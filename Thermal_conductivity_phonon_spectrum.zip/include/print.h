#ifndef PRINT_H
#define PRINT_H

#include "main.h"

typedef enum {N_I, N_R} VType;

//how to use NameList
/****************************
NameList nameList[] = {
	NameI (intVariable),
	NameR (realVector),
};
*****************************/
typedef struct {
	char *vName;
	void *vPtr;
	VType vType;
	int vLen, vStatus;
} NameList;

#define NameI(x) {#x, &x, N_I, sizeof (x) / sizeof (int)}
#define NameR(x) {#x, &x, N_R, sizeof (x) / sizeof (real)}
#define NP_I ((int *) (nameList[k].vPtr) + j)
#define NP_R ((real *) (nameList[k].vPtr) + j)

extern int cas_pho;
extern int Natoms, Nkpoints,Nkpoints_set;
extern int creat_kpoints;
extern int rm_adundant;
extern int frqcUnt;
extern int readV; // options for reading the cell volume
extern VecR volumes_cee;
extern int options_gru; // options for an additional outputs for plotting purpose.
extern real stprt;
extern real fntprt;
extern real icmtprt;
extern int options_c;
extern int ndisp; // number of dispersions
extern real cel_volm;
extern int Nelemt;
extern real gra_siz;
extern real molcl_weit;
extern VecR temprt_sfs;
extern int options_sca;
extern int methods_theml;
extern int Natoms_convtn;
extern real scaling_m5;
extern real bond_lent_avg;
extern real temprt_fre;
extern int Ncells_primtv;
extern real MGP;
extern real ASV;
extern real Tdebye;
extern real Textint;
extern real latc_const;
extern real scaling_m1;
extern int dimension_m4;
extern real LAfre, TA1fre, TA2fre; // maximum frequencies of LA and TA modes in Brillouin zone.
extern int options_Deb_sca;

int GetNameList (int argc, char **argv);
void PrintNameList (FILE *fp);
void GetsChars ();
FILE *ReadFile (char filename[128]);
FILE *WriteFile (char filename[128]);

#endif
