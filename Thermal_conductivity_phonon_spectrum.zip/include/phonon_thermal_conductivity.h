#ifndef PHONON_THERMAL_CONDUCTIVITY_H
#define PHONON_THERMAL_CONDUCTIVITY_H

#include "main.h"

#define MAX_pho 100000
#define NMAX_pho 1000
#define conv 1.0E+12
#define covmass 1.6653886E-27
#define MAX_test 200000

void Data_file_combine ();
void Phonon_thermal_conductivity ();
void Testing_code ();

#endif
