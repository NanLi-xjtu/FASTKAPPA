#ifndef MODE_GRUNEISEN_CONSTANT_H
#define MODE_GRUNEISEN_CONSTANT_H

#include "main.h"

#define MAX_mode 35000  // maximum number of rows in the data file

void Mode_Gruneisen_constant ();

#endif
