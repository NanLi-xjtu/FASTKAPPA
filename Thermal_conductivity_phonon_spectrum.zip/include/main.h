#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>

typedef double real;
typedef struct {
	real x,y,z;
} VecR;
typedef struct {
	int x,y,z;
} VecI;

//the allocations of one- and two- and three- dimensional arrays of any kind of variable or structure
#define AllocMem(a, n, t) 				\
	a = (t *) malloc ((n) * sizeof (t))
#define AllocMem2(a, n1, n2, t)				\
	AllocMem (a, n1, t *);				\
	AllocMem (a[0], (n1) * (n2), t);		\
	for (k = 1; k < n1; k ++) a[k] = a[k - 1] + n2;
#define AllocMem3(a, n1, n2, n3, t)					\
	AllocMem2(a, n1, n2, t *);					\
	AllocMem(a[0][0], (n1) * (n2) * (n3), t);			\
	for (k = 1; k < n1; k ++) a[k][0] = a[k - 1][0] + n2 * n3;	\
	for (j = 0; j < n1; j++){					\
		for (k = 1; k < n2; k++) a[j][k] = a[j][k - 1] + n3;	\
	}

#include "print.h"
#include "file_creation.h"
#include "debye_Callaway_kappa.h"
#include "group_and_phase_velocities.h"
#include "gruneisen_constants.h"
#include "mode_gruneisen_constant.h"
#include "phonon_thermal_conductivity.h"
#include "recipes.h"

#define PI 3.14159265083
#define Planck 6.62606957E-34 // Planck's constant
#define h_r 1.054571726E-34 // Reduced Planck's constant
#define k_b 1.3806488E-23 // Boltzmann constant
#define boltzmann 1.3806505E-23  // Boltzmann constants
#define N_a 6.0221413E+23 // Avogadro's number

void CheckInputFile (int argc, char **argv);
void CreatFolders ();
void CleanFiles ();
float VLen(double x, double y, double z);// Auxiliary function

#endif
