#ifndef RECIPES_H
#define RECIPES_H

#include "main.h"

void spline(float x[], float y[], int n, float yp1, float ypn, float y2[]);
void splint(float xa[], float ya[], float y2a[], int n, float x, float *y);

#endif
