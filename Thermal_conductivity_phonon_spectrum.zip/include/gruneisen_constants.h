#ifndef GRUNEISEN_CONSTANTS_H
#define GRUNEISEN_CONSTANTS_H

#include "main.h"

#define w_grun 1.0E12                    // convert THz to Hz
#define NMAX_grun 20000

float f_grun(double, double, double, double); // for evaluating the mode specific heat
void Gruneisen_constant ();

#endif
