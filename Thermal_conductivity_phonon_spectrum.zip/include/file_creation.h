#ifndef FILE_CREATION_H
#define FILE_CREATION_H

#include "main.h"

typedef struct {
	double x,y,z;
	double fre;
} Raw;

void GetNkpoints ();
void Inputs_creation_CASTEP ();
void Inputs_creation_phonopy ();
void Inputs_creation_phonopy_interpolation ();
void Inputs_creation_CASTEP_interpolation ();

#endif
