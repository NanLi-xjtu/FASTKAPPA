#ifndef DEBYE_CALLAWAY_KAPPA_H
#define DEBYE_CALLAWAY_KAPPA_H

#include "main.h"

#define MAX_debye 10000
#define NMAX_debye 100
#define conv 1.0E+12
#define covmass 1.6653886E-27
#define vmin 0.0001                // lower bound for numerical integral
#define max_in 100000                // Total number of intervals for numerical intergration

void Callway_Debye_model ();

// Debye function
float fdebye(double x);
// Integration of Debye function
float fdebye_integral(int no, float min, float max);
float feinstein(double x);
// Debye-Callway model kernel funtion for TA1
float fki_TA1(double x);
// Debye-Callway model kernel funtion for TA2
float fki_TA2(double x);
// Debye-Callway model kernel funtion for LA
float fki_LA(double x);
 // Debye-Callway model kernel funtion for OP
float fki_OP(double x);

#endif
