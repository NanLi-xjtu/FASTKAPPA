#ifndef GROUP_AND_PHASE_VELOCITIES_H
#define GROUP_AND_PHASE_VELOCITIES_H

#include "main.h"

#define MAX_vel 25000

void Velocities ();

#endif
