#include "main.h"

int main (int argc, char **argv)
{
      printf("\n");
      printf("                                \\\\--//          \n");
      printf("                              (|-@ @--|)\n");
      printf("                               \\ (_)  /      \n");
      printf("                                  -         \n");
      printf("+------------o00o-------------------------------+\n");
      printf("|                                               |\n");
      printf("|          Thermal Conducivity Project          |\n");
      printf("|        Written by Bing Xiao && Nan Li         |\n");
      printf("|                  2021-04-26                   |\n");
      printf("|  bingxiao84@xjtu.edu.cn, Bing Xiao from XJTU  |\n");
      printf("| ln906061119@stu.xjtu.edu.cn, Nan Li from XJTU |\n");
      printf("|                                               |\n");
      printf("+----------------------------------oOOo---------+\n");
      printf("\n");

	CheckInputFile (argc, argv);
	CreatFolders ();

	if (cas_pho == 1) Inputs_creation_CASTEP_interpolation ();
	else if (cas_pho == 2) Inputs_creation_phonopy_interpolation ();
	else {
		printf ("\nthe value of cas_pho is wrong\n");
		exit (1);
	}
	Velocities ();
	Mode_Gruneisen_constant ();
	Gruneisen_constant ();
	Data_file_combine ();
	Testing_code ();
	Phonon_thermal_conductivity ();
	if (methods_theml == 10) Callway_Debye_model ();

	CleanFiles ();

	return 0;
}


void CheckInputFile (int argc, char **argv)
{
	int n;
	FILE *input;
	char *filename[] = {"in/band_1.dat", "in/band_2.dat", "in/band_3.dat", "in/K.dat", \
			    "in/CONTCAR_1",  "in/CONTCAR_2", "in/CONTCAR_3","in/fastkappa.in", "\0"};
//	char *filename[] = {"in/band_c.dat", "in/band_n.dat", "in/band_s.dat", \
			    "in/K.dat", "in/Lattice_vectors.dat","in/fastkappa1.0.in", "\0"};

	n = 0;
	while (1) {
		if (strcmp (filename[n], "\0") == 0) break;
		if ((input = fopen (filename[n], "r")) == NULL) {
			printf ("%s doesn't exist\n", filename[n]);
			printf ("The following files should be included in the folder 'in':\n");
			printf ("band_c.dat, band_n.dat, band_s.dat, K.dat, CONTCAR_1,  CONTCAR_2, CONTCAR_3, fastkappa.in\n");
			exit (1);
		}
		n ++;
	}

	GetNkpoints ();
	GetNameList (argc, argv);
	PrintNameList (stdout);
	printf ("\ntotal number of original k-points in each dispersion is %d\n", Nkpoints);
	printf ("total number of interpolation k-points in each dispersion is %d\n", Nkpoints_set);
	printf ("\n\nPress 'Enter' to continue\n\n");
	getchar ();
}

void CreatFolders ()
{
	int n;
	char *filename[] = {"out", "out/file_creation", "out/group_and_phase_velocities", \
			    "out/mode_gruneisen_constants", "out/gruneisen_constants", \
			    "out/phonon_thermal_conductivity", "\0"};
	char file[128];

	n = 0;
	while (1) {
		if (strcmp(filename[n], "\0") == 0) break;
		if (mkdir(filename[n], 0777) == -1) {
			printf ("%s has already been exist\n", filename[n]);
		}
		n ++;
	}
	sprintf (file, "out/phonon_thermal_conductivity/method%d", methods_theml);
	if (mkdir(file, 0777) == -1) {
			printf ("%s has already been exist\n", file);
	}
}

void CleanFiles ()
{
	system ("rm -rf out/file_creation/Raw_*");
	system ("rm -rf out/phonon_thermal_conductivity/Spectrum_raw_*");
	switch (methods_theml){
		case 1: system ("mv out/phonon_thermal_conductivity/method1 out/phonon_thermal_conductivity/Toberer-Zevallink-Synder_model"); break;
		case 2: system ("mv out/phonon_thermal_conductivity/method2 out/phonon_thermal_conductivity/Kinetic_collective_model"); break;
		case 3: system ("mv out/phonon_thermal_conductivity/method3 out/phonon_thermal_conductivity/Modified_Kinetic_collective_model"); break;
		case 4: system ("mv out/phonon_thermal_conductivity/method4 out/phonon_thermal_conductivity/Slack_model"); break;
		case 5: system ("mv out/phonon_thermal_conductivity/method5 out/phonon_thermal_conductivity/Ding_Xiao_2015model"); break;
		case 6: system ("mv out/phonon_thermal_conductivity/method6 out/phonon_thermal_conductivity/Klemens_model"); break;
		case 7: system ("mv out/phonon_thermal_conductivity/method7 out/phonon_thermal_conductivity/Dense_k_Ding_Xiao_2015model"); break;
		case 8: system ("mv out/phonon_thermal_conductivity/method8 out/phonon_thermal_conductivity/Ding_Xiao_avegamma_model"); break;
		case 9: system ("mv out/phonon_thermal_conductivity/method9 out/phonon_thermal_conductivity/Dense_k_Ding_Xiao_avegamma_model"); break;
		case 10: system ("mv out/phonon_thermal_conductivity/method10 out/phonon_thermal_conductivity/Debye_Callaway_model"); break;
	}
}

// Auxiliary function
float VLen(double x, double y, double z)
{
      return sqrt(x*x+y*y+z*z);
}

