#include "phonon_thermal_conductivity.h"

void Method4PreProcess ();

void Data_file_combine ()
{
      int i,j,k,l;
      int R_1, R_2, R_3;
      int rows1,rows2,rows3;
      int rows;
      int Num; 
      int MAX;
      int pv;
      char file1[128],file2[128],file3[128];
      char files[128];
      float dummy1, dummy2, dummy3, dummy4, dummy5;
      float *kp, *omega,*v_p,*v_g;
      float *knumber,*fre_min,*Gamma;
      float *kx,*ky,*kz,*weight;
      float *kstar;
      FILE *input1;
      FILE *input2;
      FILE *input3;
      FILE *output;
      printf("/*----------------------------------------------------------------*/\n");
      printf("/*          THIS PROGRAM IS WRITTEN BY BING XIAO                  */\n");
      printf("/*  THIS IS A DATA PROCESSING CODE, PREPARING DATA FOR THERMAL    */\n");
      printf("/*                CONUDCTIVITY CALCULATION.                       */\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("/* You must run 'Velocities.cpp' and 'Mode_Gruneisen_constant.cpp */\n");
      printf("/*              first to generate two input files:                */\n");
      printf("/*          Velocities.dat     Geuneisen_mode.dat                 */\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("Import the data from Velocities.dat\n");
      sprintf(file1,"out/group_and_phase_velocities/Velocities.dat");
      input1=fopen(file1,"r");
      if(input1==NULL){
                      perror("Error while opening the file.\n");
                      printf("Could not find file %s.\n",file1);
                      getchar();
                      exit(EXIT_FAILURE);
                      }
      else {
      printf("File %s ls loaded.\n",file1);
           }
     R_1=0;
     while(!feof(input1)){
                     fscanf(input1,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                     R_1++;
                     }
     rows1=R_1-1;
     fclose(input1);
     kp=(float*)malloc(rows1*sizeof(float));
     omega=(float*)malloc(rows1*sizeof(float));
     v_p=(float*)malloc(rows1*sizeof(float));
     v_g=(float*)malloc(rows1*sizeof(float));
     input1=fopen(file1,"r");
     if (input1 == NULL) {
	printf ("%s does not exist\n", file1);
	exit (1);
     }
     for(i=0;i<rows1;i++){
                          fscanf(input1,"%f %f %f %f",&(kp[i]),&(omega[i]),&(v_p[i]),&(v_g[i]));
                         }
     fclose(input1);
//------------------------------------------------------------------------------
     printf("Import the data from Gruneisen_mode.dat\n");
     sprintf(file2,"out/mode_gruneisen_constants/Gruneisen_mode.dat");
     input2=fopen(file2,"r");
     if(input2==NULL){
                      perror("Error while opening the file.\n");
                      printf("Could not find file %s.\n",file2);
                      getchar();
                      exit(EXIT_FAILURE);
                      }
      else {
      printf("File %s ls loaded.\n",file2);
           }
     R_2=0;
     while(!feof(input2)){
                     fscanf(input2,"%f %f %f",&dummy1, &dummy2, &dummy3);
                     R_2++;
                     }
     rows2=R_2-1;
     fclose(input2);
     knumber=(float*)malloc(rows2*sizeof(float));
     fre_min=(float*)malloc(rows2*sizeof(float));
     Gamma=(float*)malloc(rows2*sizeof(float));
//     v_g=(float*)malloc(rows1*sizeof(float));
     input2=fopen(file2,"r");
     if (input2 == NULL) {
	printf ("%s does not exist\n", file2);
	exit (1);
     }
     for(j=0;j<rows2;j++){
                          fscanf(input2,"%f %f %f",&(knumber[j]),&(fre_min[j]),&(Gamma[j]));
                         }
     fclose(input2);
//------------------------------------------------------------------------------
     printf("The third file is relevant to the weight of each k-point.\n");
     printf("This is actually not required by thermal conductivity calculation.\n");
     printf("But it maybe useful for other purpose.\n");
     printf("Your options:Import(1) or Default(2)\n");
     printf("Enter your choice:(MUST BE AN INTEGER) %d\n", options_c);
     printf("\n");
/* Clean the buffer due to scanf */
     int S;
//     while((S=getchar())!=EOF&&S!='\n');
/*--------------------------------------*/
     if(options_c==1){
                    printf("Import the kweights from a separate file.\n");
                    printf("Enter the file name:\n");
//                    fgets(file3, 128, stdin);
                    sprintf(file3,"out/file_creation/K.dat");
		    puts (file3);
                    input3=fopen(file3,"r");
                    if(input3==NULL){
                      perror("Error while opening the file.\n");
                      printf("Could not find file %s.\n",file3);
                      getchar();
                      exit(EXIT_FAILURE);
                      }
                    else {
                          printf("File %s ls loaded.\n",file3);
                         }
                    R_3=0;
                    while(!feof(input3)){
                                         fscanf(input3,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                                         R_3++;
                                         }
                    rows3=R_3-1;
                    fclose(input3);
                    kx=(float*)malloc(rows3*sizeof(float));
                    ky=(float*)malloc(rows3*sizeof(float));
                    kz=(float*)malloc(rows3*sizeof(float));
                    weight=(float*)malloc(rows3*sizeof(float));
                    input3=fopen(file3,"r");
                    if (input3 == NULL) {
			printf ("%s does not exist\n", file3);
			exit (1);
                    }
                    for(k=0;k<rows3;k++){
                                         fscanf(input3,"%f %f %f %f",&(kx[k]),&(ky[k]),&(kz[k]),&(weight[k]));
                                         }
                    fclose(input3);
		    Num = Natoms;
                    printf("Number of atoms in the cell:(MUST BE AN INTEGER) %d\n", Num);
//                    scanf("%d",&Num);
                    MAX=3*Num*rows3;
                    kstar=(float*)malloc(MAX*sizeof(float));
                    for(i=0;i<MAX;i++){
                                       kstar[i]=0.000000;
                                       }
                    for(j=1;j<=3*Num;j++){
                                          for(k=(j-1)*rows3;k<j*rows3;k++){
                                                                           pv=k-(j-1)*rows3;
                                                                           kstar[k]=weight[pv];
                                                                           }
                                          }
                    if(rows1!=rows2||rows1!=MAX||rows2!=MAX){
                                                                 printf("Inconsistency in your data file has been detected:\n");
                                                                 printf("Rows in %s:%d\n",file1,rows1);
                                                                 printf("Rows in %s:%d\n",file2,rows2);
                                                                 printf("Rows in %s:%d\n",file3,MAX);
                                                                 printf("Go back to check your calculations.\n");
                                                                 printf("New file can not be created.\n");
                                                                 getchar();
                                                                 exit(EXIT_FAILURE);
                                                                 }
                    else if(rows1==rows2&&rows1==MAX){
                                                        rows=rows1;
                                                        }
                    }
     else if(options_c==2){
                         printf("In the default setting, the k weight is calculated as:\n");
                         printf("weight[k]=1.0/N (N: number of k points)\n");
                         printf("Enter total number of disperions:(MUST BE AN INTEGER) %d\n", ndisp);
//                         scanf("%d",&ndisp);
                         if(rows1!=rows2){
                                          printf("Inconsistency in your data file has been detected:\n");
                                          printf("Rows in %s:%d\n",file1,rows1);
                                          printf("Rows in %s:%d\n",file2,rows2);
                                          printf("Go back to check your calculations.\n");
                                          printf("New file can not be created.\n");
                                          getchar();
                                          exit(EXIT_FAILURE);
                                          }
                         else if(rows1==rows2){
                                               rows=rows1;
                                               }
                         }
//------------------------------------------------------------------------------
   sprintf(files,"out/phonon_thermal_conductivity/Inputs_kappa_cal.dat");
   output=fopen(files,"w");
   for(l=0;l<rows;l++){
                       if(options_c==1){
                                      fprintf(output,"%f\t%f\t%f\t%f\t%f\t%f\n",kp[l],omega[l],v_p[l],v_g[l],Gamma[l],kstar[l]);
                                      }
                       else if(options_c==2){
                                           fprintf(output,"%f\t%f\t%f\t%f\t%f\t%f\n",kp[l],omega[l],v_p[l],v_g[l],Gamma[l],(float)(1.0*ndisp/rows));
                                           }
                       }
   fclose(output);
   printf("All files are successfully imported.\n");
   printf("%s is created.\n",files);
   printf("Press 'Enter' key to exit the program.\n");
   free(kp);free(omega);free(v_p);free(v_g);free(knumber);
   free(Gamma);free(fre_min);
   if(options_c==1){
                  free(kx);free(ky);free(kz);
                  free(weight); free(kstar);
                  }
}

void Phonon_thermal_conductivity ()
{
int i,j,k,q;
int tmp;
int options; // Including Scattering due to isotopes??
int choice; // Methods to compute thermal conductivity
int elements; // total number of elements in the cell
int frame;
int dimension; // 2D or 3D structures;
double x, y, z, u; // intermediate varibales
double Cv; // Specific heat at constant volume
float V, V_a;// Cell volume and volume per atom
float V_av; // V/N in cubic angstrom
float d; // Grain or microstructure size
float M_v; // total molar mass of the cell
float M_av; // molar mass of averaged atom 
double *im_c; // Constant in the relaxation time of impurity
double fre; // frequency;
double th_c, total; // thermal conductivity
double th_ca, th_cb, th_cc, th_cn; // thermal conductivity due to phonon, boundary and impurity and normal process;
double th_cd; // thermal conductivitiesue to scattering of T and L phonon by dislocations
double Td; // mode Debye temperature
double blg; // bond length
double gammaave_ac;  // average Gruneisen constant of acoustic phonon modes
double gammaave_op; // average Gruneisen of optical branches
double gammasum_ac;
double gammasum_op; // 
int N; // Atoms per cell
int N_t; // total number of atoms in conventional cell
int *N_d; // Total number of single site substititional defects
int nkpt; // total number of kpoints in the dispersions
int columns; // Number of dispersions
float T, T_s, T_f, step; // Temperature
float T_fre; 
float m_t, r_t, m_a, r_a; // average mass and average radius of atoms (scattering due to single defects)
//double tau_u, tau_b, tau_m, tau_na, tau_nb, tau_n; // Relaxation times for phonon, boudary, impurity and isotope
//double tau_d, tau_dt, tau_dl; // relaxaltion tume due to phonon and dislocations 
//double taua, taub, tauc, taun, taut, tau; // average phonon relaxation times of phonon, imprity, isotope and total.
//double tau_s; // total scatrering rate
//double l_p,l_pa,l_pb,l_pc,l_pn; // mean free path
float LAfre, TA1fre, TA2fre; // maximum frequencies of LA and TA modes in Brillouin zone.
float LA_T, TA1_T, TA2_T; // Debye temperature of LA and TA modes
float phonon_T; // 
float cns;
float MGP; 
float ASV;
float Tdebye; // Debye temperature
float Textint; // Extinction Debye temperature
double B_u, B_n, B_nn; // Constants in relaxation expressions
float dummy1, dummy2, dummy3, dummy4, dummy5, dummy6; // Auxiliary variables
double scaling; // Global scaling parameter for phonon relaxation time 
float *mass,*radius,*fraction; // the atomic mass and radius for each species (scattering due to single defects)
float *kpoint,*omega,*v_p,*v_g,*Gamma,*weight; // module of k-point, frequency, phase velocity and group velocity
// Auxiliary function
float f(double);
float g(double);
float Gaussian(double,double,double);
float w2(double, double);
float w3(double, double, double);
float w4(double, double, double, double);
float damp(double);
float damp1(double, double);
float w5(double, double, double);
float w6(double, double);
char file1[128], file2[128];
printf("/*       ################################################               */\n");
printf("/*       #   Thermal Conductivity from Phonon Spectrum  #               */\n");
printf("/*       #          Version 1.0: 2016-09-13             #               */\n");
printf("/*       #   Latest Update Made: 2016-08-18             #               */\n");
printf("/*       ################################################               */\n");
printf("/*----------------------------------------------------------------------*/\n"); 
printf("/*              This Program is written by Bing Xiao                    */\n");
printf("/*                   Department of Physics                              */\n");
printf("/*                    Temple University                                 */\n");
printf("/*                    b.xiao@ucl.ac.uk                                  */\n");
printf("/*--------------------PROPERTIES COMPUTED-------------------------------*/\n"); 
printf("/*                    THERMAL CONDUCTIVITY                              */\n");
printf("/*             USING RELAXATION TIME APPROXIMATION                      */\n");
printf("/*                    Empirical Slack Model                             */\n");
printf("/*-----------------PLEASE CITE THE FOLLOWING PAPER----------------------*/\n");
printf("/*           Y.Ding, B.Xiao, RSC Advances,5,18391(2015)                 */\n");
printf("/*---------------------IMPORTANCE NOTICE--------------------------------*/\n");
printf("/*          ONLY APPLIES TO THE PRINCIPAL DIRECTIONS                    */\n");
printf("/*                  [100], [010] and [001]                              */\n");
printf("/*         THERMAL CONDUCTIVITY TENSOR COMPONENTS COMPUTED              */\n");
printf("/*                kappa_xx, kappa_yy, kappa_zz                          */\n");
printf("/*       THE RESULTS MAY NOT Correct FOR OTHER DIRECTIONS               */\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("Method one(1):Toberer-Zevallink-Synder model\n");
printf("Method two(2):Kinetic-Collective model (Requiring empirical parameters from Experiments)\n");
printf("Method three(3):Kinetic-Collective model with minimum fitting parameters\n");
printf("Method four(4):Slack model\n");
printf("Method five(5):Modified T-Z-S model with minimum cutoff distance\n");
printf("Method six(6):Klemens model\n");
printf("Method seven(7):Integration form of Method 5, requring dense k-mesh(>1000 k-points)\n");
printf("Method eight(8):Modified form of Method 5, using mode-averaged gamma\n");
printf("Method nine(9):Modified form of Method 7, using mode-avarged gamma\n");
printf("Method ten(10):Debye-Callaway model, not included in this package\n");
printf("WARNING: The Default Unit for Phonon Dispersion is THz, normal frequency.\n");
printf("If you use angular frequency, please convert the values first.\n"); 
printf("Please input the parameters indicated below:\n");
printf("All quantities are defined with respect to the actual crystal cell used in the simulation.\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("For 2D structures, volume is calculated as: layerthickness X crossarea.\n");
V = cel_volm;
printf("The cell volume:(cubic angstrom) %f\n", V);
//scanf("%f",&V);
elements = Nelemt;
printf("Number of different elements in cell:(MUST BE AN INTEGER) %d\n", elements);
//scanf("%d",&elements);
d = gra_siz;
printf("What is the grain size? (Unit in mm, the possible values are from 1-5) %f\n", gra_siz);
printf("If you are not sure about its value, please input '1.00'\n");
printf("In the current model, this is considered as a constantn from tau=L/v_g\n"); 
//scanf("%f",&d);
N = Natoms;
printf("The total number of atoms in cell (Must be an integer: 2,5,10,etc) %d\n", Natoms);
//scanf("%d",&N);
N_t = Natoms_convtn;
printf("Enter total number of atoms in conventional cell: %d\n", N_t);
//scanf("%d",&N_t);
M_v = molcl_weit;
printf("Input the molecule weight per cell (56.78 etc) %f\n", M_v);
//scanf("%f",&M_v);
T_s = stprt;
T_f = fntprt;
step = icmtprt;
printf("Temperature (K)\n");
printf("Input starting T, final T and step of T (100.0, 200.0, 10.0): %f %f %f\n", T_s,T_f,step);
//scanf("%f %f %f",&T_s,&T_f,&step);
nkpt = Nkpoints;
printf("Total numner of kpoints in each dispersion curve:(MUST BE AN INTEGER) %d\n", nkpt);
//scanf("%d",&nkpt);
printf("/*----------------------------------------------------------------------*/\n");  
printf("Here is the summary of some input parameters\n");
printf("Cell volume=%f\nTotal number of atoms=%d\nGrain size=%f\n",V,N,d);
printf("Starting T=%f\nEnding T=%f\nStep of T=%f\n",T_s,T_f,step); 
printf("/*----------------------------------------------------------------------*/\n");
FILE *input1;
FILE *output0; 
FILE *output;
FILE *output1;
FILE *output2;
FILE *output3;
FILE *output4;
FILE *output7;
V_a=V*pow(10,-30.0)/((float)N);  // Volume per atom in cubic meter
V_av=V/((float)N); // Volume per atom in cubic angstrom
M_av=(float)(M_v/N);   // Atomic mass per averged atom
//------------------------------------------------------------------------------
printf("If there are more than one elements in the structure, you must prepare:\n");
printf("------------------------------------------------------------------------\n");
printf(" Elements_1.dat, Elements_2.dat and etc.\n");
printf("------------------------------------------------------------------------\n");
options = options_sca;
printf("Do you want to include scattering mechanism due to isotopes: Yes(1)or No(2)\n");
printf("Enter your option:(MUST BE AN INTEGER) %d\n", options);
//scanf("%d",&options);
//getchar ();
if(options==1){
               FILE *input;
               int R_1;
               char files1[128];
               im_c=(double*)malloc(elements*sizeof(double));
               N_d=(int*)malloc(elements*sizeof(int));
               for(frame=0;frame<elements;frame++){
                                           N_d[frame]=0;
                                           printf("Information about all isotopes must be given in an separate file.\n");
//               printf("Enter the file name below:(Defect.dat or Isotopes.dat)\n");
//               gets(files1);
                                           sprintf(files1,"in/Elements_%d.dat",frame+1);
                                           input=fopen(files1,"r");
                                           if(input==NULL){
                                                           perror("Error while opening the file.\n");
                                                           getchar();getchar();
                                                           exit(EXIT_FAILURE);
                                                           }
                                           else {
                                                 printf("File %s ls loaded.\n",files1);
                                                 }
                                           R_1=0;
                                           while(!feof(input)){
                                                                fscanf(input,"%f %f %f",&dummy1, &dummy2, &dummy3);
                                                                R_1++;
                                                                }
                                           N_d[frame]=R_1-1;
                                           fclose(input);
                                           printf("%d\t%d\n",R_1,N_d[frame]);
                                           fraction=(float*)malloc(N_d[frame]*sizeof(float));
                                           mass=(float*)malloc(N_d[frame]*sizeof(float));
                                           radius=(float*)malloc(N_d[frame]*sizeof(float));
                                           input=fopen(files1,"r");
                                           for(j=0;j<N_d[frame];j++){
                                                                     fscanf(input,"%f %f %f",&(mass[j]),&(radius[j]),&(fraction[j]));
                                                                     }
                                           fclose(input);
                                           m_a=0.000000;
                                           r_a=0.000000; 
                                           for(k=0;k<N_d[frame];k++){
                                                              m_a+=fraction[k]*mass[k];
                                                              r_a+=fraction[k]*radius[k];
                                                              printf("%f\t%f\t%f\n",mass[k],radius[k],fraction[k]);
                                                              }
                                           printf("Defect related parameters:\n");
                                           printf("Average Mass\tAverage Radius(Angstrom)\n");
                                           printf("%f\t%f\n",m_a,r_a);
                                           im_c[frame]=0.000000;
                                           for(i=0;i<N_d[frame];i++){
                                                              im_c[frame]+=fraction[i]*((1.0-mass[i]/m_a)*(1.0-mass[i]/m_a)+(1.0-radius[i]/r_a)*(1.0-radius[i]/r_a));
                                                             }
                                           printf("The isotope constant for element %d\n",frame+1);
                                           printf("Number of isotopes: %d\n",N_d[frame]);
                                           printf("%le\n",im_c[frame]);
                                           printf("---------------------------------------------------------\n");
                                           free(fraction); free(radius); free(mass);
                                           }
                printf("Scattering constants for isotopes are calculated!\n");
               }
else if(options==2){
                    printf("Scattering due to isotopes is not calculated.\n");
                    printf("No furhter information is required.\n");
                    }
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
printf("/*-----------------------IMPORTANT NOTICE-------------------------------*/\n");
printf("/*   Two slightly different methods are implemented and availabe to     */\n");
printf("/*   calculate thermal conductivity in the program. Details about two   */\n");
printf("/*   methods can be found in the two references given below:            */\n");
printf("/*--------------------------METHOD ONE----------------------------------*/\n");
printf("/* Phonon Engineering Through Crystal Chemistry, Eric S.Toberer,        */\n");
printf("/* Alex Zevalkink and G.Jeffrey Snyder, J.Mater.Chem.,2011,21,15843.    */\n");
printf("/*--------------------------METHOD TWO----------------------------------*/\n");
printf("/* Thermal Conductivity of Group-IV Semiconductors From a Kinetic-      */\n");
printf("/* Collective Model, C.de Tomas,A.Cantarero,A.F.Lopeandia and           */\n"); 
printf("/* F.X.Alvarez, Proceedings of the Royal Society A,2015,470,20140371.   */\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*--------------------------METHOD THREE--------------------------------*/\n");
printf("/*  Kinetic-Collective Model is fully implemented in the third method.  */\n");
printf("/*  This allows the calculation of thermal conductivity in the whole    */\n");
printf("/*  temperature range with minimum fitting parameters.                  */\n");
printf("/*  From Kinetic to Collective Behaviour in Thermal Transport on Semi-  */\n");
printf("/*  conductors and Semiconductor Nanostructures,C.de Tomas,A.Cantarero  */\n");
printf("/*  A.F.Lopeandia and F.X.Alvarez,Journal of Applied Physics,115,164314 */\n");
printf("/*  (2014).                                                             */\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*---------------------------METHOD FOUR--------------------------------*/\n");
printf("/*  Slack model is an empirical method to calculate kappa as a function */\n");
printf("/*  of temperature; this method only estimates the thermal conductivity */\n");
printf("/*  and the relaxation time is not calculated at all.                   */\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*            ############################################              */\n");
printf("/*            #               METHOD FIVE                #              */\n");
printf("/*            #  Implemented by BING XIAO on 2016-08-18  #              */\n");
printf("/*            ############################################              */\n");
printf("/*  Scattering processes are exactly the same as those in method one,   */\n");
printf("/*  The cutoff radius is used to ensure the shortest mean free path is  */\n");
printf("/*  no smaller than the average atomic distance in solid (1.0 Angstrom).*/\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*            ############################################              */\n");
printf("/*            #               METHOD  SIX                #              */\n");
printf("/*            #  Implemented by BING XIAO on 2021-04-02  #              */\n");
printf("/*            ############################################              */\n");
printf("/*                            Klemens Method                            */\n");
printf("/*                                                                      */\n");
printf("/*                                                                      */\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*            ############################################              */\n");
printf("/*            #               METHOD  Seven              #              */\n");
printf("/*            #  Implemented by BING XIAO on 2021-04-02  #              */\n");
printf("/*            ############################################              */\n");
printf("/*                     Integration Form of Method 5                     */\n");
printf("/*                                                                      */\n");
printf("/*                                                                      */\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*            ############################################              */\n");
printf("/*            #               METHOD  Eight              #              */\n");
printf("/*            #  Implemented by BING XIAO on 2021-04-25  #              */\n");
printf("/*            ############################################              */\n");
printf("/*                     Modified Form of Method 5                        */\n");
printf("/*         Using the average gamma_ac and gamma_op in tau_U             */\n");
printf("/*                                                                      */\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*----------------------------------------------------------------------*/\n");
printf("/*            ############################################              */\n");
printf("/*            #               METHOD  Nine              #               */\n");
printf("/*            #  Implemented by BING XIAO on 2021-04-25  #              */\n");
printf("/*            ############################################              */\n");
printf("/*                     Modified Form of Method 7                        */\n");
printf("/*         Using the average gamma_ac and gamma_op in tau_U             */\n");
printf("/*                                                                      */\n");
printf("/*----------------------------------------------------------------------*/\n"); 
printf("/*----------------------------------------------------------------------*/\n");
printf("/*            ############################################              */\n");
printf("/*            #               METHOD  Ten                #               */\n");
printf("/*            #  Implemented by BING XIAO on 2021-04-25  #              */\n");
printf("/*            ############################################              */\n");
printf("/*                        Debye-Callaway Model                          */\n");
printf("/*               Avaialble in another associated code                   */\n");
printf("/*----------------------------------------------------------------------*/\n");           
printf("Choose you method:\n");
printf("Method one(1):Toberer-Zevallink-Synder model\n");
printf("Method two(2):Kinetic-Collective model (Requiring empirical parameters from Experiments)\n");
printf("Method three(3):Kinetic-Collective model with minimum fitting parameters\n");
printf("Method four(4):Slack model\n");
printf("Method five(5):Modified T-Z-S model with minimum cutoff distance\n");
printf("Method six(6):Klemens model\n");
printf("Method seven(7):Integration form of Method 5, requring dense k-mesh(>1000 k-points)\n");
printf("Method eight(8):Modified form of Method 5, using mode-averaged gamma\n");
printf("Method nine(9):Modified form of Method 7, using mode-avarged gamma\n");
printf("Method ten(10):Debye-Callaway model, not included in this package\n");

choice = methods_theml;
printf("Enter you choice:Method one(1) or Method two (2) or Method three (3)\n");
printf("Method four (4) or Method five (5): \n%d\n", choice);
//scanf("%d",&choice);

if (choice == 4) Method4PreProcess ();

if(choice==2||choice==3){
              printf("Additional parameters are required in Kinetic-Collective Model.\n");
              printf("Macroscpic Gruneisen Parameter(MGP)\nAverage Sound Velocity(ASV)(m/s)\n");
              printf("Debye Temperature(K)\nUmklapp Extinction Temperature(K)\n");
              printf("Enter MGP:(1.0)\n");
              printf("MGP, enter 1.0, if you do not know the actual value. %f\n", MGP);
//              scanf("%f",&MGP);
              printf("Enter ASV:(4500.0)\n");
              printf("ASV can be calculated from mechanical moduli. %f\n", ASV);
//              scanf("%f",&ASV);
              printf("Enter Debye Temperature:(239.0) %f\n", Tdebye);
//              scanf("%f",&Tdebye);
              printf("Enter U Extinction Temperature:(1000.0) %f\n", Textint);
//              scanf("%f",&Textint);
	      scaling = latc_const;
              printf("Enter lattice constant in the computing direction:(Angstrom) %f\n", scaling);
//              scanf("%lf",&scaling);
              B_u=(k_b*MGP*MGP*V_a)/((M_av*covmass)*pow(ASV,5.0));
              B_n=pow(k_b,3.0)*pow(MGP,2.0)*V_a/(pow(h_r,2.0)*(M_av*covmass)*pow(ASV,5.0));
              B_nn=k_b*pow(MGP,2.0)/((M_av*covmass)*ASV*pow(V_a,1.0/3.0));
              //B_u=2.8E-46; B_n=2.2E-23; B_nn=3.7E8;
              printf("Constants in RTA:\n");
              printf("B_u=%le(s^3K^-1)\nB_n=%le(sK^-3)\nB_n'=%le(s^-1K^-1)\n",B_u,B_n,B_nn);
              }
else if(choice==1){
		   scaling = scaling_m1;
                   printf("A global scaling parameter is required to adjust all relaxation mechansims.\n");
                   printf("The value is equivilent to lattice constant in one principal direction(Angstrom).\n");
                   printf("The default value is 1.000000 in the program.\n");
                   printf("If you wish to use another value, enter here: %f\n", scaling);
//                   scanf("%lf",&scaling);
                   }
else if(choice==5||choice==7||choice==8||choice==9){
                   scaling = scaling_m5;
                   printf("A global scaling parameter is required to adjust all relaxation mechansims.\n");
                   printf("The value is equivilent to lattice constant in one principal direction(Angstrom).\n");
                   printf("The default value is 1.000000 in the program.\n");
                   printf("If you wish to use another value, enter here: %lf\n", scaling);
//                   scanf("%lf",&scaling);
		   blg = bond_lent_avg;
                   printf("Average bond length in the cell:(2.897): %lf\n", blg);
//                   scanf("%lf",&blg);
                   }
else if(choice==4){
		   dimension = dimension_m4;
                  // read the Slack_model_supporitng.dat file for frequencies
//                   int branch[3*N];
//                   float f_slack[3*N];
		   int *branch;
		   float *f_slack;
		   AllocMem (branch, 3 * Natoms, int);
		   AllocMem (f_slack, 3 * Natoms, float);
                   FILE *input_slack;
//                   input_slack=fopen("out/phonon_thermal_conductivity/method4/Slack_model_supporting.dat","r");
		   input_slack = ReadFile ("out/phonon_thermal_conductivity/method4/Slack_model_supporting.dat");
                   for(i=0;i<3*N;i++){
                                      fscanf(input_slack,"%d %f",&(branch[i]),&(f_slack[i]));
                        }
                   fclose(input_slack);
		   printf("Slack model is employed here to calculate thermal conducitvity.\n");
                   printf("Please provide the following paramters:\n");
                   printf("Geometry of the system:3D-crystal (1); 2D-layer cryatal (2)\n");
                   printf("Enter you option: %d\n", dimension);
//                   scanf("%d",&dimension);
                   if(dimension==1||dimension==2){
                                                  //printf("Maximum phonon frequency of LA branch:(THz), not (2Pi*THz)\n");
                                                  //scanf("%f",&LAfre);
                                                  LAfre=f_slack[2];
						  printf("Maximum phonon frequency of LA branch:%f(THz)\n",LAfre);
						  //printf("Maximum phonon frequency of TA1 branch:(THz)\n");
                                                  //scanf("%f",&TA1fre);
						  TA1fre=f_slack[0];
                                                  printf("Maximum phonon frequency of TA1 branch:%f(THz)\n",TA1fre);
						  LA_T = Planck*LAfre*conv/k_b;
                                                  TA1_T = Planck*TA1fre*conv/k_b;
                                                  }
                   if(dimension==1){
                                         TA2fre=f_slack[1];
					 printf("Maximum phonon frequency of TA2 branch:%f(THz)\n",TA2fre);
                                         //scanf("%f",&TA2fre);
                                         TA2_T = Planck*TA2fre*conv/k_b;
                                         }
                   // average Debye temperature
                   if(dimension==1){
                                    phonon_T = 1.0/w5(LA_T,TA1_T,TA2_T);
                                    Tdebye = g(phonon_T);
                                    }
                   else if(dimension==2){
                                         phonon_T = 1.0/w6(LA_T,TA1_T);
                                         Tdebye = g(phonon_T);
                                         }
                   printf("-----------------------------------------------------\n");
                   printf("Phonon modes and Mode_Debye temperatures\n");
                   printf("Branch\tFrequency(THz)\tTemperature(K)\n");
                   printf("LA\t%f\t%f\n",LAfre,LA_T);
                   printf("TA1\t%f\t%f\n",TA1fre,TA1_T);
                   if(dimension==1){
                                    printf("TA2\t%f\t%f\n",TA2fre,TA2_T);
                                    }
                   printf("Phonon-Mode-Averaged-Debye-Temperature(K):%f\n",Tdebye);
                   printf("-----------------------------------------------------\n");
		   free (f_slack);
		   free (branch);
                   }
if(choice==1||choice==2||choice==3||choice==5||choice==7||choice==8||choice==9){
                         printf("Scattering mechanisms included in the calculations are:\n");
                         printf("1.Umklapp scattering(U-Process)---->ALL.\n");
                         printf("2.Boundary scattering(Finite size of sample(grain))---->ALL.\n");
                         printf("3.Isotope scattering(Defects)---->ALL.\n");
                         printf("4.Normal scattering(N-process)---->Method One/Five.\n");
                         printf("Scattering procresses are not included currently:\n");
                         printf("1.Dislocation scattering.\n");
                         printf("2.Normal scattering process(N-process)---->Method Two.\n");
                         printf("Phonon momentum is conserved in N-process,thus does not contribute to conductivity.\n");
                         printf("Any other scattering mechanisms.\n");
                         printf("The program will write relaxation time and mean free path for each\n");
                         printf("phonon frequency, but only at a temperature in the current code.\n");
                         printf("The main consideration is to reduce the adoudant data.\n");
                         T_fre = temprt_fre;
                         printf("Enter the temperature:(Valid range:%f~%f) %f\n",T_s,T_f, T_fre);
//                         scanf("%f",&T_fre); 
                         }
else if(choice==4||choice==6){
                   printf("Relaxation time is not evaluated in the method.\n");
                   }
printf("/*----------------------------------------------------------------------*/\n");
printf("Import frequency dependent parameters:\n");
if(choice==1||choice==2||choice==3||choice==5||choice==6||choice==7||choice==8||choice==9){
                                    sprintf(file1,"out/phonon_thermal_conductivity/Inputs_kappa_cal.dat");
                                    input1=fopen(file1,"r");
                                    if(input1==NULL){
                                                     perror("Error while opening the file.\n");
                                                     getchar(); getchar();
                                                     exit(EXIT_FAILURE);
                                                     }
                                    else {
                                          printf("File %s ls loaded.\n",file1);
                                          }
                                    int R_2=0;
                                    while(!feof(input1)){
                                                         fscanf(input1,"%f %f %f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4, &dummy5, &dummy6);
                                                         R_2++;
                                                         }
                                    tmp=R_2-1;
                                    columns=tmp/nkpt; // total number of bands in input
                                    printf("Importing data is done.\n");
                                    printf("Total number of rows=%d\n",tmp);
                                    printf("Total number of phonon dispersions=%d\n",columns);
                                    fclose(input1);
                                    kpoint=(float*)malloc(tmp*sizeof(float));
                                    omega=(float*)malloc(tmp*sizeof(float));
                                    v_p=(float*)malloc(tmp*sizeof(float));
                                    v_g=(float*)malloc(tmp*sizeof(float));
                                    Gamma=(float*)malloc(tmp*sizeof(float));
                                    weight=(float*)malloc(tmp*sizeof(float));
                                    input1=fopen(file1,"r");
                                    for(j=0;j<tmp;j++){
                                                       fscanf(input1,"%f %f %f %f %f %f",&(kpoint[j]),&(omega[j]),&(v_p[j]),&(v_g[j]),&(Gamma[j]),&(weight[j]));
                                                       }
                                    fclose(input1);
                                    // exclude the very small mode-gruneisen parameters 
									for(i=0;i<tmp;i++){
									                  if(fabs(Gamma[i]-0.)<=0.05){
													                             printf("%f\t%f\t%f\n",kpoint[i],omega[i],Gamma[i]);
																				 Gamma[i]=0.05;
																				 printf("%f\t%f\t%f\n",kpoint[i],omega[i],Gamma[i]);
																				 }
													  }  
                                    printf("Check the inputs, the last 50 lines will be shown here.\n");
                                    for(q=tmp-50;q<tmp;q++){
                                                            printf("%f\t%f\t%f\t%f\t%f\t%f\n",kpoint[q],omega[q],v_p[q],v_g[q],Gamma[q],weight[q]);
                                                            }
                                    }
else if(choice==4){
                   printf("You must run 'Mode_Gruneisen_constant.cpp' first to create 'Gruneisen_mode.dat' as input.\n");
                   sprintf(file1,"out/mode_gruneisen_constants/Gruneisen_mode.dat");
                   input1=fopen(file1,"r");
                   if(input1==NULL){
                                    perror("Error while opening the file.\n");
                                    getchar(); getchar();
                                    exit(EXIT_FAILURE);
                                    }
                   else {
                         printf("File %s ls loaded.\n",file1);
                         }
                   int R_2=0;
                   while(!feof(input1)){
                                        fscanf(input1,"%f %f %f",&dummy1, &dummy2, &dummy3);
                                        R_2++;
                                        }
                   tmp=R_2-1;
                   columns=tmp/nkpt; // total number of bands in input
                   printf("Importing data is done.\n");
                   printf("Total number of rows=%d\n",tmp);
                   printf("Total number of phonon dispersions=%d\n",columns);
                   fclose(input1);
                   kpoint=(float*)malloc(tmp*sizeof(float));
                   omega=(float*)malloc(tmp*sizeof(float));
                   Gamma=(float*)malloc(tmp*sizeof(float));
                   input1=fopen(file1,"r");
                   for(j=0;j<tmp;j++){
                                      fscanf(input1,"%f %f %f",&(kpoint[j]),&(omega[j]),&(Gamma[j]));
                                      }
                   fclose(input1);
                   printf("Check the inputs, the last 50 lines will be shown here.\n");
                   for(q=tmp-50;q<tmp;q++){
                                           printf("%f\t%f\t%f\n",kpoint[q],omega[q],Gamma[q]);
                                           }
                   }
printf("All required files are uploaded.\n");
printf("Program is running, please wait........\n");
//------------------------------------------------------------------------------
double th_t, th_u, th_b, th_n, th_s, th_ub, th_ubs, th_ubn;
double tau_t, tau_u, tau_b, tau_n, tau_s, tau_ub, tau_ubs, tau_ubn;
double l_t, l_u, l_n, l_s, l_b, l_ub, l_ubs, l_ubn;
double tt, tu, tb, ts, tn, tub, tubs, tubn;
double th_us, tau_us, l_us,tus;
double integral;
double invtau_s;
double CVV;
char filename[128];
if(choice==1||choice==2||choice==5||choice==7||choice==8||choice==9){
              //output0=fopen("Kappa_spectrum.dat","w");
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/Relaxation_time.dat", choice);
	      output=fopen(filename,"w"); 
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/Thermal_conductivity.dat", choice);
              output1=fopen(filename,"w");
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/Phonon_mean_path.dat", choice);
              output2=fopen(filename,"w");
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/Frequency_relaxation_tim.dat", choice);
              output3=fopen(filename,"w");
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/Frequency_mean_path.dat", choice);
              output4=fopen(filename,"w");
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/Phonon_branch_conductivity.dat", choice);
              output7=fopen(filename,"w");
              fprintf(output,"Temperature(K)\tU(s)\tB(s)\tS(s)\tN(s)\tU+B(s)\tU+B+S(s)\tU+B+N(s)\tU+B+S+N(s)\tU+S(s)\n");
              fprintf(output1,"Temperature(K)\tU(W/m.K)\tB(W/m.K)\tS(W/m.K)\tN(W/m.K)\tU+B(W/m.K)\tU+B+S(W/m.K)\tU+B+N(W/m.K)\tU+B+S+N(W/m.K)\tU+S(W/m.K)\n");
              fprintf(output2,"Temperature(K)\tU(m)\tB(m)\tS(m)\tN(m)\tU+B(m)\tU+B+S(m)\tU+B+N(m)\tU+B+S+N(m)\tU+S(m)\n");
              fprintf(output3,"Frequency(THz)\tT(K)\tU(s)\tB(s)\tS(s)\tN(s)\tU+B(s)\tU+B+S(s)\tU+B+N(s)\tU+B+S+N(s)\tU+S(s)\n");
              fprintf(output4,"Frequency(THz)\tT(K)\tU(m)\tB(m)\tS(m)\tN(m)\tU+B(m)\tU+B+S(m)\tU+B+N(m)\tU+B+S+N(m)\tU+S(m)\n");
              fprintf(output7,"Branch\tTemperature(K)\tkappa_u(W/m.K)\tkappa_b(W/m.K)\tkappa_s(W/m.K)\tkappa_t(W/m.K)\n");
              } 
if(choice==1||choice==5||choice==7||choice==8||choice==9){
                                   //double spfre;
								   //double sp_max=50.0; // THz
                                   //double sp_min=0.001; // THz;
								   //double sp_step; 
				   sprintf (filename, "out/phonon_thermal_conductivity/method%d/Kappa_spectrum.dat", choice);
				   output0=fopen(filename,"w");
                                   fprintf(output0,"Temperature(K)\tFrequency(THz)\tKappa_u(W/m.k)\tKappa_us(W/m.K)\n");
								   } 
if(choice==2){
              for(T=T_s;T<=T_f;T=T+step){
                                         /*Total thermal conductivity, relaxation time and mean free path*/
                                         th_t=0.000000;
                                         tt=0.00000;
                                         l_t=0.000000;
                                         /*U-procress*/
                                         th_u=0.000000;
                                         tu=0.000000;
                                         l_u=0.000000;
                                         /* Boundary scattering*/
                                         th_b=0.000000;
                                         tb=0.000000;
                                         l_b=0.000000;
                                         /* Isotope scattering*/
                                         th_s=0.000000;
                                         ts=0.000000;
                                         l_s=0.000000;
                                         /* N-Procress*/
                                         th_n=0.000000;
                                         tn=0.000000;
                                         l_n=0.000000;
                                         /*Composite relaxation time*/
                                         //Boundary+U-process
                                         th_ub=0.000000;
                                         tub=0.000000;
                                         l_ub=0.000000;
                                         // Boundary+U-process+Isotope
                                         th_ubs=0.000000;
                                         tubs=0.000000;
                                         l_ubs=0.000000;
                                         //Boundary+U-process+N-process
                                         th_ubn=0.000000;
                                         tubn=0.000000;
                                         l_ubn=0.000000;
                                         // U-process + Isotope
                                         th_us=0.000000;
                                         tus=0.000000;
                                         l_us=0.000000;
                                         CVV=0.000000;
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre1=omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  CVV += weight[i]*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                                         }
                                                                                                  }
                                                                 }
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                fre=omega[i]*2.0*PI*pow(10.0,12);
                                                                                                // Calculating the relaxation time
                                                                                                /* Boundary scattering*/
                                                                                                tau_b=d*pow(10.0,-3.0)/(v_g[i]*2.0*PI);
                                                                                                if(options==1){
                                                                                                /* Impurity scattering*/
                                                                                                               invtau_s=0.00000000;
                                                                                                               for(q=0;q<elements;q++){
                                                                                                                                       invtau_s += 1.0/(4.0*PI*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)/(V_a*im_c[q]*f(fre)*f(fre)));
                                                                                                                                       }
                                                                                                               tau_s=1.0/invtau_s;
                                                                                                               }
                                                                                                else if(options==2){
                                                                                                                    tau_s=99999999.0;
                                                                                                                    }
                                                                                                /* U-process*/
                                                                                                tau_u=exp(Textint/T)/(B_u*pow(fre,4.0)*T*(1.0-exp(-3.0*T/Tdebye)));
                                                                                                /* N-Process*/
                                                                                                tau_n=1.0/(B_nn*T)+1.0/(B_n*pow(T,3.0)*pow(fre,2.0)*(1.0-exp(-3.0*T/Tdebye)));
                                                                                                /* Total relaxation time*/
                                                                                                tau_t=1.0/w4(tau_u,tau_n,tau_b,tau_s);
                                                                                                /* Boundary+U-process*/
                                                                                                tau_ub=1.0/w2(tau_u,tau_b);
                                                                                                /* Isotope + U process */
                                                                                               // if(options==1){
                                                                                                tau_us=1.0/w2(tau_u,tau_s);
                                                                                                //               }
                                                                                                /* Boundary+U-process+Isotope*/
                                                                                                tau_ubs=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process+N-process*/
                                                                                                tau_ubn=1.0/w3(tau_u,tau_b,tau_n);
                                                                                                /* Mode heat capacity*/
                                                                                                Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                                                                                if(omega[i]>0.0&&v_g[i]!=0.0){
                                                                                                                              integral=(scaling*pow(10.0,-10)/(1.0*2.0*PI))*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,10);
                                                                                                                              // Boundary conductivity
                                                                                                                              th_b += tau_b*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // Isotope conductivity
                                                                                                                              if(options==1){
                                                                                                                              th_s += tau_s*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                                                  th_s+=(1.0/3.0)*0.000000;
                                                                                                                                                  } 
                                                                                                                              // U-Process
                                                                                                                              th_u += tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // N process
                                                                                                                              th_n += tau_n*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // Combined process
                                                                                                                              // 1. Total
                                                                                                                              th_t += tau_t*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // 2. Boundary +U-process
                                                                                                                              th_ub += tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // 3. Boundary + U-process + Isotope
                                                                                                                              if(options==1){
                                                                                                                              th_ubs += tau_ubs*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              th_ubs += tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                                  }
                                                                                                                              // 4. Boundary + U-process + N-process
                                                                                                                              th_ubn += tau_ubn*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // 5. U-process + Isotope scattering
                                                                                                                              if(options==1){
                                                                                                                                             th_us += tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                                                  th_us += tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                                  } 
                                                                                                                              /*------------------Total Relaxation Time-----------------------------------*/
                                                                                                                              tt+=tau_t*Cv*weight[i]/CVV;
                                                                                                                              tu+=tau_u*Cv*weight[i]/CVV;
                                                                                                                              tb+=tau_b*Cv*weight[i]/CVV;
                                                                                                                              tn+=tau_n*Cv*weight[i]/CVV;
                                                                                                                              tub+=tau_ub*Cv*weight[i]/CVV;
                                                                                                                              tubn+=tau_ubn*Cv*weight[i]/CVV;
                                                                                                                              if(options==1){
                                                                                                                              ts+=tau_s*Cv*weight[i]/CVV;
                                                                                                                              tubs+=tau_ubs*Cv*weight[i]/CVV;
                                                                                                                              tus+=tau_us*Cv*weight[i]/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              ts+=tau_s*0.000000;
                                                                                                                              tubs+=tau_ub*Cv*weight[i]/CVV;
                                                                                                                              tus+=tau_u*Cv*weight[i]/CVV;
                                                                                                                                                   }
                                                                                                                              /*-------------------MEAN FREE PATH-----------------------------------------*/
                                                                                                                              l_t+=tau_t*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_u+=tau_u*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*Cv*weight[i];
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                                                  }
                                                                                                                              }
                                                                                                if(T==T_fre&&omega[i]!=0.0){
                                                                                                             cns=(v_g[i]*2.0*PI);
                                                                                                             fprintf(output3,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u,tau_b,tau_s,tau_n,tau_ub,tau_ubs,tau_ubn,tau_t,tau_us);
                                                                                                             fprintf(output4,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u*cns,tau_b*cns,tau_s*cns,tau_n*cns,tau_ub*cns,tau_ubs*cns,tau_ubn*cns,tau_t*cns,tau_us*cns);
                                                                                                             }
                                                                                                }
                                                                 fprintf(output7,"%d\t%f\t%le\t%le\t%le\t%le\n",k,T,th_u,th_b,th_s,th_t);
                                                                 }
                                         fprintf(output,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,tu,tb,ts,tn,tub,tubs,tubn,tt,tus);
                                         fprintf(output1,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,th_u,th_b,th_s,th_n,th_ub,th_ubs,th_ubn,th_t,th_us);
                                         fprintf(output2,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,l_u,l_b,l_s,l_n,l_ub,l_ubs,l_ubn,l_t,l_us);
                                         }
              }
/*-------------------------------METHOD ONE-------------------------------------*/
if(choice==1){
              double cutoff=2.0*blg*1.0E-10;
			  double kappa_tauu; // U only 
			  double kappa_tausu; // U+S only
			  //double kappa_tauu; // U only 
			  //double kappa_tausu; // U+S only
			 // double cutoff=2.0*blg*1.0E-10; // 2a, the smallest mean free path in the crystal structure
			  double sigma; // smearing parameter 
			  FILE *output00; 
			  char file00[128];
			  // CVV =0.000000;
			  printf("Temperature(K)\tkappa_u_int(SI)\tkappa_us_int(SI)\n");
              for(T=T_s;T<=T_f;T=T+step){
                                         /*Total thermal conductivity, relaxation time and mean free path*/
                                         th_t=0.000000;
                                         tt=0.00000;
                                         l_t=0.000000;
                                         /*U-procress*/
                                         th_u=0.000000;
                                         tu=0.000000;
                                         l_u=0.000000;
                                         /* Boundary scattering*/
                                         th_b=0.000000;
                                         tb=0.000000;
                                         l_b=0.000000;
                                         /* Isotope scattering*/
                                         th_s=0.000000;
                                         ts=0.000000;
                                         l_s=0.000000;
                                         /* N-Procress*/
                                         th_n=0.000000;
                                         tn=0.000000;
                                         l_n=0.000000;
                                         /*Composite relaxation time*/
                                         //Boundary+U-process
                                         th_ub=0.000000;
                                         tub=0.000000;
                                         l_ub=0.000000;
                                         // Boundary+U-process+Isotope
                                         th_ubs=0.000000;
                                         tubs=0.000000;
                                         l_ubs=0.000000;
                                         //Boundary+U-process+N-process
                                         th_ubn=0.000000;
                                         tubn=0.000000;
                                         l_ubn=0.000000;
                                         // U-process + Isotope
                                         th_us=0.000000;
                                         tus=0.000000;
                                         l_us=0.000000;
                                         CVV = 0.000000;
                                         sprintf(file00,"out/phonon_thermal_conductivity/Spectrum_raw_%d",(int)T);
//										 output00=fopen(file00,"w");
										 output00 = WriteFile (file00);
										 for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre1 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  CVV += weight[i]*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                                         }
                                                                                                  }
                                                                 }
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                fre=omega[i]*2.0*PI*pow(10.0,12);
                                                                                                // Calculating the relaxation time
                                                                                                /* Boundary scattering*/
                                                                                                if(v_g[i]!=0.000000){
																								                    tau_b=d*pow(10.0,-3.0)/((v_g[i]*2.0*PI));
                                                                                                                    if(tau_b*v_g[i]<cutoff){
                                                                                                                                            tau_b=cutoff/v_g[i];
                                                                                                                                           }
																													}
																								else if(v_g[i]==0.000000){
																								                         tau_b=1.0E-10;
																														 }
                                                                                                if(options==1){
                                                                                                /* Impurity scattering*/
                                                                                                               invtau_s=0.00000000;
                                                                                                               for(q=0;q<elements;q++){
                                                                                                                                       invtau_s += 1.0/(4.0*PI*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)/(V_a*im_c[q]*f(fre)*f(fre)));
                                                                                                                                       }
                                                                                                               if(v_g[i]!=0.000000){
																											                        tau_s=1.0/invtau_s;
                                                                                                                                    if(tau_s*v_g[i]<cutoff){
                                                                                                                                                            tau_s=cutoff/v_g[i];
                                                                                                                                                           }
																																	}
																											    else if(v_g[i]==0.000000){
																												                         tau_s=1.0E-7;  // emiprical parameter
																																		 }
                                                                                                               }
                                                                                                else if(options==2){
                                                                                                                    tau_s=99999999.0;
                                                                                                                    }
                                                                                                /* U-process*/
                                                                                               // tau_u=1.9879*(M_av*covmass)*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*g(V_a)*f(Gamma[i])*f(fre)*T);
                                                                                                if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*scaling*f(Gamma[i])*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                     tau_u=1.0E-10;
																													 }
                                                                                                //tau_u=(M_av*covmass)*f(v_g[i]*2.0*PI)*645.0*f(h_r/k_b)/(h_r*f(Gamma[i])*f(fre*h_r/(k_b*T))*f(T)*T*exp(-645.0/(3.0*T)));
                                                                                                /* N-Process*/
                                                                                                // tau_n=1.0/(B_nn*T)+1.0/(B_n*pow(T,3.0)*pow(fre,2.0)*(1.0-exp(-3.0*T/Tdebye)));
                                                                                                tau_n=0.000000;
                                                                                                /* Total relaxation time*/
                                                                                                tau_t=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process*/
                                                                                                tau_ub=1.0/w2(tau_u,tau_b);
                                                                                                /* U-process + isotope */
                                                                                                tau_us=1.0/w2(tau_u,tau_s);
                                                                                                /* Boundary+U-process+Isotope*/
                                                                                                tau_ubs=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process+N-process*/
                                                                                                tau_ubn=1.0/w2(tau_u,tau_b);
                                                                                                /* Mode heat capacity*/
                                                                                                if(omega[i]!=0.000000){
																								                      Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
																													  }
																								else if(omega[i]==0.000000){
																								                           Cv=0.000000;
																														   }
                                                                                                /* Mode heat capacity*/
                                                                                                //Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                                                                                if(omega[i]>0.0&&v_g[i]!=0.0&&v_p[i]!=0.0){
                                                                                                                              integral=(scaling*pow(10.0,-10)/(1.0*2.0*PI))*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,10);
                                                                                                                              // Boundary conductivity
                                                                                                                              th_b += tau_b*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // Isotope conductivity
                                                                                                                              if(options==1){
                                                                                                                              th_s+=tau_s*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                                                  th_s+=(1.0/3.0)*0.000000;
                                                                                                                                                  } 
                                                                                                                              // U-Process
                                                                                                                              th_u+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // N process
                                                                                                                              //th_n+=(1.0/3.0)*tau_n*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*(v_g[i]*2.0*PI)*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,-10);
                                                                                                                              th_n+=(1.0/3.0)*0.000000;
                                                                                                                              // Combined process
                                                                                                                              // 1. Total
                                                                                                                              th_t+=tau_t*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // 2. Boundary +U-process
                                                                                                                              th_ub+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              // 3. Boundary + U-process + Isotope
                                                                                                                              if(options==1){
                                                                                                                              th_ubs+=tau_ubs*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              th_us+=tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              th_ubs+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              th_us+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                                  }
                                                                                                                              // 4. Boundary + U-process + N-process
                                                                                                                              th_ubn+=tau_ubn*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                              /*------------------Total Relaxation Time-----------------------------------*/
                                                                                                                              tt+=tau_t*Cv*weight[i]/CVV;
                                                                                                                              tu+=tau_u*Cv*weight[i]/CVV;
                                                                                                                              tb+=tau_b*Cv*weight[i]/CVV;
                                                                                                                              tn+=tau_n*Cv*weight[i]/CVV;
                                                                                                                              tub+=tau_ub*Cv*weight[i]/CVV;
                                                                                                                              tubn+=tau_ubn*Cv*weight[i]/CVV;
                                                                                                                              kappa_tauu=tau_u*Cv*weight[i]/CVV;
                                                                                                                              //kappa_tausu=
																															  if(options==1){
                                                                                                                              ts+=tau_s*Cv*weight[i]/CVV;
                                                                                                                              tubs+=tau_ubs*Cv*weight[i]/CVV;
                                                                                                                              tus+=tau_us*Cv*weight[i]/CVV;
                                                                                                                              kappa_tausu=tau_us*Cv*weight[i]/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              ts+=tau_s*0.000000;
                                                                                                                              tubs+=tau_ub*Cv*weight[i]/CVV;
                                                                                                                              tus+=tau_u*Cv*weight[i]/CVV;
                                                                                                                              kappa_tausu=tau_u*Cv*weight[i]/CVV;
                                                                                                                                                   }
                                                                                                                              /*-------------------MEAN FREE PATH-----------------------------------------*/
                                                                                                                              /*l_t+=tau_t*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_u+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                                  } */
                                                                                                                              // New definition for MFPs
                                                                                                                              l_t += tau_t*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_u += tau_u*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                                                  } 
                                                                                                                              }
                                                                                                if(T==T_fre&&omega[i]!=0.0){
                                                                                                             cns=(v_g[i]*2.0*PI);
                                                                                                             fprintf(output0,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
																											 fprintf(output3,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u,tau_b,tau_s,tau_n,tau_ub,tau_ubs,tau_ubn,tau_t,tau_us);
                                                                                                             fprintf(output4,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u*cns,tau_b*cns,tau_s*cns,tau_n*cns,tau_ub*cns,tau_ubs*cns,tau_ubn*cns,tau_t*cns,tau_us*cns);
                                                                                                             }
                                                                                                fprintf(output00,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
                                                                                                }
                                                                 fprintf(output7,"%d\t%f\t%le\t%le\t%le\t%le\n",k,T,th_u,th_b,th_s,th_t);
                                                                 }
                                         fprintf(output,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,tu,tb,ts,tn,tub,tubs,tubn,tt,tus);
                                         fprintf(output1,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,th_u,th_b,th_s,th_n,th_ub,th_ubs,th_ubn,th_t,th_us);
                                         fprintf(output2,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,l_u,l_b,l_s,l_n,l_ub,l_ubs,l_ubn,l_t,l_us);
                                         	 //---------------------------------------------------------------------------------------------------------------------------
										 // Read the Spectrum_raw_T data
										 sigma=0.10;
										 double sp_step=0.002;
										 double spfre;
								         double sp_max=50.0; // THz
                                         double sp_min=0.001; // THz;
								         //double sp_step; 
										 double kappa_u, kappa_sumu;
										 double kappa_us, kappa_sumus;
										 double gaussian_norm;
										 double spmax_tmp;
										 double spmax; 
										 double nk;
										 int row00;
										 double *spT, *spph, *spku, *spkus;
										 output00=fopen(file00,"r");
										 FILE *output11;
										 char file11[128];
										 int tmp=0;
                                         while(!feof(output00)){
                                                             fscanf(output00,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                                                             tmp++;
                                                            }
                                         row00=tmp-1;
                                         fclose(output00);
                                         // Allocate memory
                                         spT=(double*)malloc(row00*sizeof(double));
                                         spph=(double*)malloc(row00*sizeof(double));
                                         spku=(double*)malloc(row00*sizeof(double));
                                         spkus=(double*)malloc(row00*sizeof(double));
										 // Import the data
										 output00=fopen(file00,"r");
										 for(i=0;i<row00;i++){
										                      fscanf(output00,"%lf %lf %lf %lf",&(spT[i]),&(spph[i]),&(spku[i]),&(spkus[i]));
															  }
										 fclose(output00);
										 //find the maximum
										 
										 spmax_tmp=0.001;
										 for(i=0;i<row00;i++){
										                      if(spph[i]>spmax_tmp){
															                       spmax_tmp=spph[i];
																				   }
															  //spmax=spmax_tmp;
															  }
										 spmax=spmax_tmp;
										 // Start the calculation for kappa speectrum
										 sprintf(file11,"out/phonon_thermal_conductivity/method%d/Kappa_spectrum_%d.dat",choice,(int)T);
//										 output11=fopen(file11,"w");
										 output11 = WriteFile (file11);
										 fprintf(output11,"Frequency(THz)\tT(K)\tKappa_U(W/m.k)\tKappa_US(W/m.K)\n");
										 //gaussian_norm=0.000000;
										 //kappa_u=0.000000;
										 //kappa_us=0.000000;
										 double kappa_ttu=0.000000;
										 double kappa_ttus=0.000000;
										 for(spfre=sp_min;spfre<=sp_max;spfre=spfre+sp_step){
										                                                    gaussian_norm=0.000000;
										                                                    kappa_sumu=0.000000;
										                                                    kappa_sumus=0.000000;
																							nk=0.000000;
																							for(i=0;i<row00;i++){
																							                    //if(spph[i]!=0.&&fabs(spph[i]-spfre)<=4.0){
										 												                                     //kappa_u+=spku[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //kappa_us+=spkus[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //gaussian_norm+=Gaussian(spph[i],spfre,sigma)*spph[i];
																												if(fabs(spph[i]-spfre)<=4.0){
																															 kappa_sumu += spku[i]*Gaussian(spph[i],spfre,sigma);
										 																					 kappa_sumus += spkus[i]*Gaussian(spph[i],spfre,sigma);
										 																					 gaussian_norm += Gaussian(spph[i],spfre,sigma);
																															 nk=nk+1.000000;
																															 }
																												}
																							//kappa_u=kappa_sumu*(1.0/gaussian_norm)*(1.0/nk);
																							//kappa_us=kappa_sumus*(1.0/gaussian_norm)*(1.0/nk);
																							kappa_u=kappa_sumu*(1.0/nk);
																							kappa_us=kappa_sumus*(1.0/nk);
																							if(spfre>spmax){
																											kappa_u=0.00000;
																									        kappa_us=0.0000;
																											//gaussian_norm=1.00000;
																											//nk=1.0000;
																											} 
																							kappa_ttu += kappa_u*spfre;
																							kappa_ttus += kappa_us*spfre; 
																							fprintf(output11,"%lf\t%lf\t%le\t%le\t%le\t%le\n",spfre,T,kappa_u,kappa_us,nk,gaussian_norm);
																							//fprintf(output11,"%lf\t%lf\t%le\t%le\n",spfre,T,kappa_u/gaussian_norm,kappa_us/gaussian_norm);
										 												   }
								         printf("%f\t%le\t%le\n",T,kappa_ttu,kappa_ttus);	
										 fclose(output11);
										 }
              }
if(choice==5){
              // CVV =0.000000;
              double kappa_tauu; // U only 
			  double kappa_tausu; // U+S only
			  double cutoff=2.0*blg*1.0E-10; // 2a, the smallest mean free path in the crystal structure
			  double sigma; // smearing parameter 
			  FILE *output00; 
			  char file00[128];
			  printf("Temperature(K)\tkappa_u_int(SI)\tkappa_us_int(SI)\n");
              for(T=T_s;T<=T_f;T=T+step){
                                         /*Total thermal conductivity, relaxation time and mean free path*/
                                         th_t=0.000000;
                                         tt=0.00000;
                                         l_t=0.000000;
                                         /*U-procress*/
                                         th_u=0.000000;
                                         tu=0.000000;
                                         l_u=0.000000;
                                         /* Boundary scattering*/
                                         th_b=0.000000;
                                         tb=0.000000;
                                         l_b=0.000000;
                                         /* Isotope scattering*/
                                         th_s=0.000000;
                                         ts=0.000000;
                                         l_s=0.000000;
                                         /* N-Procress*/
                                         th_n=0.000000;
                                         tn=0.000000;
                                         l_n=0.000000;
                                         /*Composite relaxation time*/
                                         //Boundary+U-process
                                         th_ub=0.000000;
                                         tub=0.000000;
                                         l_ub=0.000000;
                                         // Boundary+U-process+Isotope
                                         th_ubs=0.000000;
                                         tubs=0.000000;
                                         l_ubs=0.000000;
                                         //Boundary+U-process+N-process
                                         th_ubn=0.000000;
                                         tubn=0.000000;
                                         l_ubn=0.000000;
                                         // U-process + Isotope
                                         th_us=0.000000;
                                         tus=0.000000;
                                         l_us=0.000000;
                                         CVV = 0.000000;
                                         sprintf(file00,"out/phonon_thermal_conductivity/Spectrum_raw_%d",(int)T);
//										 output00=fopen(file00,"w");
										 output00 = WriteFile (file00);
										 for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre1 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  CVV += weight[i]*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                                         }
                                                                                                  }
                                                                 }
                                        // averages Gruneisen parameter: Acoustic phonons 
										 gammasum_ac=0.000000;
										 for(k=1;k<=3;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre2 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  gammasum_ac += Gamma[i]*weight[i]*N_a*k_b*(h_r*fre2/(k_b*T))*(h_r*fre2/(k_b*T))*exp(h_r*fre2/(k_b*T))/((exp(h_r*fre2/(k_b*T))-1.0)*(exp(h_r*fre2/(k_b*T))-1.0));
																														 }                         
                                                                                                  }
                                                                 }
										 gammaave_ac=gammasum_ac/CVV;
										  // averages Gruneisen parameter: Optical phonons
										 gammasum_op=0.000000;
										 for(k=4;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre3 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  gammasum_op += Gamma[i]*weight[i]*N_a*k_b*(h_r*fre3/(k_b*T))*(h_r*fre3/(k_b*T))*exp(h_r*fre3/(k_b*T))/((exp(h_r*fre3/(k_b*T))-1.0)*(exp(h_r*fre3/(k_b*T))-1.0));
																														 }                         
                                                                                                  }
                                                                 }
										 gammaave_op=gammasum_op/CVV; 
                                         double tweight=0.000000;
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                fre=omega[i]*2.0*PI*pow(10.0,12);
                                                                                                // Calculating the relaxation time
                                                                                                /* Boundary scattering*/
                                                                                                if(v_g[i]!=0.000000){
																								                    tau_b=d*pow(10.0,-3.0)/((v_g[i]*2.0*PI));
                                                                                                                    if(tau_b*v_g[i]<cutoff){
                                                                                                                                            tau_b=cutoff/v_g[i];
                                                                                                                                           }
																													}
																								else if(v_g[i]==0.000000){
																								                         tau_b=1.0E-10;
																														 }
                                                                                                if(options==1){
                                                                                                /* Impurity scattering*/
                                                                                                               invtau_s=0.00000000;
                                                                                                               for(q=0;q<elements;q++){
                                                                                                                                       invtau_s += 1.0/(4.0*PI*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)/(V_a*im_c[q]*f(fre)*f(fre)));
                                                                                                                                       }
                                                                                                               if(v_g[i]!=0.000000){
																											                        tau_s=1.0/invtau_s;
                                                                                                                                    if(tau_s*v_g[i]<cutoff){
                                                                                                                                                            tau_s=cutoff/v_g[i];
                                                                                                                                                           }
																																	}
																											    else if(v_g[i]==0.000000){
																												                         tau_s=1.0E-7;  // emiprical parameter
																																		 }
                                                                                                               }
                                                                                                else if(options==2){
                                                                                                                    tau_s=99999999.0;
                                                                                                                    }
                                                                                                /* U-process*/
                                                                                               // tau_u=1.9879*(M_av*covmass)*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*g(V_a)*f(Gamma[i])*f(fre)*T);
                                                                                               /* if(k<=3){
																								         if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*scaling*f(gammaave_ac)*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								        else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                                                                    tau_u=1.0E-10;
																													                                               }
																										}
																								else if(k>=4){
																								         if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*scaling*f(gammaave_op)*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								        else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                                                                    tau_u=1.0E-10;
																													                                               }
																										} */
																							    if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*scaling*f(Gamma[i])*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                     tau_u=1.0E-10;
																													 }
                                                                                                //tau_u=(M_av*covmass)*f(v_g[i]*2.0*PI)*645.0*f(h_r/k_b)/(h_r*f(Gamma[i])*f(fre*h_r/(k_b*T))*f(T)*T*exp(-645.0/(3.0*T)));
                                                                                                /* N-Process*/
                                                                                                // tau_n=1.0/(B_nn*T)+1.0/(B_n*pow(T,3.0)*pow(fre,2.0)*(1.0-exp(-3.0*T/Tdebye)));
                                                                                                tau_n=0.000000;
                                                                                                /* Total relaxation time*/
                                                                                                tau_t=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process*/
                                                                                                tau_ub=1.0/w2(tau_u,tau_b);
                                                                                                /* U-process + isotope */
                                                                                                tau_us=1.0/w2(tau_u,tau_s);
                                                                                                /* Boundary+U-process+Isotope*/
                                                                                                tau_ubs=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process+N-process*/
                                                                                                tau_ubn=1.0/w2(tau_u,tau_b);
                                                                                                /* Mode heat capacity*/
                                                                                                if(omega[i]!=0.000000){
																								                      Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
																													  }
																								else if(omega[i]==0.000000){
																								                           Cv=0.000000;
																														   }
                                                                                                /* Mode heat capacity*/
                                                                                                // Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                                                                                if(omega[i]>0.0&&v_g[i]!=0.0&&v_p[i]!=0.0){
                                                                                                                              integral=(scaling*pow(10.0,-10)/(1.0*2.0*PI))*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,10);
                                                                                                                              tweight += weight[i];
																															  // Boundary conductivity
                                                                                                                              th_b += tau_b*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              // Isotope conductivity
                                                                                                                              if(options==1){
                                                                                                                              th_s+=tau_s*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                                                  th_s+=(1.0/3.0)*0.000000;
                                                                                                                                                  } 
                                                                                                                              // U-Process
                                                                                                                              th_u+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              kappa_tauu=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
																															  // N process
                                                                                                                              //th_n+=(1.0/3.0)*tau_n*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*(v_g[i]*2.0*PI)*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,-10);
                                                                                                                              th_n+=(1.0/3.0)*0.000000;
                                                                                                                              // Combined process
                                                                                                                              // 1. Total
                                                                                                                              th_t+=tau_t*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              // 2. Boundary +U-process
                                                                                                                              th_ub+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              // 3. Boundary + U-process + Isotope
                                                                                                                              if(options==1){
                                                                                                                              th_ubs+=tau_ubs*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              th_us+=tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              kappa_tausu=tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              th_ubs+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              th_us+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              kappa_tausu=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                                                  }
                                                                                                                              // 4. Boundary + U-process + N-process
                                                                                                                              th_ubn+=tau_ubn*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              /*------------------Total Relaxation Time-----------------------------------*/
                                                                                                                              tt+=tau_t*Cv*weight[i]/CVV;
                                                                                                                              tu+=tau_u*Cv*weight[i]/CVV;
                                                                                                                              tb+=tau_b*Cv*weight[i]/CVV;
                                                                                                                              tn+=tau_n*Cv*weight[i]/CVV;
                                                                                                                              tub+=tau_ub*Cv*weight[i]/CVV;
                                                                                                                              tubn+=tau_ubn*Cv*weight[i]/CVV;
                                                                                                                              if(options==1){
                                                                                                                              ts+=tau_s*Cv*weight[i]/CVV;
                                                                                                                              tubs+=tau_ubs*Cv*weight[i]/CVV;
                                                                                                                              tus+=tau_us*Cv*weight[i]/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              ts+=tau_s*0.000000;
                                                                                                                              tubs+=tau_ub*Cv*weight[i]/CVV;
                                                                                                                              tus+=tau_u*Cv*weight[i]/CVV;
                                                                                                                                                   }
                                                                                                                              /*-------------------MEAN FREE PATH-----------------------------------------*/
                                                                                                                              /*l_t+=tau_t*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_u+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                                  } */
                                                                                                                              // New definition for MFPs
                                                                                                                              l_t += tau_t*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_u += tau_u*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                                                  } 
                                                                                                                              }
                                                                                                if(T==T_fre&&omega[i]!=0.0){
                                                                                                             cns=(v_g[i]*2.0*PI);
                                                                                                             fprintf(output0,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
																											 fprintf(output3,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u,tau_b,tau_s,tau_n,tau_ub,tau_ubs,tau_ubn,tau_t,tau_us);
                                                                                                             fprintf(output4,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u*cns,tau_b*cns,tau_s*cns,tau_n*cns,tau_ub*cns,tau_ubs*cns,tau_ubn*cns,tau_t*cns,tau_us*cns);
                                                                                                             }
                                                                                                fprintf(output00,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
                                                                                                // spectrum function calculation
																								//sigma=0.50;
																								//sp_step=0.05;
																								//double kappa_u;
																								//double kappa_us;
																								//double gaussian_norm;
																								//gaussian_norm=0.000000;
																								//for(spfre=sp_min;spfre<=sp_max;spfre=spfre+sp_step){
																								//                                                   if(fabs(omega[i]-sp_step)<=2.0){
																								//												                                     kappa_u+=kappa_tauu*Gaussian(spfre,omega[i],sigma);
																								//																					 kappa_us+=kappa_tauus*Gaussian(spfre,omega[i],sigma);
																								//																					 gaussian_norm+=Gaussian(spfre,omega[i],sigma);
																								//																					}
																								//												  
																								//												   }
                                                                                                }
                                                                 fprintf(output7,"%d\t%f\t%le\t%le\t%le\t%le\n",k,T,th_u,th_b,th_s,th_t);
                                                                 }
                                         fclose(output00);
                                         fprintf(output,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,tu/tweight,tb/tweight,ts/tweight,tn/tweight,tub/tweight,tubs/tweight,tubn/tweight,tt/tweight,tus/tweight);
                                         fprintf(output1,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,th_u,th_b,th_s,th_n,th_ub,th_ubs,th_ubn,th_t,th_us);
                                         fprintf(output2,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,l_u,l_b,l_s,l_n,l_ub,l_ubs,l_ubn,l_t,l_us);
                                         // spectrum function calculation
										 //---------------------------------------------------------------------------------------------------------------------------
										 // Read the Spectrum_raw_T data
										 sigma=0.10;
										 double sp_step=0.01;
										 double spfre;
								         double sp_max=30.0; // THz
                                         double sp_min=0.; // THz;
								         //double sp_step; 
										 double kappa_sumu, kappa_u;
										 double kappa_sumus, kappa_us;
										 double gaussian_norm;
										 double spmax_tmp;
										 double spmax;
										 double nk; 
										 int row00;
										 double *spT, *spph, *spku, *spkus;
										 output00=fopen(file00,"r");
										 FILE *output11;
										 char file11[128];
										 int tmp=0;
                                         while(!feof(output00)){
                                                             fscanf(output00,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                                                             tmp++;
                                                            }
                                         row00=tmp-1;
                                         fclose(output00);
                                         // Allocate memory
                                         spT=(double*)malloc(row00*sizeof(double));
                                         spph=(double*)malloc(row00*sizeof(double));
                                         spku=(double*)malloc(row00*sizeof(double));
                                         spkus=(double*)malloc(row00*sizeof(double));
										 // Import the data
										 output00=fopen(file00,"r");
										 for(i=0;i<row00;i++){
										                      fscanf(output00,"%lf %lf %lf %lf",&(spT[i]),&(spph[i]),&(spku[i]),&(spkus[i]));
															  }
										 fclose(output00);
										 //find the maximum
										 
										 spmax_tmp=0.001;
										 for(i=0;i<row00;i++){
										                      if(spph[i]>spmax_tmp){
															                       spmax_tmp=spph[i];
																				   }
															  //spmax=spmax_tmp;
															  }
										 spmax=spmax_tmp;
										 // Start the calculation for kappa speectrum
										 sprintf(file11,"out/phonon_thermal_conductivity/method%d/Kappa_spectrum_%d.dat",choice,(int)T);
//										 output11=fopen(file11,"w");
										 output11 = WriteFile (file11);
										 fprintf(output11,"Frequency(THz)\tT(K)\tKappa_U(W/m.k)\tKappa_US(W/m.K)\n");
										 //gaussian_norm=0.000000;
										 //kappa_u=0.000000;
										 //kappa_us=0.000000;
										 double kappa_ttu=0.000000;
										 double kappa_ttus=0.000000;
										 for(spfre=sp_min;spfre<=sp_max;spfre=spfre+sp_step){
										                                                    gaussian_norm=0.000000;
										                                                    kappa_sumu=0.000000;
										                                                    kappa_sumus=0.000000;
																							nk=0.000000;
																							for(i=0;i<row00;i++){
																							                    //if(spph[i]!=0.&&fabs(spph[i]-spfre)<=4.0){
										 												                                     //kappa_u+=spku[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //kappa_us+=spkus[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //gaussian_norm+=Gaussian(spph[i],spfre,sigma)*spph[i];
																												if(fabs(spph[i]-spfre)<=4.0){
																															 kappa_sumu += spku[i]*Gaussian(spph[i],spfre,sigma);
										 																					 kappa_sumus += spkus[i]*Gaussian(spph[i],spfre,sigma);
										 																					 gaussian_norm += Gaussian(spph[i],spfre,sigma);
																															 nk=nk+1.000000;
																															 }
																												}
																							//kappa_u=kappa_sumu*(1.0/gaussian_norm)*(1.0/nk);
																							//kappa_us=kappa_sumus*(1.0/gaussian_norm)*(1.0/nk);
																							//kappa_u=kappa_sumu*(1.0/nk);
																							//kappa_us=kappa_sumus*(1.0/nk);
																							kappa_u=kappa_sumu;
																							kappa_us=kappa_sumus;
																							if(spfre>spmax){
																											kappa_u=0.00000;
																									        kappa_us=0.0000;
																											//gaussian_norm=1.00000;
																											//nk=1.0000;
																											} 
																							kappa_ttu += kappa_u*spfre;
																							kappa_ttus += kappa_us*spfre; 
																							fprintf(output11,"%lf\t%lf\t%le\t%le\t%le\t%le\n",spfre,T,kappa_u,kappa_us,nk,gaussian_norm);
										 												   }
										 printf("%f\t%le\t%le\n",T,kappa_ttu,kappa_ttus);
										 fclose(output11);
                                         }
              }
//-----------------------------------------------------------------------------------------------------------
// Integration form of method 5
if(choice==7){
              // CVV =0.000000;
              double kappa_tauu; // U only 
			  double kappa_tausu; // U+S only
			  double cutoff=2.0*blg*1.0E-10; // 2a, the smallest mean free path in the crystal structure 
			  double sigma; // smearing parameter 
			  FILE *output00; 
			  char file00[128];
			  printf("Temperature(K)\tkappa_u_int(SI)\tkappa_us_int(SI)\n");
			  for(T=T_s;T<=T_f;T=T+step){
                                         /*Total thermal conductivity, relaxation time and mean free path*/
                                         th_t=0.000000;
                                         tt=0.00000;
                                         l_t=0.000000;
                                         /*U-procress*/
                                         th_u=0.000000;
                                         tu=0.000000;
                                         l_u=0.000000;
                                         /* Boundary scattering*/
                                         th_b=0.000000;
                                         tb=0.000000;
                                         l_b=0.000000;
                                         /* Isotope scattering*/
                                         th_s=0.000000;
                                         ts=0.000000;
                                         l_s=0.000000;
                                         /* N-Procress*/
                                         th_n=0.000000;
                                         tn=0.000000;
                                         l_n=0.000000;
                                         /*Composite relaxation time*/
                                         //Boundary+U-process
                                         th_ub=0.000000;
                                         tub=0.000000;
                                         l_ub=0.000000;
                                         // Boundary+U-process+Isotope
                                         th_ubs=0.000000;
                                         tubs=0.000000;
                                         l_ubs=0.000000;
                                         //Boundary+U-process+N-process
                                         th_ubn=0.000000;
                                         tubn=0.000000;
                                         l_ubn=0.000000;
                                         // U-process + Isotope
                                         th_us=0.000000;
                                         tus=0.000000;
                                         l_us=0.000000;
                                         CVV = 0.000000;
                                         sprintf(file00,"out/phonon_thermal_conductivity/Spectrum_raw_%d",(int)T);
//										 output00=fopen(file00,"w");
										 output00 = WriteFile (file00);
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre1 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  CVV += ((scaling*pow(10.0,-10)/(1.0*2.0*PI)))*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,10)*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                                         }
                                                                                                  }
                                                                 }
                                        // averages Gruneisen parameter: Acoustic phonons 
										 gammasum_ac=0.000000;
										 for(k=1;k<4;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre2 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  gammasum_ac += Gamma[i]*weight[i]*N_a*k_b*(h_r*fre2/(k_b*T))*(h_r*fre2/(k_b*T))*exp(h_r*fre2/(k_b*T))/((exp(h_r*fre2/(k_b*T))-1.0)*(exp(h_r*fre2/(k_b*T))-1.0));
																														 }                         
                                                                                                  }
                                                                 }
										 gammaave_ac=gammasum_ac/CVV;
										  // averages Gruneisen parameter: Optical phonons
										 gammasum_op=0.000000;
										 for(k=4;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre3 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  gammasum_op += Gamma[i]*weight[i]*N_a*k_b*(h_r*fre3/(k_b*T))*(h_r*fre3/(k_b*T))*exp(h_r*fre3/(k_b*T))/((exp(h_r*fre3/(k_b*T))-1.0)*(exp(h_r*fre3/(k_b*T))-1.0));
																														 }                         
                                                                                                  }
                                                                 }
										 gammaave_op=gammasum_op/CVV; 
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                fre=omega[i]*2.0*PI*pow(10.0,12);
                                                                                                // Calculating the relaxation time
                                                                                                /* Boundary scattering*/
                                                                                                if(v_g[i]!=0.000000){
																								                    tau_b=d*pow(10.0,-3.0)/((v_g[i]*2.0*PI));
                                                                                                                    if(tau_b*v_g[i]<cutoff){
                                                                                                                                            tau_b=cutoff/v_g[i];
                                                                                                                                           }
																													}
																								else if(v_g[i]==0.000000){
																								                         tau_b=1.0E-10;
																														 }
                                                                                                if(options==1){
                                                                                                /* Impurity scattering*/
                                                                                                               invtau_s=0.00000000;
                                                                                                               for(q=0;q<elements;q++){
                                                                                                                                       invtau_s += 1.0/(4.0*PI*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)/(V_a*im_c[q]*f(fre)*f(fre)));
                                                                                                                                       }
                                                                                                               if(v_g[i]!=0.000000){
																											                        tau_s=1.0/invtau_s;
                                                                                                                                    if(tau_s*v_g[i]<cutoff){
                                                                                                                                                            tau_s=cutoff/v_g[i];
                                                                                                                                                           }
																																	}
																											    else if(v_g[i]==0.000000){
																												                         tau_s=1.0E-7;  // emiprical parameter
																																		 }
                                                                                                               }
                                                                                                else if(options==2){
                                                                                                                    tau_s=99999999.0;
                                                                                                                    }
                                                                                                /* U-process*/
                                                                                               // tau_u=1.9879*(M_av*covmass)*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*g(V_a)*f(Gamma[i])*f(fre)*T);
                                                                                              /*   if(k<4){
																								         if(omega[i]!=0.&&v_g[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_g[i]*v_g[i]*4.0*PI*PI)/(k_b*scaling*f(gammaave_ac)*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								        else if(omega[i]==0.||v_g[i]==0.){
																								                                         tau_u=1.0E-10;
																													                     }
																										}
																								else if(k>=4){
																								         if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_g[i]*v_g[i]*4.0*PI*PI)/(k_b*scaling*f(gammaave_op)*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								        else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                                                                    tau_u=1.0E-10;
																													                                               }
																										} */
																								if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*scaling*f(Gamma[i])*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                     tau_u=1.0E-10;
																													 }
                                                                                                //tau_u=(M_av*covmass)*f(v_g[i]*2.0*PI)*645.0*f(h_r/k_b)/(h_r*f(Gamma[i])*f(fre*h_r/(k_b*T))*f(T)*T*exp(-645.0/(3.0*T)));
                                                                                                /* N-Process*/
                                                                                                // tau_n=1.0/(B_nn*T)+1.0/(B_n*pow(T,3.0)*pow(fre,2.0)*(1.0-exp(-3.0*T/Tdebye)));
                                                                                                tau_n=0.000000;
                                                                                                /* Total relaxation time*/
                                                                                                tau_t=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process*/
                                                                                                tau_ub=1.0/w2(tau_u,tau_b);
                                                                                                /* U-process + isotope */
                                                                                                tau_us=1.0/w2(tau_u,tau_s);
                                                                                                /* Boundary+U-process+Isotope*/
                                                                                                tau_ubs=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process+N-process*/
                                                                                                tau_ubn=1.0/w2(tau_u,tau_b);
                                                                                                /* Mode heat capacity*/
                                                                                                if(omega[i]!=0.000000){
																								                      Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
																													  }
																								else if(omega[i]==0.000000){
																								                           Cv=0.000000;
																														   }
                                                                                                // Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                                                                                //if(omega[i]>=0.0&&v_g[i]!=0.0&&v_p[i]!=0.0){
                                                                                                if(omega[i]!=0.00000){
																								//}
                                                                                                                              integral=(scaling*pow(10.0,-10)/(1.0*2.0*PI))*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,10);
                                                                                                                              // Boundary conductivity
                                                                                                                              th_b += tau_b*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              // Isotope conductivity
                                                                                                                              if(options==1){
                                                                                                                              th_s+=tau_s*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                                                  th_s+=(1.0/3.0)*0.000000;
                                                                                                                                                  } 
                                                                                                                              // U-Process
                                                                                                                              th_u+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              kappa_tauu=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
																															  // N process
                                                                                                                              //th_n+=(1.0/3.0)*tau_n*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*(v_g[i]*2.0*PI)*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,-10);
                                                                                                                              th_n+=(1.0/3.0)*0.000000;
                                                                                                                              // Combined process
                                                                                                                              // 1. Total
                                                                                                                              th_t+=tau_t*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              // 2. Boundary +U-process
                                                                                                                              th_ub+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              // 3. Boundary + U-process + Isotope
                                                                                                                              if(options==1){
                                                                                                                              th_ubs+=tau_ubs*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              th_us+=tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              kappa_tausu=tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              th_ubs+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              th_us+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              kappa_tausu=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
																																				  }
                                                                                                                              // 4. Boundary + U-process + N-process
                                                                                                                              th_ubn+=tau_ubn*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              /*------------------Total Relaxation Time-----------------------------------*/
                                                                                                                              tt+=tau_t*Cv*integral/CVV;
                                                                                                                              tu+=tau_u*Cv*integral/CVV;
                                                                                                                              tb+=tau_b*Cv*integral/CVV;
                                                                                                                              tn+=tau_n*Cv*integral/CVV;
                                                                                                                              tub+=tau_ub*Cv*integral/CVV;
                                                                                                                              tubn+=tau_ubn*Cv*integral/CVV;
                                                                                                                              if(options==1){
                                                                                                                              ts+=tau_s*Cv*integral/CVV;
                                                                                                                              tubs+=tau_ubs*Cv*integral/CVV;
                                                                                                                              tus+=tau_us*Cv*integral/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              ts+=tau_s*0.000000;
                                                                                                                              tubs+=tau_ub*Cv*integral/CVV;
                                                                                                                              tus+=tau_u*Cv*integral/CVV;
                                                                                                                                                   }
                                                                                                                              /*-------------------MEAN FREE PATH-----------------------------------------*/
                                                                                                                              /*l_t+=tau_t*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_u+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                                  } */
                                                                                                                              // New definition for MFPs
                                                                                                                              l_t += tau_t*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_u += tau_u*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                                                  } 
                                                                                                                              }
                                                                                                if(T==T_fre&&omega[i]!=0.0){
                                                                                                             cns=(v_g[i]*2.0*PI);
                                                                                                             fprintf(output0,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
																											 fprintf(output3,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u,tau_b,tau_s,tau_n,tau_ub,tau_ubs,tau_ubn,tau_t,tau_us);
                                                                                                             fprintf(output4,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u*cns,tau_b*cns,tau_s*cns,tau_n*cns,tau_ub*cns,tau_ubs*cns,tau_ubn*cns,tau_t*cns,tau_us*cns);
                                                                                                             }
                                                                                                fprintf(output00,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
                                                                                                }
                                                                 fprintf(output7,"%d\t%f\t%le\t%le\t%le\t%le\n",k,T,th_u,th_b,th_s,th_t);
                                                                 }
                                         fprintf(output,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,tu,tb,ts,tn,tub,tubs,tubn,tt,tus);
                                         fprintf(output1,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,th_u,th_b,th_s,th_n,th_ub,th_ubs,th_ubn,th_t,th_us);
                                         fprintf(output2,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,l_u,l_b,l_s,l_n,l_ub,l_ubs,l_ubn,l_t,l_us);
                                         // spectrum function calculation
										 //---------------------------------------------------------------------------------------------------------------------------
										 // Read the Spectrum_raw_T data
										 sigma=0.10;
										 double sp_step=0.002;
										 double spfre;
								         double sp_max=30.0; // THz
                                         double sp_min=0.001; // THz;
								         //double sp_step; 
										 double kappa_u, kappa_sumu;
										 double kappa_us, kappa_sumus;
										 double gaussian_norm;
										 double spmax_tmp;
										 double spmax; 
										 double nk;
										 int row00;
										 double *spT, *spph, *spku, *spkus;
										 output00=fopen(file00,"r");
										 FILE *output11;
										 char file11[128];
										 int tmp=0;
                                         while(!feof(output00)){
                                                             fscanf(output00,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                                                             tmp++;
                                                            }
                                         row00=tmp-1;
                                         fclose(output00);
                                         // Allocate memory
                                         spT=(double*)malloc(row00*sizeof(double));
                                         spph=(double*)malloc(row00*sizeof(double));
                                         spku=(double*)malloc(row00*sizeof(double));
                                         spkus=(double*)malloc(row00*sizeof(double));
										 // Import the data
										 output00=fopen(file00,"r");
										 for(i=0;i<row00;i++){
										                      fscanf(output00,"%lf %lf %lf %lf",&(spT[i]),&(spph[i]),&(spku[i]),&(spkus[i]));
															  }
										 fclose(output00);
										 //find the maximum
										 
										 spmax_tmp=0.001;
										 for(i=0;i<row00;i++){
										                      if(spph[i]>spmax_tmp){
															                       spmax_tmp=spph[i];
																				   }
															  //spmax=spmax_tmp;
															  }
										 spmax=spmax_tmp;
										 // Start the calculation for kappa speectrum
										 sprintf(file11,"out/phonon_thermal_conductivity/method%d/Kappa_spectrum_%d.dat",choice,(int)T);
//										 output11=fopen(file11,"w");
										 output11 = WriteFile (file11);
										 fprintf(output11,"Frequency(THz)\tT(K)\tKappa_U(W/m.k)\tKappa_US(W/m.K)\n");
										 //gaussian_norm=0.000000;
										 //kappa_u=0.000000;
										 //kappa_us=0.000000;
										 double kappa_ttu=0.000000;
										 double kappa_ttus=0.000000;
										 for(spfre=sp_min;spfre<=sp_max;spfre=spfre+sp_step){
										                                                    gaussian_norm=0.000000;
										                                                    kappa_sumu=0.000000;
										                                                    kappa_sumus=0.000000;
																							nk=0.000000;
																							for(i=0;i<row00;i++){
																							                    //if(spph[i]!=0.&&fabs(spph[i]-spfre)<=4.0){
										 												                                     //kappa_u+=spku[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //kappa_us+=spkus[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //gaussian_norm+=Gaussian(spph[i],spfre,sigma)*spph[i];
																												if(fabs(spph[i]-spfre)<=4.0){
																															 kappa_sumu += spku[i]*Gaussian(spph[i],spfre,sigma);
										 																					 kappa_sumus += spkus[i]*Gaussian(spph[i],spfre,sigma);
										 																					 gaussian_norm += Gaussian(spph[i],spfre,sigma);
																															 nk=nk+1.000000;
																															 }
																												}
																							//kappa_u=kappa_sumu*(1.0/gaussian_norm)*(1.0/nk);
																							//kappa_us=kappa_sumus*(1.0/gaussian_norm)*(1.0/nk);
																							//kappa_u=kappa_sumu*(1.0/nk);
																							//kappa_us=kappa_sumus*(1.0/nk);
																							kappa_u=kappa_sumu;
																							kappa_us=kappa_sumus;
																							if(spfre>spmax){
																											kappa_u=0.00000;
																									        kappa_us=0.0000;
																											//gaussian_norm=1.00000;
																											//nk=1.0000;
																											} 
																							kappa_ttu += kappa_u*sp_step;
																							kappa_ttus += kappa_us*sp_step; 
																							fprintf(output11,"%lf\t%lf\t%le\t%le\t%le\t%le\n",spfre,T,kappa_u,kappa_us,nk,gaussian_norm);
										 												   }
										 printf("%f\t%le\t%le\n",T,kappa_ttu,kappa_ttus);
										 fclose(output11);
										 }
              }
/*------------------------------METHOD THREE------------------------------------*/
double kappa_col, kappa_kin; //Collective and kinetic parts
double kappa_t; // Total
double switch_f; // from collective to kinetic
double avetau_n, avetau_r; // Normal and resisitive scattering mechanisms
double sumtau_n, sumtau_r, sumnormal;
double sumcol, normal_col;
double invsumtau_r, invavetau_r;
double avev_g, sumv_g, normalv_g; // Average group velocity
double Cvv;
double Cvq;
double sumsqare_q, normal_q;
double avesqare_q; 
double Feff;
double fx, fy, fz, fu;
double ave_l;
FILE *output5;
FILE *output6;
if(choice==3){
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/KCM_conducitvity.dat", choice);
              output5=fopen(filename,"w");
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/KCM_relaxation_time.dat", choice);
              output6=fopen(filename,"w");
              fprintf(output5,"T(K)\tAve_vg(m/s)\tkappa_col(W/m.K)\tkappa_kin(W/m.K)\tkappa(W/m.K)\tSwitch_factor\n");
              fprintf(output6,"T(K)\tavetau_n(s)\tavetau_r(s)\n");
              for(T=T_s;T<=T_f;T=T+step){
                                         // Frequency Averaged phonon wave vectors
                                         sumsqare_q=0.000000;
                                         normal_q=0.000000;
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  Cvq = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                                                                                  if(omega[i]>0.0&&v_g[i]!=0.0){
                                                                                                                                sumsqare_q+=Cvq*(kpoint[i]*kpoint[i])*weight[i];
                                                                                                                                normal_q+=Cvq*weight[i];
                                                                                                                                }
                                                                                                  }
                                                                 }
                                         avesqare_q=sumsqare_q/normal_q;                                                              
                                         /*Total thermal conductivity, relaxation time and mean free path*/
                                         kappa_kin=0.000000;
                                         sumnormal=0.00000;
                                         sumtau_n=0.000000;
                                         sumtau_r=0.000000;
                                         sumcol=0.000000;
                                         normal_col=0.000000;
                                         // group velocity
                                         sumv_g=0.000000;
                                         normalv_g=0.000000;
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                fre=omega[i]*2.0*PI*pow(10.0,12.0);
                                                                                                // Calculating the relaxation time
                                                                                                /* Boundary scattering*/
                                                                                                tau_b=d*pow(10.0,-3.0)/(v_g[i]*2.0*PI);
                                                                                                if(options==1){
                                                                                                /* Impurity scattering*/
                                                                                                               invtau_s=0.00000000;
                                                                                                               for(q=0;q<elements;q++){
                                                                                                                                       invtau_s += 1.0/(4.0*PI*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)/(V_a*im_c[q]*f(fre)*f(fre)));
                                                                                                                                       }
                                                                                                               tau_s=1.0/invtau_s;
                                                                                                               }
                                                                                                else if(options==2){
                                                                                                                    tau_s=99999999.0;
                                                                                                                    }
                                                                                                /* U-process*/
                                                                                                tau_u=exp(Textint/T)/(B_u*pow(fre,4.0)*T*(1.0-exp(-3.0*T/Tdebye)));
                                                                                                /* N-Process*/
                                                                                                tau_n=1.0/(B_nn*T)+1.0/(B_n*pow(T,3.0)*pow(fre,2.0)*(1.0-exp(-3.0*T/Tdebye)));
                                                                                                /* Total relaxation time*/
                                                                                                tau_t=1.0/w4(tau_u,tau_n,tau_b,tau_s);
                                                                                                /* Boundary+U-process*/
                                                                                                tau_ub=1.0/w2(tau_u,tau_b);
                                                                                                /* Boundary+U-process+Isotope*/
                                                                                                tau_ubs=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process+N-process*/
                                                                                                tau_ubn=1.0/w3(tau_u,tau_b,tau_n);
                                                                                                /* Mode heat capacity*/
                                                                                                Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                                                                                Cvv= N_a*(h_r*fre/(k_b*T*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                                                                                if(omega[i]>0.0&&v_g[i]!=0.0){
                                                                                                                              integral=(scaling*pow(10.0,-10.0)/(1.0*2.0*PI))*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,10.0);
                                                                                                                              // Normalization factor
                                                                                                                              sumnormal+=Cv*weight[i];
                                                                                                                              // sum of N-scattering
                                                                                                                              sumtau_n+=tau_n*Cv*weight[i];
                                                                                                                              // Kinetic sum term
                                                                                                                              sumcol+=(v_g[i]*2.0*PI)*(kpoint[i]*pow(10.0,10.0))*Cvv*weight[i];
                                                                                                                              // Group velocity
                                                                                                                              sumv_g+=(v_g[i]*2.0*PI)*Cv*weight[i];
                                                                                                                              normalv_g+=Cv*weight[i];
                                                                                                                              if(options==1){
                                                                                                                                              // 1. Total kinetic model
                                                                                                                                             kappa_kin+=tau_ubs*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                             sumtau_r+=tau_ubs*Cv*weight[i];
                                                                                                                                             invsumtau_r+=(1.0/tau_ubs)*Cv*weight[i];
                                                                                                                                             // 2. Collective region
                                                                                                                                             //if(tau_ubs!=0.0){
                                                                                                                                             normal_col+=(1.0/(fre*h_r))*(avesqare_q*pow(10.0,20))*(w3(tau_u,tau_b,tau_s))*Cvv*weight[i];
                                                                                                                                             //                   }
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                                                   // 1. Total kinetic model
                                                                                                                                                  kappa_kin+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i];
                                                                                                                                                  sumtau_r+=tau_ub*Cv*weight[i];
                                                                                                                                                  invsumtau_r+=(1.0/tau_ub)*Cv*weight[i];
                                                                                                                                                  // 2. Collective region
                                                                                                                                                  //if(tau_ub!=0.0){
                                                                                                                                                  normal_col+=(1.0/(fre*h_r))*(avesqare_q*pow(10.0,20.0))*(w2(tau_u,tau_b))*Cvv*weight[i];
                                                                                                                                                  //               }
                                                                                                                                                  }
                                                                                                                              }
                                                                                 //               if(T==T_fre&&omega[i]!=0.0){
                                                                                 //                            cns=(v_g[i]*2.0*PI);
                                                                                 //                            fprintf(output3,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u,tau_b,tau_s,tau_n,tau_ub,tau_ubs,tau_ubn,tau_t);
                                                                                 //                            fprintf(output4,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u*cns,tau_b*cns,tau_s*cns,tau_n*cns,tau_ub*cns,tau_ubs*cns,tau_ubn*cns,tau_t*cns);
                                                                                 //                            }
                                                                                 //               printf("%le\t%le\n",sumcol,normal_col);
                                                                                                }
                                                                 }
                                         avev_g=sumv_g/normalv_g;
                                         avetau_n=sumtau_n/sumnormal; avetau_r=sumtau_r/sumnormal;
                                         invavetau_r=invsumtau_r/sumnormal;
                                         switch_f=1.0/(1.0+avetau_n/avetau_r);
                                         kappa_col=(sumcol*sumcol)/normal_col;
                                         // effective factor
                                         fx=avetau_n/invavetau_r;
                                         ave_l=avev_g*sqrt(fx);
                                         fu=d*pow(10.0,-3.0);
                                         fy=(1.0+4.0*PI*PI*pow(ave_l/fu,2.0));
                                         fz=(1.0/(2.0*PI*PI))*(pow(fu/ave_l,2.0));
                                         Feff=fz*(sqrt(fy)-1.0);
                                         kappa_t=kappa_kin*(1.0-switch_f)+kappa_col*switch_f*Feff;
                                         fprintf(output5,"%f\t%le\t%le\t%le\t%le\t%lf\n",T,avev_g,kappa_col,kappa_kin,kappa_t,switch_f);
                                         fprintf(output6,"%f\t%le\t%le\n",T,avetau_n,avetau_r);
                                         }
              fclose(output5); fclose(output6);
              }
//--------------------------------------------------------------------------------------------------------------------
//---------------------------------METHOD FOUR------------------------------------------------------------------------
// Using Slack model to estimate thermal conductivity
float gamma_ave; // phonon spectrum averaged Gruneisen constant
float gamma_mode;
float A_const; // A constant in Slack model
float kappa; // Thermal conductivity
FILE *output8;
if(choice==4){
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/Slack_kappa_T.dat", choice);
              output8=fopen(filename,"w");
              fprintf(output8,"Temperature(K)\tKappa(W/m.K)\tCv(J/mol.K)\tGamma\n");
              for(T=T_s;T<=T_f;T=T+step){
                                            // Calculate the Gruneisen parameter
                                            CVV = 0.000000; gamma_mode =0.000000;
                                            for(k=2;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  double fre1 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  CVV += (1.0/(float)nkpt)*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                                         //}
                                                                                                  Cv = (1.0/(float)nkpt)*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                  gamma_mode += Gamma[i]*Cv;
                                                                                                                            }
                                                                                                  }
                                                                 }
                                            gamma_ave = gamma_mode/CVV;
                                            // Calculate thermal conductivity by Slack method
                                            A_const = 2.43*pow(10.0,-6.0)/(1.0-(0.514/gamma_ave)+(0.228/(gamma_ave*gamma_ave)));
                                            kappa = A_const*M_av*pow(Tdebye,3.0)*V_av*g((float)N)/(T*pow(gamma_ave,2.0));
                                            fprintf(output8,"%f\t%f\t%f\t%f\n",T,kappa,CVV,gamma_ave);         
                                            }
              fclose(output8);
              }
// Clemensen method
//----------------------------------------------------------------------------------------------------------------------------
//--------------------METHOD\A1\A1SIX\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD\A3\AD 
FILE *output9;
FILE *output10;
double kappa_sum; // total thermal conducivity from all brachnes
double kappa_j; // thermal conductivity of phonon branch j
double gamma2_modej; // square of Gruneisen parameters of branch j
double gamma2_avej;
double vg_sumj;
double vg_avej;
double omega_maxj; // lowest frequency
double omega2_minj; // square highest frequency
double omega_minj;
double omega_ratioj; 
double CVV_j; // heat capacity
double mass_rou;
mass_rou=M_v*covmass/(V*pow(10,-30.0));
if(choice==6){
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/Klemens_kappa_T.dat", choice);
              output9=fopen(filename,"w");
	      sprintf (filename, "out/phonon_thermal_conductivity/method%d/Klemens_kappa_jbranch.dat", choice);
              output10=fopen(filename,"w");
			  fprintf(output9,"Temperature(K)\tKappa(W/m.K)\n");
              fprintf(output10,"Temperature(K)\tomega_max(THz)\tomega_min(THz)\tgamma2_avej\tvg_avej\tKappa(W/m.K)\n");
			  printf("Temperature(K)\tomega_max(THz)\tomega_min(THz)\tgamma2_avej\tvg_avej\tKappa(W/m.K)\n"); 
			  for(T=T_s;T<=T_f;T=T+step){
                                            // Calculate the Gruneisen parameter
                                            kappa_sum=0.000000;
                                            for(k=1;k<=columns;k++){
                                                                 CVV_j = 0.000000; gamma2_modej =0.000000;
																 vg_sumj=0.000000;  
																 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  double fre1 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  CVV_j += (1.0/(float)nkpt)*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                                         //}
                                                                                                  Cv = (1.0/(float)nkpt)*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                  gamma2_modej += Gamma[i]*Gamma[i]*Cv;
                                                                                                  vg_sumj += v_g[i]*Cv; 
																								  // determine the max frequency for each phonon branch   
																													    }
                                                                                                  }
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
																                                  double max_int=0.001;
																                                  if(omega[i]>max_int){
																								                      max_int=omega[i];
																													  }
																								  omega_maxj=max_int;
																								  }
																 // calculate the minimum frequency 
                                                                 gamma2_avej = gamma2_modej/CVV_j;
                                                                 vg_avej=2.0*PI*vg_sumj/CVV_j;
                                                                 omega2_minj=(0.5*covmass*M_v)*(vg_avej*vg_avej*vg_avej)*(8.0*PI*PI*PI)*(omega_maxj*2.0*PI*pow(10.0,12))*(1.0/gamma2_avej)*(1.0/(k_b*T))*(1.0/(d*pow(10.0,-3.0)));
                                                                 omega_minj=sqrt(omega2_minj);
																 omega_ratioj=log(omega_maxj*2.0*PI*pow(10.0,12)/omega_minj);
																 kappa_j=mass_rou*(vg_avej*vg_avej*vg_avej*vg_avej)*(16.0*PI*PI*PI*PI)*omega_ratioj*(1.0/gamma2_avej)*(1.0/(omega_maxj*2.0*PI*pow(10.0,12)))*(1.0/T);
																 kappa_sum += mass_rou*(vg_avej*vg_avej*vg_avej*vg_avej)*(16.0*PI*PI*PI*PI)*omega_ratioj*(1.0/gamma2_avej)*(1.0/(omega_maxj*2.0*PI*pow(10.0,12)))*(1.0/T);
																 fprintf(output10,"%f\t%f\t%f\t%f\t%f\t%f\n",T,omega_maxj,omega_minj/(2.0*PI*pow(10.0,12)),gamma2_avej,vg_avej,kappa_j);
																 printf("%f\t%f\t%f\t%f\t%f\t%f\n",T,omega_maxj,omega_minj/(2.0*PI*pow(10.0,12)),gamma2_avej,vg_avej,kappa_j);
																 }
                                            // Calculate thermal conductivity by Slack method
                                            //A_const = 2.43*pow(10.0,-6.0)/(1.0-(0.514/gamma_ave)+(0.228/(gamma_ave*gamma_ave)));
                                            //kappa = A_const*M_av*pow(Tdebye,3.0)*V_av*g((float)N)/(T*pow(gamma_ave,2.0));
                                            fprintf(output9,"%f\t%f\n",T,kappa_sum);         
                                            }
              fclose(output9); fclose(output10);
              }
//----------------------------------------------------------------------------------------------------------------------
//--------------------------------METHOD EIGHT-------------------------------------------------------------------------- 
if(choice==8){
              // CVV =0.000000;
              double kappa_tauu; // U only 
			  double kappa_tausu; // U+S only
			  double cutoff=2.0*blg*1.0E-10; // 2a, the smallest mean free path in the crystal structure
			  double sigma; // smearing parameter 
			  FILE *output00; 
			  char file00[128];
			  printf("Temperature(K)\tkappa_u_int(SI)\tkappa_us_int(SI)\n");
              for(T=T_s;T<=T_f;T=T+step){
                                         /*Total thermal conductivity, relaxation time and mean free path*/
                                         th_t=0.000000;
                                         tt=0.00000;
                                         l_t=0.000000;
                                         /*U-procress*/
                                         th_u=0.000000;
                                         tu=0.000000;
                                         l_u=0.000000;
                                         /* Boundary scattering*/
                                         th_b=0.000000;
                                         tb=0.000000;
                                         l_b=0.000000;
                                         /* Isotope scattering*/
                                         th_s=0.000000;
                                         ts=0.000000;
                                         l_s=0.000000;
                                         /* N-Procress*/
                                         th_n=0.000000;
                                         tn=0.000000;
                                         l_n=0.000000;
                                         /*Composite relaxation time*/
                                         //Boundary+U-process
                                         th_ub=0.000000;
                                         tub=0.000000;
                                         l_ub=0.000000;
                                         // Boundary+U-process+Isotope
                                         th_ubs=0.000000;
                                         tubs=0.000000;
                                         l_ubs=0.000000;
                                         //Boundary+U-process+N-process
                                         th_ubn=0.000000;
                                         tubn=0.000000;
                                         l_ubn=0.000000;
                                         // U-process + Isotope
                                         th_us=0.000000;
                                         tus=0.000000;
                                         l_us=0.000000;
                                         CVV = 0.000000;
                                         sprintf(file00,"out/phonon_thermal_conductivity/Spectrum_raw_%d",(int)T);
//										 output00=fopen(file00,"w");
										 output00 = WriteFile (file00);
										 for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre1 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  CVV += weight[i]*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                                         }
                                                                                                  }
                                                                 }
                                        // averages Gruneisen parameter: Acoustic phonons 
										 gammasum_ac=0.000000;
										 for(k=1;k<=3;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre2 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  gammasum_ac += Gamma[i]*weight[i]*N_a*k_b*(h_r*fre2/(k_b*T))*(h_r*fre2/(k_b*T))*exp(h_r*fre2/(k_b*T))/((exp(h_r*fre2/(k_b*T))-1.0)*(exp(h_r*fre2/(k_b*T))-1.0));
																														 }                         
                                                                                                  }
                                                                 }
										 gammaave_ac=gammasum_ac/CVV;
										  // averages Gruneisen parameter: Optical phonons
										 gammasum_op=0.000000;
										 for(k=4;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre3 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  gammasum_op += Gamma[i]*weight[i]*N_a*k_b*(h_r*fre3/(k_b*T))*(h_r*fre3/(k_b*T))*exp(h_r*fre3/(k_b*T))/((exp(h_r*fre3/(k_b*T))-1.0)*(exp(h_r*fre3/(k_b*T))-1.0));
																														 }                         
                                                                                                  }
                                                                 }
										 gammaave_op=gammasum_op/CVV; 
                                         double tweight=0.000000;
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                fre=omega[i]*2.0*PI*pow(10.0,12);
                                                                                                // Calculating the relaxation time
                                                                                                /* Boundary scattering*/
                                                                                                if(v_g[i]!=0.000000){
																								                    tau_b=d*pow(10.0,-3.0)/((v_g[i]*2.0*PI));
                                                                                                                    if(tau_b*v_g[i]<cutoff){
                                                                                                                                            tau_b=cutoff/v_g[i];
                                                                                                                                           }
																													}
																								else if(v_g[i]==0.000000){
																								                         tau_b=1.0E-10;
																														 }
                                                                                                if(options==1){
                                                                                                /* Impurity scattering*/
                                                                                                               invtau_s=0.00000000;
                                                                                                               for(q=0;q<elements;q++){
                                                                                                                                       invtau_s += 1.0/(4.0*PI*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)/(V_a*im_c[q]*f(fre)*f(fre)));
                                                                                                                                       }
                                                                                                               if(v_g[i]!=0.000000){
																											                        tau_s=1.0/invtau_s;
                                                                                                                                    if(tau_s*v_g[i]<cutoff){
                                                                                                                                                            tau_s=cutoff/v_g[i];
                                                                                                                                                           }
																																	}
																											    else if(v_g[i]==0.000000){
																												                         tau_s=1.0E-7;  // emiprical parameter
																																		 }
                                                                                                               }
                                                                                                else if(options==2){
                                                                                                                    tau_s=99999999.0;
                                                                                                                    }
                                                                                                /* U-process*/
                                                                                               // tau_u=1.9879*(M_av*covmass)*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*g(V_a)*f(Gamma[i])*f(fre)*T);
                                                                                                if(k<=3){
																								         if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*scaling*f(gammaave_ac)*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								        else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                                                                    tau_u=1.0E-10;
																													                                               }
																										}
																								else if(k>=4){
																								         if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*scaling*f(gammaave_op)*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								        else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                                                                    tau_u=1.0E-10;
																													                                               }
																										}
																							    /*if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*scaling*f(Gamma[i])*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                     tau_u=1.0E-10;
																													 } */
                                                                                                //tau_u=(M_av*covmass)*f(v_g[i]*2.0*PI)*645.0*f(h_r/k_b)/(h_r*f(Gamma[i])*f(fre*h_r/(k_b*T))*f(T)*T*exp(-645.0/(3.0*T)));
                                                                                                /* N-Process*/
                                                                                                // tau_n=1.0/(B_nn*T)+1.0/(B_n*pow(T,3.0)*pow(fre,2.0)*(1.0-exp(-3.0*T/Tdebye)));
                                                                                                tau_n=0.000000;
                                                                                                /* Total relaxation time*/
                                                                                                tau_t=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process*/
                                                                                                tau_ub=1.0/w2(tau_u,tau_b);
                                                                                                /* U-process + isotope */
                                                                                                tau_us=1.0/w2(tau_u,tau_s);
                                                                                                /* Boundary+U-process+Isotope*/
                                                                                                tau_ubs=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process+N-process*/
                                                                                                tau_ubn=1.0/w2(tau_u,tau_b);
                                                                                                /* Mode heat capacity*/
                                                                                                if(omega[i]!=0.000000){
																								                      Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
																													  }
																								else if(omega[i]==0.000000){
																								                           Cv=0.000000;
																														   }
                                                                                                /* Mode heat capacity*/
                                                                                                // Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                                                                                if(omega[i]>0.0&&v_g[i]!=0.0&&v_p[i]!=0.0){
                                                                                                                              integral=(scaling*pow(10.0,-10)/(1.0*2.0*PI))*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,10);
                                                                                                                              tweight += weight[i];
																															  // Boundary conductivity
                                                                                                                              th_b += tau_b*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              // Isotope conductivity
                                                                                                                              if(options==1){
                                                                                                                              th_s+=tau_s*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                                                  th_s+=(1.0/3.0)*0.000000;
                                                                                                                                                  } 
                                                                                                                              // U-Process
                                                                                                                              th_u+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              kappa_tauu=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
																															  // N process
                                                                                                                              //th_n+=(1.0/3.0)*tau_n*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*(v_g[i]*2.0*PI)*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,-10);
                                                                                                                              th_n+=(1.0/3.0)*0.000000;
                                                                                                                              // Combined process
                                                                                                                              // 1. Total
                                                                                                                              th_t+=tau_t*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              // 2. Boundary +U-process
                                                                                                                              th_ub+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              // 3. Boundary + U-process + Isotope
                                                                                                                              if(options==1){
                                                                                                                              th_ubs+=tau_ubs*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              th_us+=tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              kappa_tausu=tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              th_ubs+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              th_us+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              kappa_tausu=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                                                  }
                                                                                                                              // 4. Boundary + U-process + N-process
                                                                                                                              th_ubn+=tau_ubn*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*weight[i]*(Cv/CVV);
                                                                                                                              /*------------------Total Relaxation Time-----------------------------------*/
                                                                                                                              tt+=tau_t*Cv*weight[i]/CVV;
                                                                                                                              tu+=tau_u*Cv*weight[i]/CVV;
                                                                                                                              tb+=tau_b*Cv*weight[i]/CVV;
                                                                                                                              tn+=tau_n*Cv*weight[i]/CVV;
                                                                                                                              tub+=tau_ub*Cv*weight[i]/CVV;
                                                                                                                              tubn+=tau_ubn*Cv*weight[i]/CVV;
                                                                                                                              if(options==1){
                                                                                                                              ts+=tau_s*Cv*weight[i]/CVV;
                                                                                                                              tubs+=tau_ubs*Cv*weight[i]/CVV;
                                                                                                                              tus+=tau_us*Cv*weight[i]/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              ts+=tau_s*0.000000;
                                                                                                                              tubs+=tau_ub*Cv*weight[i]/CVV;
                                                                                                                              tus+=tau_u*Cv*weight[i]/CVV;
                                                                                                                                                   }
                                                                                                                              /*-------------------MEAN FREE PATH-----------------------------------------*/
                                                                                                                              /*l_t+=tau_t*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_u+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                                  } */
                                                                                                                              // New definition for MFPs
                                                                                                                              l_t += tau_t*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_u += tau_u*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*Cv*weight[i]/CVV;
                                                                                                                                                  } 
                                                                                                                              }
                                                                                                if(T==T_fre&&omega[i]!=0.0){
                                                                                                             cns=(v_g[i]*2.0*PI);
                                                                                                             fprintf(output0,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
																											 fprintf(output3,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u,tau_b,tau_s,tau_n,tau_ub,tau_ubs,tau_ubn,tau_t,tau_us);
                                                                                                             fprintf(output4,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u*cns,tau_b*cns,tau_s*cns,tau_n*cns,tau_ub*cns,tau_ubs*cns,tau_ubn*cns,tau_t*cns,tau_us*cns);
                                                                                                             }
                                                                                                fprintf(output00,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
                                                                                                // spectrum function calculation
																								//sigma=0.50;
																								//sp_step=0.05;
																								//double kappa_u;
																								//double kappa_us;
																								//double gaussian_norm;
																								//gaussian_norm=0.000000;
																								//for(spfre=sp_min;spfre<=sp_max;spfre=spfre+sp_step){
																								//                                                   if(fabs(omega[i]-sp_step)<=2.0){
																								//												                                     kappa_u+=kappa_tauu*Gaussian(spfre,omega[i],sigma);
																								//																					 kappa_us+=kappa_tauus*Gaussian(spfre,omega[i],sigma);
																								//																					 gaussian_norm+=Gaussian(spfre,omega[i],sigma);
																								//																					}
																								//												  
																								//												   }
                                                                                                }
                                                                 fprintf(output7,"%d\t%f\t%le\t%le\t%le\t%le\n",k,T,th_u,th_b,th_s,th_t);
                                                                 }
                                         fclose(output00);
                                         fprintf(output,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,tu/tweight,tb/tweight,ts/tweight,tn/tweight,tub/tweight,tubs/tweight,tubn/tweight,tt/tweight,tus/tweight);
                                         fprintf(output1,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,th_u,th_b,th_s,th_n,th_ub,th_ubs,th_ubn,th_t,th_us);
                                         fprintf(output2,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,l_u,l_b,l_s,l_n,l_ub,l_ubs,l_ubn,l_t,l_us);
                                         // spectrum function calculation
										 //---------------------------------------------------------------------------------------------------------------------------
										 // Read the Spectrum_raw_T data
										 sigma=0.10;
										 double sp_step=0.01;
										 double spfre;
								         double sp_max=30.0; // THz
                                         double sp_min=0.; // THz;
								         //double sp_step; 
										 double kappa_sumu, kappa_u;
										 double kappa_sumus, kappa_us;
										 double gaussian_norm;
										 double spmax_tmp;
										 double spmax;
										 double nk; 
										 int row00;
										 double *spT, *spph, *spku, *spkus;
										 output00=fopen(file00,"r");
										 FILE *output11;
										 char file11[128];
										 int tmp=0;
                                         while(!feof(output00)){
                                                             fscanf(output00,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                                                             tmp++;
                                                            }
                                         row00=tmp-1;
                                         fclose(output00);
                                         // Allocate memory
                                         spT=(double*)malloc(row00*sizeof(double));
                                         spph=(double*)malloc(row00*sizeof(double));
                                         spku=(double*)malloc(row00*sizeof(double));
                                         spkus=(double*)malloc(row00*sizeof(double));
										 // Import the data
										 output00=fopen(file00,"r");
										 for(i=0;i<row00;i++){
										                      fscanf(output00,"%lf %lf %lf %lf",&(spT[i]),&(spph[i]),&(spku[i]),&(spkus[i]));
															  }
										 fclose(output00);
										 //find the maximum
										 
										 spmax_tmp=0.001;
										 for(i=0;i<row00;i++){
										                      if(spph[i]>spmax_tmp){
															                       spmax_tmp=spph[i];
																				   }
															  //spmax=spmax_tmp;
															  }
										 spmax=spmax_tmp;
										 // Start the calculation for kappa speectrum
										 sprintf(file11,"out/phonon_thermal_conductivity/method%d/Kappa_spectrum_%d.dat",choice,(int)T);
//										 output11=fopen(file11,"w");
										 output11 = WriteFile (file11);
										 fprintf(output11,"Frequency(THz)\tT(K)\tKappa_U(W/m.k)\tKappa_US(W/m.K)\n");
										 //gaussian_norm=0.000000;
										 //kappa_u=0.000000;
										 //kappa_us=0.000000;
										 double kappa_ttu=0.000000;
										 double kappa_ttus=0.000000;
										 for(spfre=sp_min;spfre<=sp_max;spfre=spfre+sp_step){
										                                                    gaussian_norm=0.000000;
										                                                    kappa_sumu=0.000000;
										                                                    kappa_sumus=0.000000;
																							nk=0.000000;
																							for(i=0;i<row00;i++){
																							                    //if(spph[i]!=0.&&fabs(spph[i]-spfre)<=4.0){
										 												                                     //kappa_u+=spku[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //kappa_us+=spkus[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //gaussian_norm+=Gaussian(spph[i],spfre,sigma)*spph[i];
																												if(fabs(spph[i]-spfre)<=4.0){
																															 kappa_sumu += spku[i]*Gaussian(spph[i],spfre,sigma);
										 																					 kappa_sumus += spkus[i]*Gaussian(spph[i],spfre,sigma);
										 																					 gaussian_norm += Gaussian(spph[i],spfre,sigma);
																															 nk=nk+1.000000;
																															 }
																												}
																							//kappa_u=kappa_sumu*(1.0/gaussian_norm)*(1.0/nk);
																							//kappa_us=kappa_sumus*(1.0/gaussian_norm)*(1.0/nk);
																							//kappa_u=kappa_sumu*(1.0/nk);
																							//kappa_us=kappa_sumus*(1.0/nk);
																							kappa_u=kappa_sumu;
																							kappa_us=kappa_sumus;
																							if(spfre>spmax){
																											kappa_u=0.00000;
																									        kappa_us=0.0000;
																											//gaussian_norm=1.00000;
																											//nk=1.0000;
																											} 
																							kappa_ttu += kappa_u*spfre;
																							kappa_ttus += kappa_us*spfre; 
																							fprintf(output11,"%lf\t%lf\t%le\t%le\t%le\t%le\n",spfre,T,kappa_u,kappa_us,nk,gaussian_norm);
										 												   }
										 printf("%f\t%le\t%le\n",T,kappa_ttu,kappa_ttus);
										 fclose(output11);
                                         }
              }
//-----------------------------------------------------------------------------------------------------------
// Integration form of method 8
if(choice==9){
              // CVV =0.000000;
              double kappa_tauu; // U only 
			  double kappa_tausu; // U+S only
			  double cutoff=2.0*blg*1.0E-10; // 2a, the smallest mean free path in the crystal structure 
			  double sigma; // smearing parameter 
			  FILE *output00; 
			  char file00[128];
			  printf("Temperature(K)\tkappa_u_int(SI)\tkappa_us_int(SI)\n");
			  for(T=T_s;T<=T_f;T=T+step){
                                         /*Total thermal conductivity, relaxation time and mean free path*/
                                         th_t=0.000000;
                                         tt=0.00000;
                                         l_t=0.000000;
                                         /*U-procress*/
                                         th_u=0.000000;
                                         tu=0.000000;
                                         l_u=0.000000;
                                         /* Boundary scattering*/
                                         th_b=0.000000;
                                         tb=0.000000;
                                         l_b=0.000000;
                                         /* Isotope scattering*/
                                         th_s=0.000000;
                                         ts=0.000000;
                                         l_s=0.000000;
                                         /* N-Procress*/
                                         th_n=0.000000;
                                         tn=0.000000;
                                         l_n=0.000000;
                                         /*Composite relaxation time*/
                                         //Boundary+U-process
                                         th_ub=0.000000;
                                         tub=0.000000;
                                         l_ub=0.000000;
                                         // Boundary+U-process+Isotope
                                         th_ubs=0.000000;
                                         tubs=0.000000;
                                         l_ubs=0.000000;
                                         //Boundary+U-process+N-process
                                         th_ubn=0.000000;
                                         tubn=0.000000;
                                         l_ubn=0.000000;
                                         // U-process + Isotope
                                         th_us=0.000000;
                                         tus=0.000000;
                                         l_us=0.000000;
                                         CVV = 0.000000;
                                         sprintf(file00,"out/phonon_thermal_conductivity/Spectrum_raw_%d",(int)T);
//										 output00=fopen(file00,"w");
										 output00 = WriteFile (file00);
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre1 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  CVV += ((scaling*pow(10.0,-10)/(1.0*2.0*PI)))*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,10)*N_a*k_b*(h_r*fre1/(k_b*T))*(h_r*fre1/(k_b*T))*exp(h_r*fre1/(k_b*T))/((exp(h_r*fre1/(k_b*T))-1.0)*(exp(h_r*fre1/(k_b*T))-1.0));
                                                                                                                         }
                                                                                                  }
                                                                 }
                                        // averages Gruneisen parameter: Acoustic phonons 
										 gammasum_ac=0.000000;
										 for(k=1;k<4;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre2 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  gammasum_ac += Gamma[i]*weight[i]*N_a*k_b*(h_r*fre2/(k_b*T))*(h_r*fre2/(k_b*T))*exp(h_r*fre2/(k_b*T))/((exp(h_r*fre2/(k_b*T))-1.0)*(exp(h_r*fre2/(k_b*T))-1.0));
																														 }                         
                                                                                                  }
                                                                 }
										 gammaave_ac=gammasum_ac/CVV;
										  // averages Gruneisen parameter: Optical phonons
										 gammasum_op=0.000000;
										 for(k=4;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                  if(omega[i]!=0.000000){
                                                                                                  double fre3 = omega[i]*2.0*PI*pow(10.0,12);
                                                                                                  gammasum_op += Gamma[i]*weight[i]*N_a*k_b*(h_r*fre3/(k_b*T))*(h_r*fre3/(k_b*T))*exp(h_r*fre3/(k_b*T))/((exp(h_r*fre3/(k_b*T))-1.0)*(exp(h_r*fre3/(k_b*T))-1.0));
																														 }                         
                                                                                                  }
                                                                 }
										 gammaave_op=gammasum_op/CVV; 
                                         for(k=1;k<=columns;k++){
                                                                 for(i=(k-1)*nkpt;i<=k*nkpt-1;i++){
                                                                                                fre=omega[i]*2.0*PI*pow(10.0,12);
                                                                                                // Calculating the relaxation time
                                                                                                /* Boundary scattering*/
                                                                                                if(v_g[i]!=0.000000){
																								                    tau_b=d*pow(10.0,-3.0)/((v_g[i]*2.0*PI));
                                                                                                                    if(tau_b*v_g[i]<cutoff){
                                                                                                                                            tau_b=cutoff/v_g[i];
                                                                                                                                           }
																													}
																								else if(v_g[i]==0.000000){
																								                         tau_b=1.0E-10;
																														 }
                                                                                                if(options==1){
                                                                                                /* Impurity scattering*/
                                                                                                               invtau_s=0.00000000;
                                                                                                               for(q=0;q<elements;q++){
                                                                                                                                       invtau_s += 1.0/(4.0*PI*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)*(v_g[i]*2.0*PI)/(V_a*im_c[q]*f(fre)*f(fre)));
                                                                                                                                       }
                                                                                                               if(v_g[i]!=0.000000){
																											                        tau_s=1.0/invtau_s;
                                                                                                                                    if(tau_s*v_g[i]<cutoff){
                                                                                                                                                            tau_s=cutoff/v_g[i];
                                                                                                                                                           }
																																	}
																											    else if(v_g[i]==0.000000){
																												                         tau_s=1.0E-7;  // emiprical parameter
																																		 }
                                                                                                               }
                                                                                                else if(options==2){
                                                                                                                    tau_s=99999999.0;
                                                                                                                    }
                                                                                                /* U-process*/
                                                                                               // tau_u=1.9879*(M_av*covmass)*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*g(V_a)*f(Gamma[i])*f(fre)*T);
                                                                                                 if(k<4){
																								         if(omega[i]!=0.&&v_g[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_g[i]*v_g[i]*4.0*PI*PI)/(k_b*scaling*f(gammaave_ac)*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								        else if(omega[i]==0.||v_g[i]==0.){
																								                                         tau_u=1.0E-10;
																													                     }
																										}
																								else if(k>=4){
																								         if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																												tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_g[i]*v_g[i]*4.0*PI*PI)/(k_b*scaling*f(gammaave_op)*f(fre)*T);
																												if(tau_u*v_g[i]<cutoff){
                                                                                                                                        tau_u=cutoff/v_g[i];
                                                                                                                                        }
																												} 
																								        else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																								                                                                    tau_u=1.0E-10;
																													                                               }
																										}
																							//	if(omega[i]!=0.&&v_g[i]!=0.&&v_p[i]!=0.&&Gamma[i]!=0.){
																							//					tau_u=1.9879*pow(10.0,10)*((float)(N*M_av*covmass))*(v_g[i]*2.0*PI)*(v_p[i]*v_p[i]*4.0*PI*PI)/(k_b*scaling*f(Gamma[i])*f(fre)*T);
																						//						if(tau_u*v_g[i]<cutoff){
                                                                                          //                                              tau_u=cutoff/v_g[i];
                                                                                           //                                             }
																							//					} 
																						//		else if(omega[i]==0.||v_g[i]==0.||v_p[i]==0.||Gamma[i]==0.){
																						//		                     tau_u=1.0E-10;
																						//							 }
                                                                                                //tau_u=(M_av*covmass)*f(v_g[i]*2.0*PI)*645.0*f(h_r/k_b)/(h_r*f(Gamma[i])*f(fre*h_r/(k_b*T))*f(T)*T*exp(-645.0/(3.0*T)));
                                                                                                /* N-Process*/
                                                                                                // tau_n=1.0/(B_nn*T)+1.0/(B_n*pow(T,3.0)*pow(fre,2.0)*(1.0-exp(-3.0*T/Tdebye)));
                                                                                                tau_n=0.000000;
                                                                                                /* Total relaxation time*/
                                                                                                tau_t=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process*/
                                                                                                tau_ub=1.0/w2(tau_u,tau_b);
                                                                                                /* U-process + isotope */
                                                                                                tau_us=1.0/w2(tau_u,tau_s);
                                                                                                /* Boundary+U-process+Isotope*/
                                                                                                tau_ubs=1.0/w3(tau_u,tau_b,tau_s);
                                                                                                /* Boundary+U-process+N-process*/
                                                                                                tau_ubn=1.0/w2(tau_u,tau_b);
                                                                                                /* Mode heat capacity*/
                                                                                                if(omega[i]!=0.000000){
																								                      Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
																													  }
																								else if(omega[i]==0.000000){
																								                           Cv=0.000000;
																														   }
                                                                                                // Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                                                                                //if(omega[i]>=0.0&&v_g[i]!=0.0&&v_p[i]!=0.0){
                                                                                                if(omega[i]!=0.00000){
																								//}
                                                                                                                              integral=(scaling*pow(10.0,-10)/(1.0*2.0*PI))*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,10);
                                                                                                                              // Boundary conductivity
                                                                                                                              th_b += tau_b*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              // Isotope conductivity
                                                                                                                              if(options==1){
                                                                                                                              th_s+=tau_s*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                                                  th_s+=(1.0/3.0)*0.000000;
                                                                                                                                                  } 
                                                                                                                              // U-Process
                                                                                                                              th_u+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              kappa_tauu=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
																															  // N process
                                                                                                                              //th_n+=(1.0/3.0)*tau_n*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*(v_g[i]*2.0*PI)*fabs(kpoint[i+1]-kpoint[i])*pow(10.0,-10);
                                                                                                                              th_n+=(1.0/3.0)*0.000000;
                                                                                                                              // Combined process
                                                                                                                              // 1. Total
                                                                                                                              th_t+=tau_t*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              // 2. Boundary +U-process
                                                                                                                              th_ub+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              // 3. Boundary + U-process + Isotope
                                                                                                                              if(options==1){
                                                                                                                              th_ubs+=tau_ubs*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              th_us+=tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              kappa_tausu=tau_us*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              th_ubs+=tau_ub*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              th_us+=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              kappa_tausu=tau_u*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
																																				  }
                                                                                                                              // 4. Boundary + U-process + N-process
                                                                                                                              th_ubn+=tau_ubn*(v_g[i]*v_g[i]*4.0*PI*PI)*Cv*integral*(Cv/CVV);
                                                                                                                              /*------------------Total Relaxation Time-----------------------------------*/
                                                                                                                              tt+=tau_t*Cv*integral/CVV;
                                                                                                                              tu+=tau_u*Cv*integral/CVV;
                                                                                                                              tb+=tau_b*Cv*integral/CVV;
                                                                                                                              tn+=tau_n*Cv*integral/CVV;
                                                                                                                              tub+=tau_ub*Cv*integral/CVV;
                                                                                                                              tubn+=tau_ubn*Cv*integral/CVV;
                                                                                                                              if(options==1){
                                                                                                                              ts+=tau_s*Cv*integral/CVV;
                                                                                                                              tubs+=tau_ubs*Cv*integral/CVV;
                                                                                                                              tus+=tau_us*Cv*integral/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              ts+=tau_s*0.000000;
                                                                                                                              tubs+=tau_ub*Cv*integral/CVV;
                                                                                                                              tus+=tau_u*Cv*integral/CVV;
                                                                                                                                                   }
                                                                                                                              /*-------------------MEAN FREE PATH-----------------------------------------*/
                                                                                                                              /*l_t+=tau_t*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_u+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*weight[i];
                                                                                                                                                  } */
                                                                                                                              // New definition for MFPs
                                                                                                                              l_t += tau_t*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_u += tau_u*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_b+=tau_b*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_n+=tau_n*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_ub+=tau_ub*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_ubn+=tau_ubn*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              if(options==1){
                                                                                                                              l_s+=tau_s*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_ubs+=tau_ubs*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_us+=tau_us*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                                             }
                                                                                                                              else if(options==2){
                                                                                                                              l_s+=tau_s*0.000000;
                                                                                                                              l_ubs+=tau_ub*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                              l_us+=tau_u*(v_g[i]*2.0*PI)*Cv*integral/CVV;
                                                                                                                                                  } 
                                                                                                                              }
                                                                                                if(T==T_fre&&omega[i]!=0.0){
                                                                                                             cns=(v_g[i]*2.0*PI);
                                                                                                             fprintf(output0,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
																											 fprintf(output3,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u,tau_b,tau_s,tau_n,tau_ub,tau_ubs,tau_ubn,tau_t,tau_us);
                                                                                                             fprintf(output4,"%f\t%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",omega[i],T,tau_u*cns,tau_b*cns,tau_s*cns,tau_n*cns,tau_ub*cns,tau_ubs*cns,tau_ubn*cns,tau_t*cns,tau_us*cns);
                                                                                                             }
                                                                                                fprintf(output00,"%f\t%le\t%le\t%le\n",T,omega[i],kappa_tauu,kappa_tausu);
                                                                                                }
                                                                 fprintf(output7,"%d\t%f\t%le\t%le\t%le\t%le\n",k,T,th_u,th_b,th_s,th_t);
                                                                 }
                                         fprintf(output,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,tu,tb,ts,tn,tub,tubs,tubn,tt,tus);
                                         fprintf(output1,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,th_u,th_b,th_s,th_n,th_ub,th_ubs,th_ubn,th_t,th_us);
                                         fprintf(output2,"%f\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\t%le\n",T,l_u,l_b,l_s,l_n,l_ub,l_ubs,l_ubn,l_t,l_us);
                                         // spectrum function calculation
										 //---------------------------------------------------------------------------------------------------------------------------
										 // Read the Spectrum_raw_T data
										 sigma=0.10;
										 double sp_step=0.002;
										 double spfre;
								         double sp_max=30.0; // THz
                                         double sp_min=0.001; // THz;
								         //double sp_step; 
										 double kappa_u, kappa_sumu;
										 double kappa_us, kappa_sumus;
										 double gaussian_norm;
										 double spmax_tmp;
										 double spmax; 
										 double nk;
										 int row00;
										 double *spT, *spph, *spku, *spkus;
										 output00=fopen(file00,"r");
										 FILE *output11;
										 char file11[128];
										 int tmp=0;
                                         while(!feof(output00)){
                                                             fscanf(output00,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                                                             tmp++;
                                                            }
                                         row00=tmp-1;
                                         fclose(output00);
                                         // Allocate memory
                                         spT=(double*)malloc(row00*sizeof(double));
                                         spph=(double*)malloc(row00*sizeof(double));
                                         spku=(double*)malloc(row00*sizeof(double));
                                         spkus=(double*)malloc(row00*sizeof(double));
										 // Import the data
										 output00=fopen(file00,"r");
										 for(i=0;i<row00;i++){
										                      fscanf(output00,"%lf %lf %lf %lf",&(spT[i]),&(spph[i]),&(spku[i]),&(spkus[i]));
															  }
										 fclose(output00);
										 //find the maximum
										 
										 spmax_tmp=0.001;
										 for(i=0;i<row00;i++){
										                      if(spph[i]>spmax_tmp){
															                       spmax_tmp=spph[i];
																				   }
															  //spmax=spmax_tmp;
															  }
										 spmax=spmax_tmp;
										 // Start the calculation for kappa speectrum
										 sprintf(file11,"out/phonon_thermal_conductivity/method%d/Kappa_spectrum_%d.dat",choice,(int)T);
//										 output11=fopen(file11,"w");
										 output11 = WriteFile (file11);
										 fprintf(output11,"Frequency(THz)\tT(K)\tKappa_U(W/m.k)\tKappa_US(W/m.K)\n");
										 //gaussian_norm=0.000000;
										 //kappa_u=0.000000;
										 //kappa_us=0.000000;
										 double kappa_ttu=0.000000;
										 double kappa_ttus=0.000000;
										 for(spfre=sp_min;spfre<=sp_max;spfre=spfre+sp_step){
										                                                    gaussian_norm=0.000000;
										                                                    kappa_sumu=0.000000;
										                                                    kappa_sumus=0.000000;
																							nk=0.000000;
																							for(i=0;i<row00;i++){
																							                    //if(spph[i]!=0.&&fabs(spph[i]-spfre)<=4.0){
										 												                                     //kappa_u+=spku[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //kappa_us+=spkus[i]*Gaussian(spph[i],spfre,sigma)*spph[i];
										 																					 //gaussian_norm+=Gaussian(spph[i],spfre,sigma)*spph[i];
																												if(fabs(spph[i]-spfre)<=4.0){
																															 kappa_sumu += spku[i]*Gaussian(spph[i],spfre,sigma);
										 																					 kappa_sumus += spkus[i]*Gaussian(spph[i],spfre,sigma);
										 																					 gaussian_norm += Gaussian(spph[i],spfre,sigma);
																															 nk=nk+1.000000;
																															 }
																												}
																							//kappa_u=kappa_sumu*(1.0/gaussian_norm)*(1.0/nk);
																							//kappa_us=kappa_sumus*(1.0/gaussian_norm)*(1.0/nk);
																							//kappa_u=kappa_sumu*(1.0/nk);
																							//kappa_us=kappa_sumus*(1.0/nk);
																							kappa_u=kappa_sumu;
																							kappa_us=kappa_sumus;
																							if(spfre>spmax){
																											kappa_u=0.00000;
																									        kappa_us=0.0000;
																											//gaussian_norm=1.00000;
																											//nk=1.0000;
																											} 
																							kappa_ttu += kappa_u*sp_step;
																							kappa_ttus += kappa_us*sp_step; 
																							fprintf(output11,"%lf\t%lf\t%le\t%le\t%le\t%le\n",spfre,T,kappa_u,kappa_us,nk,gaussian_norm);
										 												   }
										 printf("%f\t%le\t%le\n",T,kappa_ttu,kappa_ttus);
										 fclose(output11);
										 }
              }
//--------------------------Previous Version------------------------------------
//------------------------DUMPED IMPLEMENTATION---------------------------------
//                   for(T=T_s;T<T_f;T=T+step){
//                            th_c = 0.0;
//                          //  taua = 0.0;
//                            taub = 0.0;
//                            tauc = 0.0;
//                            tau = 0.0;
//                            taun = 0.0;
                      //      taud = 0.0;
                         //   th_ca = 0.0;
//                            th_cb = 0.0;
//                            th_cc = 0.0;
//                            th_cn = 0.0;
                       //     th_cd = 0.0;
//                            l_p = 0.0;
                          //  l_pa = 0.0;
//                            l_pb = 0.0;
//                            l_pc = 0.0;
//                            l_pn = 0.0;
//                            for(k=1;k<=columns;k++){
//                                                   for(i=(k-1)*nkpt;i<k*nkpt;i++){
//                                                                      fre = omega[i]*conv*2.0*PI;
//                                                                      Td = h_r*fre*2.0*PI/k_b;
//                                                                      constant=1.0/(2.0*PI);
//                                                                      scaling=1.0;
                                               // Phonon U process
                                               //tau_u = 1.94889*(M_av/N)*pow(10.0,-27)*v_g[i]*f(v_p[i])*exp(h_r*fre/(3.0*k_b*T))/((k_b)*pow(V_a,1.0/3)*f(fre)*f(Gamma[i])*pow(T,1.0));
//                                               tau_u = (scaling)*((M_av)*1.6653886*pow(10.0,-27))*(v_g[i]*2.0*PI)*f(v_p[i]*2.0*PI)/((k_b)*pow(V_a,1.0/3)*f(fre)*f(Gamma[i])*T);
                                               // Grain boundary scattering
//                                               tau_b = d*pow(10.0,-2.0)/(v_g[i]*2.0*PI);
                                               // N scrttering low temperature
//                                               tau_na = (scaling)*(1.0/3)*(1.0/(f(fre)*pow(T,3)*pow(10.0,-21)))+(2.0/3)*(1.0/(2.0*pow(10.0,-13)*fre*pow(T,4)));
                                               // N scrattering high T limit
//                                               tau_nb = (scaling)*(1.0/3)*(1.0/(f(fre)*T*pow(10.0,-14)))+(1.0/3)*(1.0/(1.0*fre*T));
                                               // scattering due to dislocations
                                               // Low T
//                                               tau_dt = (scaling)*1.0/(pow(10.0,-8)*fre);
                                               //High T
//                                               tau_dl = (scaling)*1.0/(3.0*pow(10.0,-7)*fre); 
                                               // N scattering total
                                            //   tau_n = tau_na*(1.0-damp(T))+tau_nb*damp(T);
                                            //   if(T<400.0){ 
                                             //            tau_n = tau_na*(1.0-damp(T));
                                             //             tau_d = tau_dt*(10.0-damp1(Td,T));
                                             //             }
                                             //  else if(T>=400.0){
//                                                          tau_n = tau_nb*damp(T);
//                                                          tau_d = tau_dl*damp1(Td,T);
                                               //           }
                                               // Phonon-impurity scattering
                                               // tau_m = 1.0/(V_a*pow(10.0,-30)*f(fre)*f(fre)*im_c/(4.0*PI*v_g[i]*f(v_p[i])));
                                              /* tau_dt = 1.0/(pow(10.0,-8)*fre);
                                               tau_dl = 1.0/(3.0*pow(10.0,-7)*fre);
                                               tau_d = tau_dl*damp1(Td,T)+tau_dt*(10.0-damp1(Td,T)); */
                                               // Phonon mode specific heat
//                                               Cv = N_a*k_b*(h_r*fre/(k_b*T))*(h_r*fre/(k_b*T))*exp(h_r*fre/(k_b*T))/((exp(h_r*fre/(k_b*T))-1.0)*(exp(h_r*fre/(k_b*T))-1.0));
                                               // total relaxation time
//                                               tau_s = 1.0/(1.0/tau_u+1.0/tau_b+1.0/tau_n+1.0/tau_d);
//                                               if(omega[i]>0.0&&v_g[i]!=0.0){
                                                             // Total thermal conductivity with U-scattering mechanism                
//                                                               th_c +=(1.0/3.0)*(constant)*Cv*(tau_u)*f(v_g[i]*2.0*PI)*fabs(kpoint[i+1]-kpoint[i])*pow(10,10.0);
                                                             // Thermal conductivity from U-process and isotope effect
                                                             //  th_ca += (1.0/3)*Cv*(1.0/(1.0/tau_u+1.0/tau_m))*f(v_g[i]);
                                                             // Thermal conductivity including U-scattering, and boundary scatterings
//                                                               th_cb += (1.0/3.0)*(constant)*Cv*(1.0/(1.0/tau_b+1.0/tau_u))*f(v_g[i]*2.0*PI)*fabs(kpoint[i+1]-kpoint[i])*pow(10,10.0);
                                                             // Including U-scattering, boundary and N-process  
//                                                               th_cc += (1.0/3.0)*(constant)*Cv*(1.0/(1.0/tau_b+1.0/tau_u+1.0/tau_n))*f(v_g[i]*2.0*PI)*fabs(kpoint[i+1]-kpoint[i])*pow(10,10.0);
                                                             // Including U- and N processes, boundary and dislocations
//                                                               th_cn += (1.0/3.0)*(constant)*Cv*(1.0/(1.0/tau_b+1.0/tau_u+1.0/tau_n+1.0/tau_d))*f(v_g[i]*2.0*PI)*fabs(kpoint[i+1]-kpoint[i])*pow(10,10.0);
                                                              // th_cd += (1.0/3)*Cv*(tau_d)*f(v_g[i]);
//                                                               l_p += tau_u*(v_g[i]*2.0*PI)*weight[i]; // mean free path
                                                               // l_pa += (1.0/(1.0/tau_u+1.0/tau_m))*v_g[i]*weight[i];
//                                                               l_pb += (1.0/(1.0/tau_b+1.0/tau_u))*(v_g[i]*2.0*PI)*weight[i];
//                                                               l_pc += (1.0/(1.0/tau_b+1.0/tau_u+1.0/tau_n))*(v_g[i]*2.0*PI)*weight[i];
//                                                               l_pn += (1.0/(1.0/tau_b+1.0/tau_u+1.0/tau_n+1.0/tau_d))*(v_g[i]*2.0*PI)*weight[i];
//                                                               tau += (tau_u)*weight[i];
                                                               // taua += (1.0/(1.0/tau_u+1.0/tau_m))*weight[i];  //U process
//                                                               taub += (1.0/(1.0/tau_b+1.0/tau_u))*weight[i];  // Boundary scattering
//                                                               tauc += (1.0/(1.0/tau_b+1.0/tau_u+1.0/tau_n))*weight[i];  // isotope or impurity scattering
//                                                               taun += (1.0/(1.0/tau_b+1.0/tau_u+1.0/tau_n+1.0/tau_d))*weight[i];  // Nornmal three phonon scattering
                                                        //       taud += (tau_d)*weight[i];  // Dislocation
                                                    //           tauo += (tau_o)*weight[i];
//                                                               }
                                    //             printf("%f\t%le\t%le\t%le\t%le\n",kp[i],th_c,th_ca,tau_m,tau_n);       
                                    //           fprintf(output3,"%f\t%f\t%f\n",);
//                                                                                }
//                                                    }
                            //  taut = 1.0/(1.0/taua+1.0/taub+1.0/tauc+1.0/taun+1.0/taud);
                            //  total = th_ca+th_cb+th_cc+th_cn+th_cd;
//                              printf("%f\t%le\t%le\t%le\n",T,th_cb,th_cc,th_c);
//                              fprintf(output1,"%f\t%le\t%le\t%le\t%le\n",T,th_cb,th_cc,th_cn,th_c);
//                              fprintf(output,"%f\t%le\t%le\t%le\t%le\n",T,taub,tauc,taun,tau);
//                              fprintf(output2,"%f\t%le\t%le\t%le\t%le\n",T,l_pb,l_pc,l_pn,l_p);
//                            }
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
if(choice==1||choice==2||choice==5||choice==7){
                         fclose(output);
                         fclose(output1);
                         fclose(output2);
                         fclose(output3);
                         fclose(output4);
                         fclose(output7);
						 }
if(choice==1||choice==5||choice==7){
                                   fclose(output0);
								   }
if(choice==1||choice==2||choice==3||choice==5||choice==7||choice==6){
                                    free(kpoint); free(omega); 
                                    free(v_p); free(v_g); 
                                    free(Gamma); free(weight);
                                    }
else if(choice==4){
                   free(kpoint); free(omega); free(Gamma);
                   }
if(options==1){
               free(N_d); free(im_c);
               }
printf("ALL CALCULATIONS ARE DONE\n");
printf("THE RESULTS ARE SAVED IN THE OUTPUTS\n");                                               
}

void Testing_code ()
{
      int j;
      int tmp;
      float kpoint[MAX_test],omega[MAX_test],v_p[MAX_test],v_g[MAX_test],Gamma[MAX_test],weight[MAX_test];
      FILE *input;
      input=fopen("out/phonon_thermal_conductivity/Inputs_kappa_cal.dat","r");
      if (input == NULL) {
	printf ("out/phonon_thermal_conductivity/Inputs_kappa_cal.dat does not exist\n");
	exit (1);
      }
      printf("/*----------------------------------------------------------------*/\n");
      printf("This is a testing code for input data file.\n");
      printf("Please run the testing code before computing thermal conductivity.\n");
      printf("You May Not Pass The Test, If there are none numbers in the data.\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("Starting to import the data\n");
      j=0;
      while(fscanf(input,"%f %f %f %f %f %f",&kpoint[j],&omega[j],&v_p[j],&v_g[j],&Gamma[j],&weight[j])!=EOF){
                   j=j+1;
                   }
      tmp=j;
      printf("Total number of rows=%d\n",tmp);
      fclose(input);
      printf("Importing data is done\n");
      for(j=0;j<tmp;j++){
                         printf("%f\t%f\t%f\t%f\t%f\t%f\n",kpoint[j],omega[j],v_p[j],v_g[j],Gamma[j],weight[j]);
                         }
      printf("Congratuations!\nThe importing test is passed\n");
      printf("Press 'Enter' key to exit the program.\n");

}

void Method4PreProcess ()
{
      int i,j;
      int tmp;
      int nkpt;
      int columns;
      char file1[128];
      char file2[128]; 
      float *kpoint,*omega,*v_p,*v_g,*Gamma,*weight;
      float dummy1, dummy2, dummy3, dummy4, dummy5, dummy6;
      FILE *input;
      FILE *output;
      nkpt = Nkpoints;
      printf("Numer of kpoints in each band dispersion: %d\n", nkpt);
//      scanf("%d",&nkpt);
//      input=fopen("Inputs_kappa_cal.dat","r");
      input = ReadFile ("out/phonon_thermal_conductivity/Inputs_kappa_cal.dat");
      printf("/*----------------------------------------------------------------*/\n");
      printf("/*  FIND THE MAXIMUM FREQUENCY FOR TA1,TA2 and LA1 BRANCHES       */\n");
	  printf("/*             SUPPORTING THE SLACK's MODEL                       */\n");
	  printf("/*           CONTRIBUTORS: BING XIAO && NAN LI                    */\n");
	  printf("/*                  DATED: 2021-04-27                             */\n");    
	//  printf("This is a testing code for input data file.\n");
    //  printf("Please run the testing code before computing thermal conductivity.\n");
    //  printf("You May Not Pass The Test, If there are none numbers in the data.\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("Starting to import the data\n");
//      system("PAUSE");
      sprintf(file1,"out/phonon_thermal_conductivity/Inputs_kappa_cal.dat");
      input=fopen(file1,"r");
      if(input==NULL){
                      perror("Error while opening the file.\n");
                      getchar(); getchar();
                      exit(EXIT_FAILURE);
                     }
      else {
            printf("File %s ls loaded.\n",file1);
            }
      int R_2=0;
      while(!feof(input)){
                           fscanf(input,"%f %f %f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4, &dummy5, &dummy6);
                           R_2++;
                         }
      tmp=R_2-1;
      columns=tmp/nkpt; // total number of bands in input
      printf("Importing data is done.\n");
      printf("Total number of rows=%d\n",tmp);
      printf("Total number of phonon dispersions=%d\n",columns);
      fclose(input);
      kpoint=(float*)malloc(tmp*sizeof(float));
      omega=(float*)malloc(tmp*sizeof(float));
      v_p=(float*)malloc(tmp*sizeof(float));
      v_g=(float*)malloc(tmp*sizeof(float));
      Gamma=(float*)malloc(tmp*sizeof(float));
      weight=(float*)malloc(tmp*sizeof(float));
      input=fopen(file1,"r");
      for(j=0;j<tmp;j++){
                         fscanf(input,"%f %f %f %f %f %f",&(kpoint[j]),&(omega[j]),&(v_p[j]),&(v_g[j]),&(Gamma[j]),&(weight[j]));
                        }
      fclose(input);
      printf("Importing data is done\n");
//      system("PAUSE");
      for(j=0;j<tmp;j++){
                         printf("%f\t%f\t%f\t%f\t%f\t%f\n",kpoint[j],omega[j],v_p[j],v_g[j],Gamma[j],weight[j]);
                         }
// find the maximum value for each phonon branch
      float fmax;
      sprintf(file2,"out/phonon_thermal_conductivity/method4/Slack_model_supporting.dat");
//      output=fopen(file2,"w");
      output = WriteFile (file2);
      for(i=1;i<=columns;i++){
	                         float ftmp=-0.1;
							 for(j=(i-1)*nkpt;j<i*nkpt;j++){
							                                if(omega[j]>ftmp){
															                 ftmp=omega[j];
																			 }
															fmax=ftmp;
															}
							 printf("%d\t%f\n",i,fmax);
							 fprintf(output,"%d\t%f\n",i,fmax);
							 } 
	  fclose(output);
	  free(kpoint); free(omega); free(v_p); free(v_g); free(Gamma); free(weight);     
      printf("Congratuations!\nThe importing test is passed\n");
      printf("Press 'Enter' key to exit the program.\n");
 } 

float f(double x)
{
      return pow(x,2.0);
      }
float g(double y)
{
      return pow(y,1.0/3.0);
      }
float Gaussian(double x, double y, double z)
{
      double c1;
      double c2;
      c1=1.0/sqrt(2.0*PI)*(1.0/z);
      c2=(x-y)*(x-y);
      return c1*exp(-1.0*c2/(2.0*z*z));
	  }
float w2(double x, double y)
{
      return 1.0/x+1.0/y;
      }
float w3(double x, double y, double z)
{
      return 1.0/x+1.0/y+1.0/z;
      }
float w4(double x, double y, double z, double u)
{
      return 1.0/x+1.0/y+1.0/z+1.0/u;
      }
float w5(double x, double y, double z)
{
      return (1.0/3.0)*(1.0/pow(x,3.0)+1.0/pow(y,3.0)+1.0/pow(z,3.0));
      }
float w6(double x, double y)
{
      return 0.5*(1.0/pow(x,3.0)+1.0/pow(y,3.0));
      }
float damp(double x)
{
      return 1.0/(1.0+exp(-(x/10.0-10.0)));
      }
float damp1(double x, double y)
{
      return 1.0+10.0*(x-x/(1.0+exp(-(x/y-1.0))));
      }
