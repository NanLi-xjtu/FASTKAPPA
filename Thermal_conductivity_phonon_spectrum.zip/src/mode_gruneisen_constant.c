#include "mode_gruneisen_constant.h"

void Mode_Gruneisen_constant ()
{
	int i,j,k,l;
	int N_t;
	int M_k;
	int kp; //total number of rows or k-points in the input-file
	float k_1, k_2, k_3; // mode_gruneisen_constants
	float kk_1, kk_2, kk_3;
	float Gamma_1;
	float Gamma; // Mean Gruneisen constant: Gamma=(k_1+k_2+k_3)/3
	float a11,a12,a13;
	float a21,a22,a23;
	float a31,a32,a33;
	float a1,a2,a3;
	float scale; // a scale constant in CONTCAR or POSCAR 
	float V_1, V_2, V_3; // Cell volumes
	float V;
	float *knumber;
	float *fre_minus, *fre_min, *fre_plus; // number of kpoints, frequencies of phonons
	float dummy1, dummy2, dummy3, dummy4;
	char file[128];
	char coords00[256]; // anauxilary vairable
	FILE *input;
	FILE *input0;
	FILE *output;
	double x, y, z;
	char filename[128];
	printf("/*------------------Thermal Conductivity Project------------------------*/\n");
	printf("/*                     Mode-Gruneisen Parameter                         */\n");
	printf("/*                       Written by Bing Xiao                           */\n");
	printf("/*                        b.xiao@ucl.ac.uk                              */\n");
	printf("/*                           2015-08-10                                 */\n");
	printf("/*    New Updates Implemented by: Bing Xiao, XJTU                       */\n");
	printf("/*                           2020-06-29                                 */\n");
	printf("/*  THIS CODE EVALUATES THE mode_gruneisen_constants AT EACH K-POINT    */\n");
	printf("/*  THE mode_gruneisen_constants ARE REQUIRED TO COMPUTE THE LATTICE    */\n");
	printf("/*  THERMAL CONDUCTIVITY WHEN THE TEMPERATURE IS HIGHER THAN DEBYE T    */\n");
	printf("/* Please Cite: Yingchun Ding, Bing Xiao, RSC Advances, 5,18391(2015).  */\n");   
	printf("/*----------------------------------------------------------------------*/\n");
	printf("Cell three cell volumes are required as the inputs:\n");
	printf("The order of the three cell volumes: Compressed-Equilibrium-Expansion\n");
	printf("Two options are offered: Type on the screen(1) or Compute from CONTCAR/POSCAR(2)\n");
	printf("Enter your option below:(MUST BE AN INTER) %d\n", readV);
	if(readV==1){
		V_1 = volumes_cee.x;
		V_2 = volumes_cee.y;
		V_3 = volumes_cee.z;
		printf("Please enter the three volumes in the order of compression-equilibrium-expansion\n");
		printf("Example: 123.50 125.90 130.54\n");
		printf("%.2f %.2f %.2f\n", V_1, V_2, V_3);
	//	scanf("%f %f %f",&V_1,&V_2,&V_3);
	} else if(readV==2){
		printf("Only accept the structural files in CONTCAR/POSCAR format!\n");
		printf("Example: POSCAR_1 POSCAR_2 POSCAR_3\n");
		printf("Enter the prefix for inputs:\n");
		int S;
//		while((S=getchar())!=EOF&&S!='\n');
//		fgets(file, 128, stdin);
		sprintf (file, "CONTCAR");

		// read the lattice vectors from each structural file
		for(i=1;i<=3;i++){
			char file00[128];
			sprintf(file00,"in/%s_%d",file,i);
			input0=fopen(file00,"r");
			if(input0==NULL){
				printf ("Error while opening the file %s.\n", file00);
				getchar();
				exit(EXIT_FAILURE);
			} else {
				printf("File:%s is loaded\n",file00);
				// for(j=0;j<NMAX;j++){
				j=0;
				while(fgets(coords00,256,input0)!=NULL) {              
					if(j==1) {
						sscanf(coords00,"%f",&scale);
					} else if(j==2){
						sscanf(coords00,"%f %f %f",&a11,&a12,&a13);
					} else if(j==3){
						sscanf(coords00,"%f %f %f",&a21,&a22,&a23);
					} else if(j==4){
						sscanf(coords00,"%f %f %f",&a31,&a32,&a33);
					}
					j++;
				}
			}
			fclose(input0);
			printf("Reading file:%d is completed \n",i);
			printf("-----------------------------------\n");
			printf("         Lattice vectors           \n");
			printf("%f %f %f\n",a11*scale,a12*scale,a13*scale);
			printf("%f %f %f\n",a21*scale,a22*scale,a23*scale);
			printf("%f %f %f\n",a31*scale,a32*scale,a33*scale);
			a1=VLen(a11,a12,a13)*scale;
			a2=VLen(a21,a22,a23)*scale;
			a3=VLen(a31,a32,a33)*scale;
			V=(a11*(a22*a33-a32*a23)-a12*(a21*a33-a31*a23)+a13*(a21*a32-a31*a22))*(scale*scale*scale);
			if(i==1){
				V_1=V;
			} else if(i==2){
				V_2=V;
			} else if(i==3){
				V_3=V;
			}       
			printf("------------------------------------\n");
			printf("         Lattice constants          \n");
			printf("a=%f b=%f c=%f\n",a1,a2,a3);
			printf("Cell volume:%f\n",V); 
		}
	}  

	sprintf (filename, "out/file_creation/Phonon_volume.dat");
	input=fopen(filename,"r");
	if (input == NULL) {
		printf ("opening %s failed\n", filename);
		exit (1);
	}
	sprintf (filename, "out/mode_gruneisen_constants/Gruneisen_mode.dat");
	output=fopen(filename,"w");
	if (output == NULL) {
		printf ("opening %s failed\n", filename);
		exit (1);
	}
	l=0;
	while(fscanf(input,"%f %f %f %f",&dummy1,&dummy2,&dummy3,&dummy4)!=EOF){
		           l=l+1;
		           }
	kp=l;
	fclose(input);
	// Allocating the dynamic memory to arrays in the furture implementations
	knumber=(float*)malloc(kp*sizeof(float));
	fre_minus=(float*)malloc(kp*sizeof(float));
	fre_min=(float*)malloc(kp*sizeof(float));
	fre_plus=(float*)malloc(kp*sizeof(float));
	sprintf (filename, "out/file_creation/Phonon_volume.dat");
	input=fopen(filename,"r");
	if (input == NULL) {
		printf ("opening %s failed\n", filename);
		exit (1);
	}
	for(i=0;i<kp;i++){
		          fscanf(input,"%f %f %f %f",&(knumber[i]),&(fre_minus[i]),&(fre_min[i]),&(fre_plus[i]));
		          }
	fclose(input);
	//Checking the inputs
	printf("Please check your inputs below\n");
	for(k=0;k<20;k++){
		          printf("%f\t%f\t%f\t%f\n",knumber[k],fre_minus[k],fre_min[k],fre_plus[k]);
		          }
	printf("The total number of k-points in the file is=%d\n",kp);
	printf("The three cell volumes are given as\n");
	printf("Compression=%f\tEquilibrium=%f\tExpansion=%f\n",V_1,V_2,V_3);
	printf("The code will start to compute the mode Gruneisen constant at each k point\n");

	//Computing the mode-Gruneisen constant
	for(j=0;j<kp;j++){
		          k_1=(fre_min[j]-fre_minus[j])/(V_2-V_1);
		          k_2=(fre_plus[j]-fre_min[j])/(V_3-V_2);
		          k_3=(fre_plus[j]-fre_minus[j])/(V_3-V_1);
		          Gamma=-1.0*(k_1+k_2+k_3)*V_2/(3.0*fre_min[j]+0.000001);
		          printf("%f\t%f\t%f\t%f\t%f\n",knumber[j],k_1,k_2,k_3,Gamma);
		          fprintf(output,"%f\t%f\t%f\n",knumber[j],fre_min[j],Gamma);
		          }
	fclose(output);
	// For plotting purpose only
	FILE *output1;
	printf("Do you want to separate the data of different phonon branches by a blank line:Yes(1) or No(2)\n");
	printf("Enter you option:(MUST BE AN INTEGER) %d\n", options_gru);
//	scanf("%d",&options_gru);
	if(options_gru==1){
		       printf("Enter additional parameters below:\n");
		       N_t = Natoms;
		       printf("Total number of atoms in cell:(Example:25) %d\n", N_t);
//		       scanf("%d",&N_t);
		       M_k = Nkpoints;
		       printf("Total number of k-points in each dispersion:(Example:120) %d\n", M_k);
//		       scanf("%d",&M_k);
		       sprintf (filename, "out/mode_gruneisen_constants/Gruneisen_mode_plot.dat");
		       output1=fopen(filename,"w");
			if (output1 == NULL) {
				printf ("opening %s failed\n", filename);
				exit (1);
			}
		       for(i=1;i<=N_t*3;i++){
		                               for(j=(i-1)*M_k;j<i*M_k;j++){
		                                                              kk_1=(fre_min[j]-fre_minus[j])/(V_2-V_1);
		                                                              kk_2=(fre_plus[j]-fre_min[j])/(V_3-V_2);
		                                                              kk_3=(fre_plus[j]-fre_minus[j])/(V_3-V_1);
		                                                              Gamma_1=-1.0*(kk_1+kk_2+kk_3)*V_2/(3.0*fre_min[j]+0.000001);
		                                                             // printf("%f\t%f\t%f\t%f\t%f\n",knumber[j],k_1,k_2,k_3,Gamma);
		                                                              fprintf(output1,"%f\t%f\t%f\n",knumber[j],fre_min[j],Gamma_1);
		                                                              }
		                               fprintf(output1,"\n");
		                               }
		       fclose(output1);
		       }
	else if(options_gru==2){
		            printf("Further action is not required.\n");
		            }
	free(knumber);
	free(fre_minus); free(fre_min); free(fre_plus);
	printf("The calculations are done.\n");
	printf("The resutls are saved in file.\n");
	printf("Thank you for using the code.\n");
}
