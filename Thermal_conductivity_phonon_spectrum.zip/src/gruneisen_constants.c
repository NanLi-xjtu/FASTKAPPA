#include "gruneisen_constants.h"

void Gruneisen_constant ()
{
 int i, j;
 int R_1;
 int N_t;
 int M_k, nkpt_r; 
 float Cv; // specific heat
 float Cv1, Cv2, Cv3; // Specific heat in x, y and z directions
 float Cb; // mode specific heat
 float Cb1, Cb2, Cb3; //mode specific heat in x, y and z directions
 float Gamma; // Gruneisen constant
 float Gamma_1, Gamma_2, Gamma_3; // Gamma values in three principal directions, x,y and z
 float Gamma_mode;
 float Gamma_modex, Gamma_modey, Gamma_modez; // Mode gamma in x, y and z directions
// The same set of parameters using ture value
 float Gamma1;
 float Gamma_11, Gamma_22, Gamma_33;
 float Gamma_mode1;
 float Gamma_modex1, Gamma_modey1, Gamma_modez1;
 float dummy1, dummy2, dummy3, dummy4, dummy5, dummy6;
 float fre;
 float T;
 float T_s, T_f, T_step; // Starting, ending and step for temperature
 float x,y,z,r; // varibles
 float *kxdata,*kydata,*kzdata; // k ccordinates
 float *frequency, *Gruneisen, *weight; // Import the data for kpoint, phonon frwquency and mode gruneisen constant
 float *kx, *ky, *kz; // K_points.dat file
 float *kmag, *frep, *modegamma; // Mode-gruneisen.dat file
 int rows;
 int row;
 char filename[256];
 float w, k, h;
 w = w_grun;
 k = boltzmann;
 h = h_r;
 FILE *input; // frequency
 FILE *input1; // k_points
 FILE *output;  // Combined file
 FILE *output1; // Gruneisen constant in different directions
 FILE *output2; // Plotting data
printf("/*-------------------Theraml Conductivity Project-----------------------*/\n"); 
printf("/*              This Program is written by Bing Xiao                    */\n");
printf("/*                   Department of Physics                              */\n");
printf("/*                    Temple University                                 */\n");
printf("/*                    b.xiao@ucl.ac.uk                                  */\n");
printf("/*                        2015-11-12                                    */\n");
printf("/*-------------------PROPERTIES COMPUTED--------------------------------*/\n"); 
printf("/*                    gruneisen_constants                               */\n");
printf("/*-----------------PLEASE CITE THE FOLLOWING PAPER----------------------*/\n");
printf("/*           Y.Ding, B.Xiao, RSC Advances,5,18391(2015)                 */\n");
printf("/*---------------------IMPORTANCE NOTICE--------------------------------*/\n");
printf("/*          ONLY APPLIES TO THE PRINCIPAL DIRECTIONS                    */\n");
printf("/*                  [100], [010] and [001]                              */\n");
printf("/*       THE RESULTS MAY NOT RIGHT FOR OTHER DIRECTIONS                 */\n");
printf("/*----------------------------------------------------------------------*/\n");      
 printf("Prepare to input the following parameters\n");
 printf("Enter the file name for k-points and their weights:\n");
// fgets(filename, 128, stdin);
 sprintf (filename, "out/file_creation/K.dat");
 puts (filename);
 N_t = Natoms;
 printf("Total number of atoms in cell:(MUST BE AN INTEGER) %d\n", N_t);
// scanf("%d",&N_t);
 M_k = Nkpoints;
 printf("Total number of k-points in each phonon dispersion:(MUST BE AN INTEGER) %d\n", M_k);
// scanf("%d",&M_k);
 T_s = stprt;
 printf("The starting temperature (K) %.2f\n", T_s);
// scanf("%f",&T_s);
 T_f = fntprt;
 printf("The final temperature %.2f\n", T_f);
// scanf("%f",&T_f);
 T_step = icmtprt;
 printf("The increment of temperature %.2f\n", T_step);
// scanf ("%f",&T_step);
 printf("You inputs are summrized below\n");
 printf("Starting Temperature (K)=%f\n",T_s);
 printf("The final temperature (K)=%f\n",T_f);
 printf("The step (K)=%f\n",T_step);
 row=N_t*M_k*3;
// Import the k_points.dat
 kx=(float*)malloc(M_k*sizeof(float));
 ky=(float*)malloc(M_k*sizeof(float));
 kz=(float*)malloc(M_k*sizeof(float));
 weight=(float*)malloc(M_k*sizeof(float));
 input=fopen(filename,"r");
 if (input == NULL) {
	printf ("opening %s failed\n", filename);
	exit (1);
 }
 nkpt_r=0;
 for(i=0;i<M_k;i++){
                     fscanf(input,"%f %f %f %f",&(kx[i]),&(ky[i]),&(kz[i]),&(weight[i]));
                     nkpt_r++;
                     }
 if(M_k!=nkpt_r){
                  printf("Inconsisency is found in the number of k_points.\n");
                  printf("K-point in kpoints file is %d,\n",nkpt_r);
                  printf("while, you gave %d previously.\n",M_k);
                  exit(EXIT_FAILURE);
                  }
 else {
       printf("%s is imported.\n",filename);
       printf("Number of kpoints:%d\n",nkpt_r);
       }
 fclose(input);
// Import the mode_gruneisen constant from previous calculations
// Determine the data structure
 sprintf (filename, "out/mode_gruneisen_constants/Gruneisen_mode.dat");
 input1=fopen(filename,"r");
 if (input1 == NULL) {
	printf ("opening %s failed\n", filename);
	exit (1);
 }
 R_1=0;
 while(!feof(input1)){
                    fscanf(input1,"%f %f %f",&dummy1, &dummy2, &dummy3);
                    R_1++;
                    }
 rows=R_1-1;
 if(rows!=row){
               printf("Inconsistency is found in your phonon data.\n");
               printf("Total number of rows expected in 'Gruneisen_mode.dat' is %d.\n",row);
               printf("Rows atcullay found is %d.\n",rows);
               exit(EXIT_FAILURE);
               }
 else {
       printf("Data are imported successfully from 'Gruneisen_mode.dat' file.\n");
       printf("Total number of rows in file:%d\n",rows);
       printf("Expected number of rows from 3N*nkpt=%d\n",row);
       }
 fclose(input);
 kmag=(float*)malloc(rows*sizeof(float));
 frep=(float*)malloc(rows*sizeof(float));
 modegamma=(float*)malloc(rows*sizeof(float));
 sprintf (filename, "out/mode_gruneisen_constants/Gruneisen_mode.dat");
 input1=fopen(filename,"r");
 if (input1 == NULL) {
	printf ("opening %s failed\n", filename);
	exit (1);
 }
 for(i=0;i<rows;i++){
                     fscanf(input1,"%f %f %f",&(kmag[i]),&(frep[i]),&(modegamma[i]));
                     }
 fclose(input1);
// Combine the two files in two single
 int rowk;
 sprintf (filename, "out/gruneisen_constants/Kpoint_Gruneisen.dat");
 output=fopen(filename,"w");
 if (output == NULL) {
	printf ("opening %s failed\n", filename);
	exit (1);
 }
 for(i=1;i<N_t*3;i++){
                        for(j=(i-1)*M_k;j<i*M_k;j++){
                                                       rowk = j-(i-1)*M_k;
                                                       fprintf(output,"%f\t%f\t%f\t%f\t%f\n",kx[rowk],ky[rowk],kz[rowk],frep[j],modegamma[j]);
                                                       }
                        }
 fclose(output);
 free(kx); free(ky); free(kz); free(weight);
 free(frep); free(modegamma); free(kmag);
// Import the data from combined file
// Allocate the memory to poitners
 kxdata=(float*)malloc(rows*sizeof(float));
 kydata=(float*)malloc(rows*sizeof(float));
 kzdata=(float*)malloc(rows*sizeof(float));
 frequency=(float*)malloc(rows*sizeof(float));
 Gruneisen=(float*)malloc(rows*sizeof(float));
// weight=(float*)malloc(rows*sizeof(float));
 sprintf (filename, "out/gruneisen_constants/Kpoint_Gruneisen.dat");
 output=fopen(filename,"r");
 if (output == NULL) {
	printf ("opening %s failed\n", filename);
	exit (1);
 }
 for(i=0;i<rows;i++){
                     fscanf(output,"%f %f %f %f %f",&(kxdata[i]),&(kydata[i]),&(kzdata[i]),&(frequency[i]),&(Gruneisen[i])); 
                     }
 fclose(output);
// Cv=0.0;
// Gamma_mode=0.0;
 printf("Temperature(K)\tGamma\tGamma_x\tGamma_y\tGamma_z\tCv(J/K.mol)\n");
 output1=fopen("out/gruneisen_constants/Gruneisen_directional_abs.dat","w");
 output2=fopen("out/gruneisen_constants/Gruneisen_directional_ture.dat","w");
 fprintf(output1,"T(K)\tGamma_x\tGamma_y\tGamma_z\tGamma\n");
 fprintf(output2,"T(K)\tGamma_x\tGamma_y\tGamma_z\tGamma\n");
 for(T=T_s;T<=T_f;T=T+T_step){
                            Cv=0.0;
                            Cv1=0.0;
                            Cv2=0.0;
                            Cv3=0.0;
                            Gamma_mode=0.0; Gamma_mode1=0.0;
                            Gamma_modex=0.0; Gamma_modex1=0.0;
                            Gamma_modey=0.0; Gamma_modey1=0.0;
                            Gamma_modez=0.0; Gamma_modez1=0.0;
                            for(j=0;j<rows;j++){
                                                if(frequency[j]>0.0&&Gruneisen[j]!=0.0){
                                                                     fre=frequency[j]*w*2.0*PI;
                                                                     Cv+=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a;
                                                                     Cb=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a;
                                                                     Gamma_mode+=(Cb)*fabs(Gruneisen[j]);  // Using absolute value
                                                                     Gamma_mode1+=(Cb)*Gruneisen[j]; // Using the ture value
                                                                     // Gruneisen constant in x direction
                                                                     if(kxdata[j]!=0.0&&kydata[j]==0.0&&kzdata[j]==0.0){
                                                                                                                        //Cv1+=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a*weight[j];
                                                                                                                        Cv1+=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a;
                                                                                                                        Cb1=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a;
                                                                                                                        //Gamma_modex+=(Cb1)*Gruneisen[j]*weight[i];
                                                                                                                        Gamma_modex += (Cb1)*fabs(Gruneisen[j]);
                                                                                                                        Gamma_modex1 += (Cb1)*Gruneisen[j];
                                                                                                                        }
                                                                     // In y direction
                                                                     else if(kxdata[j]==0.0&&kydata[j]!=0.0&&kzdata[j]==0.0){
                                                                                                                             //Cv2+=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a*weight[j];
                                                                                                                             Cv2+=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a;
                                                                                                                             Cb2=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a;
                                                                                                                             //Gamma_modey+=(Cb2)*Gruneisen[j]*weight[j];
                                                                                                                             Gamma_modey += (Cb2)*fabs(Gruneisen[j]);
                                                                                                                             Gamma_modey1 += (Cb2)*Gruneisen[j];
                                                                                                                             }
                                                                     // In z direction
                                                                     else if(kxdata[j]==0.0&&kydata[j]==0.0&&kzdata[j]!=0.0){
                                                                                                                             //Cv3+=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a*weight[j];
                                                                                                                             Cv3+=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a;
                                                                                                                             Cb3=k*(h*fre/(k*T))*(h*fre/(k*T))*f_grun(h,fre,k,T)*exp(h*fre/(k*T))*N_a;
                                                                                                                             //Gamma_modez+=(Cb3)*Gruneisen[j]*weight[j];
                                                                                                                             Gamma_modez += (Cb3)*fabs(Gruneisen[j]);
                                                                                                                             Gamma_modez1 += (Cb3)*Gruneisen[j];
                                                                                                                             }
                                                                                          }
                                                }
                            Gamma=Gamma_mode/Cv; // Absolute value
                            Gamma1=Gamma_mode1/Cv; // True value
                            if(Cv1!=0.0){
                                         Gamma_1=Gamma_modex/Cv1;
                                         Gamma_11=Gamma_modex1/Cv1;
                                         }
                            else{
                                 Gamma_1=0.0; Gamma_11=0.0;
                                 }
                            if(Cv2!=0.0){
                                         Gamma_2=Gamma_modey/Cv2;
                                         Gamma_22=Gamma_modey1/Cv2;
                                         }
                            else{
                                 Gamma_2=0.0; Gamma_22=0.0;
                                 }
                            if(Cv3!=0.0){
                                         Gamma_3=Gamma_modez/Cv3;
                                         Gamma_33=Gamma_modez1/Cv3;
                                         }
                            else{
                                 Gamma_3=0.0; Gamma_33=0.0;
                                 }
                            if(T>=T_f-20.0||T<=T_s+20.0){
                                                         printf("%f\t%f\t%f\t%f\t%f\t%f\n",T,Gamma,Gamma_1,Gamma_2,Gamma_3,(float)(Cv/M_k));
                                                         }
                            fprintf(output1,"%f\t%f\t%f\t%f\t%f\n",T,Gamma_1,Gamma_2,Gamma_3,Gamma);
                            fprintf(output2,"%f\t%f\t%f\t%f\t%f\n",T,Gamma_11,Gamma_22,Gamma_33,Gamma1);
                            }
 free(kxdata); free(kydata); free(kzdata); free(Gruneisen); free(frequency);
 printf("All calculations are done\n");
 printf("The resutls are stored in the output file\n");
 printf("Press 'Enter' to exit the program\n");
 fclose(output1); fclose(output2);
}

float f_grun(double x, double y, double z, double r)
{
      return 1.0/((exp(x*y/(z*r))-1.0)*(exp(x*y/(z*r))-1.0));
      } 
