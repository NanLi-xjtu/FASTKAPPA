#include "group_and_phase_velocities.h"

void Velocities ()
{
int i,j,l;
int R_1;
int kpnub; // total number of k points
int options; // unit conversion
float La_x[MAX_vel],La_y[MAX_vel],La_z[MAX_vel]; // Lattice vectors
float *k_x,*k_y,*k_z,*frequency; // The fractional coordinates of each k point
float weight[MAX_vel]; // The weight of k point
float Weig; //total weight
// Reciprocal lattice vectors
float R_1x, R_1y, R_1z; // Reciprocal lattice vectors in [100] direction
float R_2x, R_2y, R_2z; // Reciprocal lattice vectors in [010] direction
float R_3x, R_3y, R_3z; // Reciprocal lattice vectors in [001] direction
double V; // cell volume
double omega; //Phonon frequency;
double v_px, v_py, v_pz; // The three components of the phase velocity
double v_gx, v_gy, v_gz; // The three components of the group velocity
double v_p, v_g; // Phase and group velocities
double h, h_1, h_2; // Deriative step
double h_x, h_y, h_z; // the step of k vector in each direction
int N_t; // Total number of atoms in the cell
int M_k; // total number of kpoints in the phonon spectrum
float a_1, a_2, a_3; // lattice vectors in x
float b_1, b_2, b_3; // lattice vectors in y
float c_1, c_2, c_3; // lattice vectots in z
float a,b,c; // lattice constants
float kp_x, kp_y, kp_z; // k vector lengths, k_x, k_y and k_z
float Kp_x, Kp_y, Kp_z; // Coordinates of k points in phonon dispersions
float Kp_x1, Kp_y1, Kp_z1; // Numerical differential only purpose
float Kp_x2, Kp_y2, Kp_z2;
float kp; // Module of k vector
float kp_d, kp_d1, kp_d2; // Module of ext k vector
float dummy1, dummy2, dummy3, dummy4;
double x, y, z;
char filename[128];
printf("/*----------------------------------------------------------------------*/\n"); 
printf("/*              This Program is written by Bing Xiao                    */\n");
printf("/*                   Department of Physics                              */\n");
printf("/*                    Temple University                                 */\n");
printf("/*                    b.xiao@ucl.ac.uk                                  */\n");
printf("/*                        2015-10-30                                    */\n");
printf("/*-------------------PROPERTIES COMPUTED--------------------------------*/\n"); 
printf("/*             PHASE VELOCITY   AND   GROUP VELOCITY                    */\n");
printf("/*                  USING FINITE DIFFERENCE METHOD                      */\n");
printf("/*-----------------PLEASE CITE THE FOLLOWING PAPER----------------------*/\n");
printf("/*           Y.Ding, B.Xiao, RSC Advances,5,18391(2015)                 */\n");
printf("/*---------------------IMPORTANCE NOTICE--------------------------------*/\n");
printf("/*          ONLY APPLIES TO THE PRINCIPAL DIRECTIONS                    */\n");
printf("/*                  [100], [010] and [001]                              */\n");
printf("/*       THE RESULTS MAY NOT RIGHT FOR OTHER DIRECTIONS                 */\n");
printf("/*----------------------------------------------------------------------*/\n");            
printf("Input the following parameters\n");
N_t = Natoms;
printf("Enter the total number of atoms in your system (MUST BE AN INTEGER): %d\n", N_t);
//scanf("%d",&N_t);
M_k = Nkpoints;
printf("Enter the total number of kpoints in each phonon dispersion (MUST BE AN INTEGER): %d\n", M_k);
//scanf("%d",&M_k);
printf("########################################################################\n");
printf("Default unit of phonon frequency in Phononpy is THz.\n");
printf("If the results are used for thermal conductivity, please choose 2.\n");
printf("A factor 2.0*PI will be multiplied to frequency and velocities by code. \n");
options = frqcUnt;
printf("Unit of the phonon frequency: THz(1) or 2PI*THz(2): %d\n", options);
//scanf("%d",&options);
printf("########################################################################\n");
FILE *input0;
FILE *input1;
FILE *output;
FILE *output1;
FILE *output2;
FILE *output3;
FILE *output4;
FILE *output5;
FILE *output6;
//input=fopen("Lattice_vectors.dat","r");
// The lattice parameters of the crystal structure
// Import from the CONTCAR or POSCAR
printf("Only accept the structural files in CONTCAR format!\n");
//printf("Example: CONTCAR_1 CONTCAR_2 CONTCAR_3\n");
//printf("Enter the prefix for inputs:\n");
//int S;
//while((S=getchar())!=EOF&&S!='\n');
//gets(file);
// read the lattice vectors from each structural file
char file00[128];
char coords00[256];
float scale;
sprintf(file00,"in/CONTCAR_2");
input0=fopen(file00,"r");
if(input0==NULL){
                 perror("Error while opening the file.\n");
                 getchar();
                 exit(EXIT_FAILURE);
                }
else {
      printf("File:%s is loaded\n",file00);
                        // for(j=0;j<NMAX;j++){
      j=0;
      while(fgets(coords00,256,input0)!=NULL){              
                                              if(j==1){
												       sscanf(coords00,"%f",&scale);
													  }
											  else if(j==2){
												 	        sscanf(coords00,"%f %f %f",&a_1,&a_2,&a_3);
												            }
											  else if(j==3){
												 	        sscanf(coords00,"%f %f %f",&b_1,&b_2,&b_3);
												            }
											  else if(j==4){
												 	        sscanf(coords00,"%f %f %f",&c_1,&c_2,&c_3);
												            }
                                              j++;
			                                }
			                           }
fclose(input0);
printf("Reading file:%d is completed \n",i);
printf("-----------------------------------\n");
printf("         Lattice vectors           \n");
printf("%f %f %f\n",a_1*scale,a_2*scale,a_3*scale);
printf("%f %f %f\n",b_1*scale,b_2*scale,b_3*scale);
printf("%f %f %f\n",c_1*scale,c_2*scale,c_3*scale);
a=VLen(a_1,a_2,a_3)*scale;
b=VLen(b_1,b_2,b_3)*scale;
c=VLen(c_1,c_2,c_3)*scale;
V=(a_1*(b_2*c_3-c_2*b_3)-a_2*(b_1*c_3-c_1*b_3)+a_3*(b_1*c_2-c_1*b_2))*(scale*scale*scale); 
//i=0;
//while(fscanf(input,"%f %f %f",&La_x[i],&La_y[i],&La_z[i])!=EOF){
//                   i=i+1;
//                   }
//a_1=La_x[0],a_2=La_y[0],a_3=La_z[0];
//b_1=La_x[1],b_2=La_y[1],b_3=La_z[1];
//c_1=La_x[2],c_2=La_y[2],c_3=La_z[2];
//fclose(input);
// Determine the structural of data
sprintf (filename, "out/file_creation/K_points.dat");
if ((input1 = fopen(filename,"r")) == NULL) {
	printf ("opening %s failed\n", filename);
	exit (1);
}
R_1=0;
while(!feof(input1)){
                    fscanf(input1,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                    R_1++;
                    }
kpnub=R_1-1;
fclose(input1);
// Allocate the memory to pointers
k_x=(float*)malloc(kpnub*sizeof(float));
k_y=(float*)malloc(kpnub*sizeof(float));
k_z=(float*)malloc(kpnub*sizeof(float));
frequency=(float*)malloc(kpnub*sizeof(float));
sprintf (filename, "out/file_creation/K_points.dat");
if ((input1 = fopen(filename,"r")) == NULL) {
	printf ("opening %s failed\n", filename);
	exit (1);
}
for(i=0;i<kpnub;i++){
                     fscanf(input1,"%f %f %f %f",&(k_x[i]),&(k_y[i]),&(k_z[i]),&(frequency[i]));
                     }
//for(i=0;i<10;i++){
//          printf("%f\t%f\t%f\n",k_x[i],k_y[i],k_z[i]);
//          }
fclose(input1);
// The reciprocal lattice vectors
//V=a_1*(b_2*c_3-c_2*b_3)+a_2*(b_3*c_1-b_1*c_3)+a_3*(b_1*c_2-c_1*b_2); // Cell volume
R_1x=(2.0*PI/V)*(b_2*c_3-c_2*b_3);
R_1y=(2.0*PI/V)*(b_3*c_1-b_1*c_3);
R_1z=(2.0*PI/V)*(b_1*c_2-b_2*c_1);
R_2x=(2.0*PI/V)*(a_3*c_2-c_3*a_2);
R_2y=(2.0*PI/V)*(a_1*c_3-a_3*c_1);
R_2z=(2.0*PI/V)*(c_1*a_2-a_1*c_2);
R_3x=(2.0*PI/V)*(a_2*b_3-a_3*b_2);
R_3y=(2.0*PI/V)*(a_3*b_1-a_1*b_3);
R_3z=(2.0*PI/V)*(a_1*b_2-a_2*b_1);
kp_x=VLen(R_1x,R_1y,R_1z);
kp_y=VLen(R_2x,R_2y,R_2z);
kp_z=VLen(R_3x,R_3y,R_3z);
printf("Lattice constants of the system are (unit in Angstrm)\n");
printf("%f\t%f\t%f\n",a_1,a_2,a_3);
printf("%f\t%f\t%f\n",b_1,b_2,b_3);
printf("%f\t%f\t%f\n",c_1,c_2,c_3);
printf("Cell volume(cubic angstrom)=%f\n",V);
printf("The reciprocal lattice vectors are (unit in Angstrom^(-1))\n");
printf("%f\t%f\t%f\n",R_1x,R_1y,R_1z);
printf("%f\t%f\t%f\n",R_2x,R_2y,R_2z);
printf("%f\t%f\t%f\n",R_3x,R_3y,R_3z);
printf("The lengths of reciprocal vectors in three principal directions are\n");
printf("[100]=%f\t[010]=%f\t[001]=%f\n",kp_x,kp_y,kp_z);
printf("Total number of rows in your input file=%d\n",kpnub);
// Compute the coordinates of k points using reciprocal lattice vectors
printf("Coordinates of some kpoints\n");
output=fopen("out/group_and_phase_velocities/K_coordinates.dat","w");
output1=fopen("out/group_and_phase_velocities/Velocities.dat","w");
output2=fopen("out/group_and_phase_velocities/X-Velocity.dat","w");
output3=fopen("out/group_and_phase_velocities/Y-Velocity.dat","w");
output4=fopen("out/group_and_phase_velocities/Z-Velocity.dat","w");
output5=fopen("out/group_and_phase_velocities/XYZ-phase.dat","w");
output6=fopen("out/group_and_phase_velocities/XYZ-group.dat","w");
for(j=0;j<3*N_t;j++){
 //                  Weig=0.0;
                   for(i=j*M_k;i<(j+1)*M_k;i++){
                                        Kp_x=0.5*2.0*(k_x[i]*R_1x+k_y[i]*R_1y+k_z[i]*R_1z);
                                        Kp_y=0.5*2.0*(k_x[i]*R_2x+k_y[i]*R_2y+k_z[i]*R_2z);
                                        Kp_z=0.5*2.0*(k_x[i]*R_3x+k_y[i]*R_3y+k_z[i]*R_3z);
                                        kp=VLen(Kp_x,Kp_y,Kp_z);
                                        omega=frequency[i];
//                                        Weig+=weight[i];
// Compute Phase velocites                      
                                        if(Kp_x==0.0&&Kp_y!=0.0&&Kp_z!=0.0){
                                                                        v_px=0.0000;
                                                                        v_py=omega*100.0/Kp_y;
                                                                        v_pz=omega*100.0/Kp_z;
                                                                        v_p=VLen(v_px,v_py,v_pz);
                                                                        }             
                                        else if(Kp_y==0.0&&Kp_x!=0.0&&Kp_z!=0.0){
                                                                            v_py=0.0000;
                                                                            v_px=omega*100.0/Kp_x;
                                                                            v_pz=omega*100.0/Kp_z;
                                                                            v_p=VLen(v_px,v_py,v_pz);
                                                                            }
                                        else if(Kp_z==0.0&&Kp_x!=0.0&&Kp_y!=0.0){
                                                                            v_pz=0.0000;
                                                                            v_px=omega*100.0/Kp_x;
                                                                            v_py=omega*100.0/Kp_y;
                                                                            v_p=VLen(v_px,v_py,v_pz);
                                                                            }
                                        else if(Kp_x==0.0&&Kp_y==0.0&&Kp_z==0.0){
                                                                                 v_px=0.0;
                                                                                 v_py=0.0;
                                                                                 v_pz=0.0;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }
                                        else if(Kp_x==0.0&&Kp_y==0.0&&Kp_z!=0.0){
                                                                                 v_px=0.0;
                                                                                 v_py=0.0;
                                                                                 v_pz=omega*100.0/Kp_z;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }
                                        else if(Kp_x!=0.0&&Kp_y==0.0&&Kp_z==0.0){
                                                                                 v_py=0.0;
                                                                                 v_pz=0.0;
                                                                                 v_px=omega*100.0/Kp_x;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }
                                        else if(Kp_x==0.0&&Kp_y!=0.0&&Kp_z==0.0){
                                                                                 v_px=0.0;
                                                                                 v_pz=0.0;
                                                                                 v_py=omega*100.0/Kp_y;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }
                                        else if(Kp_x!=0.0&&Kp_y!=0.0&&Kp_z!=0.0){
                                                                                 v_px=omega*100.0/Kp_x;
                                                                                 v_py=omega*100.0/Kp_y;
                                                                                 v_pz=omega*100.0/Kp_z;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }                                                         
// Compute group velocity
                                // The first point of each phonon branch
                                        if(i==j*M_k){
                                                  Kp_x1=0.5*2.0*(k_x[i+1]*R_1x+k_y[i+1]*R_1y+k_z[i+1]*R_1z);
                                                  Kp_y1=0.5*2.0*(k_x[i+1]*R_2x+k_y[i+1]*R_2y+k_z[i+1]*R_2z);
                                                  Kp_z1=0.5*2.0*(k_x[i+1]*R_3x+k_y[i+1]*R_3y+k_z[i+1]*R_3z);
                                                  h_x=Kp_x1-Kp_x;
                                                  h_y=Kp_y1-Kp_y;
                                                  h_z=Kp_z1-Kp_z;
                                                  if(h_x==0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i])/h_x);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i])/h_y);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i])/h_x);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i])/h_y);
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                //  kp_d=f(Kp_x1,Kp_y1,Kp_z1);
                                                //  h=kp_d-kp;
                                                //  v_g=100.0*fabs((frequency[i]+frequency[i+1])/h);
                                                                                   }
                               // Those points between first and last point in each phonon dispersion
                                        else if(i!=(j+1)*M_k-1&&i!=j*M_k){
                                                                      Kp_x1=0.5*2.0*(k_x[i+1]*R_1x+k_y[i+1]*R_1y+k_z[i+1]*R_1z);
                                                                      Kp_y1=0.5*2.0*(k_x[i+1]*R_2x+k_y[i+1]*R_2y+k_z[i+1]*R_2z);
                                                                      Kp_z1=0.5*2.0*(k_x[i+1]*R_3x+k_y[i+1]*R_3y+k_z[i+1]*R_3z);
                                                                      Kp_x2=0.5*2.0*(k_x[i-1]*R_1x+k_y[i-1]*R_1y+k_z[i-1]*R_1z);
                                                                      Kp_y2=0.5*2.0*(k_x[i-1]*R_2x+k_y[i-1]*R_2y+k_z[i-1]*R_2z);
                                                                      Kp_z2=0.5*2.0*(k_x[i-1]*R_3x+k_y[i-1]*R_3y+k_z[i-1]*R_3z);
                                                                      h_x=Kp_x1-Kp_x2;
                                                                      h_y=Kp_y1-Kp_y2;
                                                                      h_z=Kp_z1-Kp_z2;
                                                   if(h_x==0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                                /*      v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                      v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                      v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                      v_g=f(v_gx,v_gy,v_gz);
                                                                     // Below is the old method, k vector is treated as a scalor 
                                                                     // kp_d1=f(Kp_x1,Kp_y1,Kp_z1);
                                                                     // kp_d2=f(Kp_x2,Kp_y2,Kp_z2);
                                                                     // h=kp_d1-kp_d2;
                                                                     // v_g=100.0*fabs((frequency[i+1]-frequency[i-1])/h); */
                                                                      } 
                               // The last data in each phonon dispersion
                                        else if(i==(j+1)*M_k-1){
                                                              Kp_x1=0.5*2.0*(k_x[i-1]*R_1x+k_y[i-1]*R_1y+k_z[i-1]*R_1z);
                                                              Kp_y1=0.5*2.0*(k_x[i-1]*R_2x+k_y[i-1]*R_2y+k_z[i-1]*R_2z);
                                                              Kp_z1=0.5*2.0*(k_x[i-1]*R_3x+k_y[i-1]*R_3y+k_z[i-1]*R_3z);
                                                              h_x=Kp_x1-Kp_x;
                                                              h_y=Kp_y1-Kp_y;
                                                              h_z=Kp_z1-Kp_z;
                                                   if(h_x==0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                                                   v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  /*
                                                              v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                              v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                              v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                              v_g=f(v_gx,v_gy,v_gz);
                                                             // kp_d=f(Kp_x1,Kp_y1,Kp_z1);
                                                             // h=kp_d-kp;
                                                             // v_g=100.0*fabs((frequency[i]-frequency[i-1])/h); */
                                                             } 
// Done
                     if(i<201){
                             printf("%f\t%f\t%f\t%f\t%f\t%lf\t%lf\n",Kp_x,Kp_y,Kp_z,kp,omega,v_p,v_g);
                             }
                     if(options==1){
                                    fprintf(output,"%f\t%f\t%f\t%f\t%f\n",Kp_x,Kp_y,Kp_z,kp,omega*2.0*PI);
                                    fprintf(output1,"%lf\t%lf\t%lf\t%lf\n",kp,omega*2.0*PI,v_p*2.0*PI,v_g*2.0*PI);
                                    fprintf(output2,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_px*2.0*PI,v_gx*2.0*PI);
                                    fprintf(output3,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_py*2.0*PI,v_gy*2.0*PI);
                                    fprintf(output4,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_pz*2.0*PI,v_gz*2.0*PI);
                                    fprintf(output5,"%f\t%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_px*2.0*PI,v_py*2.0*PI,v_pz*2.0*PI);
                                    fprintf(output6,"%f\t%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_gx*2.0*PI,v_gy*2.0*PI,v_gz*2.0*PI);
                                    }
                     else if(options==2){
                                         fprintf(output,"%f\t%f\t%f\t%f\t%f\n",Kp_x,Kp_y,Kp_z,kp,omega);
                                         fprintf(output1,"%lf\t%lf\t%lf\t%lf\n",kp,omega,v_p,v_g);
                                         fprintf(output2,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_px,v_gx);
                                         fprintf(output3,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_py,v_gy);
                                         fprintf(output4,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_pz,v_gz);
                                         fprintf(output5,"%f\t%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_px,v_py,v_pz);
                                         fprintf(output6,"%f\t%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_gx,v_gy,v_gz);
                                         }
                                                   }
                  }
printf("k_x\tk_y\tk_z\tk_module\tfrequency(THz)\tv_p (m/s)\tv_g (m/s)\n");
//printf("Total weight of k-points is=%f\n",Weig);
printf("Please make sure that the sum of weights of all kpoints is equal to 1\n");
fclose(output);
fclose(output1);
fclose(output2);
fclose(output3);
fclose(output4);
fclose(output5);
fclose(output6);
free(k_x); free(k_y); free(k_z); free(frequency);
printf("All calculations are finished\n");
printf("Results are stored in files\n");
printf("Thanks for using this code\n");
}

void Velocities1 ()
{
int i,j,l;
int R_1;
int kpnub; // total number of k points
int options; // unit conversion
float La_x[MAX_vel],La_y[MAX_vel],La_z[MAX_vel]; // Lattice vectors
float *k_x,*k_y,*k_z,*frequency; // The fractional coordinates of each k point
float weight[MAX_vel]; // The weight of k point
float Weig; //total weight
// Reciprocal lattice vectors
float R_1x, R_1y, R_1z; // Reciprocal lattice vectors in [100] direction
float R_2x, R_2y, R_2z; // Reciprocal lattice vectors in [010] direction
float R_3x, R_3y, R_3z; // Reciprocal lattice vectors in [001] direction
double V; // cell volume
double omega; //Phonon frequency;
double v_px, v_py, v_pz; // The three components of the phase velocity
double v_gx, v_gy, v_gz; // The three components of the group velocity
double v_p, v_g; // Phase and group velocities
double h, h_1, h_2; // Deriative step
double h_x, h_y, h_z; // the step of k vector in each direction
int N; // Total number of atoms in the cell
int M; // total number of kpoints in the phonon spectrum
float a_1, a_2, a_3;
float b_1, b_2, b_3;
float c_1, c_2, c_3;
float kp_x, kp_y, kp_z; // k vector lengths, k_x, k_y and k_z
float Kp_x, Kp_y, Kp_z; // Coordinates of k points in phonon dispersions
float Kp_x1, Kp_y1, Kp_z1; // Numerical differential only purpose
float Kp_x2, Kp_y2, Kp_z2;
float kp; // Module of k vector
float kp_d, kp_d1, kp_d2; // Module of ext k vector
float dummy1, dummy2, dummy3, dummy4;
double x, y, z;
float f(double, double, double); // sqrt(x^2+y^2+z^2)

printf("/*----------------------------------------------------------------------*/\n"); 
printf("/*              This Program is written by Bing Xiao                    */\n");
printf("/*                   Department of Physics                              */\n");
printf("/*                    Temple University                                 */\n");
printf("/*                    b.xiao@ucl.ac.uk                                  */\n");
printf("/*                        2015-10-30                                    */\n");
printf("/*-------------------PROPERTIES COMPUTED--------------------------------*/\n"); 
printf("/*             PHASE VELOCITY   AND   GROUP VELOCITY                    */\n");
printf("/*                  USING FINITE DIFFERENCE METHOD                      */\n");
printf("/*-----------------PLEASE CITE THE FOLLOWING PAPER----------------------*/\n");
printf("/*           Y.Ding, B.Xiao, RSC Advances,5,18391(2015)                 */\n");
printf("/*---------------------IMPORTANCE NOTICE--------------------------------*/\n");
printf("/*          ONLY APPLIES TO THE PRINCIPAL DIRECTIONS                    */\n");
printf("/*                  [100], [010] and [001]                              */\n");
printf("/*       THE RESULTS MAY NOT RIGHT FOR OTHER DIRECTIONS                 */\n");
printf("/*----------------------------------------------------------------------*/\n");       
printf("Input the following parameters\n");
N = Natoms;
printf("Enter the total number of atoms in your system (MUST BE AN INTEGER): %d\n", N);
//scanf("%d",&N);
M = Nkpoints;
printf("Enter the total number of kpoints in each phonon dispersion (MUST BE AN INTEGER): %d\n", M);
//scanf("%d",&M);
printf("########################################################################\n");
printf("Default unit of phonon frequency in Phononpy is THz.\n");
printf("If the results are used for thermal conductivity, please choose 2.\n");
printf("A factor 2.0*PI will be multiplied to frequency and velocities by code. \n");
options = frqcUnt;
printf("Unit of the phonon frequency: THz(1) or 2PI*THz(2): %d\n", options);
//scanf("%d",&options);     
printf("########################################################################\n");
FILE *input;
FILE *input1;
FILE *output;
FILE *output1;
FILE *output2;
FILE *output3;
FILE *output4;
FILE *output5;
FILE *output6;
input=fopen("in/Lattice_vectors.dat","r");
if (input == NULL) {
	printf ("in/Lattice_vectors.dat does not exist\n");
	exit (1);
}
// The lattice parameters of the crystal structure
i=0;
while(fscanf(input,"%f %f %f",&La_x[i],&La_y[i],&La_z[i])!=EOF){
                   i=i+1;
                   }
a_1=La_x[0],a_2=La_y[0],a_3=La_z[0];
b_1=La_x[1],b_2=La_y[1],b_3=La_z[1];
c_1=La_x[2],c_2=La_y[2],c_3=La_z[2];
fclose(input);
// Determine the structural of data
input1=fopen("out/file_creation/K_points.dat","r");
if (input1 == NULL) {
	printf ("out/file_creation/K_points.dat does not exist\n");
	exit (1);
}
R_1=0;
while(!feof(input1)){
                    fscanf(input1,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                    R_1++;
                    }
kpnub=R_1-1;
fclose(input1);
// Allocate the memory to pointers
k_x=(float*)malloc(kpnub*sizeof(float));
k_y=(float*)malloc(kpnub*sizeof(float));
k_z=(float*)malloc(kpnub*sizeof(float));
frequency=(float*)malloc(kpnub*sizeof(float));
input1=fopen("out/file_creation/K_points.dat","r");
for(i=0;i<kpnub;i++){
                     fscanf(input1,"%f %f %f %f",&(k_x[i]),&(k_y[i]),&(k_z[i]),&(frequency[i]));
                     }
//for(i=0;i<10;i++){
//          printf("%f\t%f\t%f\n",k_x[i],k_y[i],k_z[i]);
//          }
fclose(input1);
// The reciprocal lattice vectors
V=a_1*(b_2*c_3-c_2*b_3)+a_2*(b_3*c_1-b_1*c_3)+a_3*(b_1*c_2-c_1*b_2); // Cell volume
R_1x=(2.0*PI/V)*(b_2*c_3-c_2*b_3);
R_1y=(2.0*PI/V)*(b_3*c_1-b_1*c_3);
R_1z=(2.0*PI/V)*(b_1*c_2-b_2*c_1);
R_2x=(2.0*PI/V)*(a_3*c_2-c_3*a_2);
R_2y=(2.0*PI/V)*(a_1*c_3-a_3*c_1);
R_2z=(2.0*PI/V)*(c_1*a_2-a_1*c_2);
R_3x=(2.0*PI/V)*(a_2*b_3-a_3*b_2);
R_3y=(2.0*PI/V)*(a_3*b_1-a_1*b_3);
R_3z=(2.0*PI/V)*(a_1*b_2-a_2*b_1);
kp_x=VLen(R_1x,R_1y,R_1z);
kp_y=VLen(R_2x,R_2y,R_2z);
kp_z=VLen(R_3x,R_3y,R_3z);
//system("PAUSE");
printf("Lattice constants of the system are (unit in Angstrm)\n");
printf("%f\t%f\t%f\n",a_1,a_2,a_3);
printf("%f\t%f\t%f\n",b_1,b_2,b_3);
printf("%f\t%f\t%f\n",c_1,c_2,c_3);
printf("Cell volume(cubic angstrom)=%f\n",V);
printf("The reciprocal lattice vectors are (unit in Angstrom^(-1))\n");
printf("%f\t%f\t%f\n",R_1x,R_1y,R_1z);
printf("%f\t%f\t%f\n",R_2x,R_2y,R_2z);
printf("%f\t%f\t%f\n",R_3x,R_3y,R_3z);
printf("The lengths of reciprocal vectors in three principal directions are\n");
printf("[100]=%f\t[010]=%f\t[001]=%f\n",kp_x,kp_y,kp_z);
printf("Total number of rows in your input file=%d\n",kpnub);
// Compute the coordinates of k points using reciprocal lattice vectors
printf("Coordinates of some kpoints\n");
//system("PAUSE");
output=fopen("out/group_and_phase_velocities/K_coordinates.dat","w");
output1=fopen("out/group_and_phase_velocities/Velocities.dat","w");
output2=fopen("out/group_and_phase_velocities/X-Velocity.dat","w");
output3=fopen("out/group_and_phase_velocities/Y-Velocity.dat","w");
output4=fopen("out/group_and_phase_velocities/Z-Velocity.dat","w");
output5=fopen("out/group_and_phase_velocities/XYZ-phase.dat","w");
output6=fopen("out/group_and_phase_velocities/XYZ-group.dat","w");
for(j=0;j<3*N;j++){
//                   Weig=0.0;
                   for(i=j*M;i<(j+1)*M;i++){
                                        Kp_x=0.5*2.0*(k_x[i]*R_1x+k_y[i]*R_1y+k_z[i]*R_1z);
                                        Kp_y=0.5*2.0*(k_x[i]*R_2x+k_y[i]*R_2y+k_z[i]*R_2z);
                                        Kp_z=0.5*2.0*(k_x[i]*R_3x+k_y[i]*R_3y+k_z[i]*R_3z);
                                        kp=VLen(Kp_x,Kp_y,Kp_z);
                                        omega=frequency[i];
//                                       Weig+=weight[i];
// Compute Phase velocites                      
                                        if(Kp_x==0.0&&Kp_y!=0.0&&Kp_z!=0.0){
                                                                        v_px=0.0000;
                                                                        v_py=omega*100.0/Kp_y;
                                                                        v_pz=omega*100.0/Kp_z;
                                                                        v_p=VLen(v_px,v_py,v_pz);
                                                                        }             
                                        else if(Kp_y==0.0&&Kp_x!=0.0&&Kp_z!=0.0){
                                                                            v_py=0.0000;
                                                                            v_px=omega*100.0/Kp_x;
                                                                            v_pz=omega*100.0/Kp_z;
                                                                            v_p=VLen(v_px,v_py,v_pz);
                                                                            }
                                        else if(Kp_z==0.0&&Kp_x!=0.0&&Kp_y!=0.0){
                                                                            v_pz=0.0000;
                                                                            v_px=omega*100.0/Kp_x;
                                                                            v_py=omega*100.0/Kp_y;
                                                                            v_p=VLen(v_px,v_py,v_pz);
                                                                            }
                                        else if(Kp_x==0.0&&Kp_y==0.0&&Kp_z==0.0){
                                                                                 v_px=0.0;
                                                                                 v_py=0.0;
                                                                                 v_pz=0.0;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }
                                        else if(Kp_x==0.0&&Kp_y==0.0&&Kp_z!=0.0){
                                                                                 v_px=0.0;
                                                                                 v_py=0.0;
                                                                                 v_pz=omega*100.0/Kp_z;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }
                                        else if(Kp_x!=0.0&&Kp_y==0.0&&Kp_z==0.0){
                                                                                 v_py=0.0;
                                                                                 v_pz=0.0;
                                                                                 v_px=omega*100.0/Kp_x;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }
                                        else if(Kp_x==0.0&&Kp_y!=0.0&&Kp_z==0.0){
                                                                                 v_px=0.0;
                                                                                 v_pz=0.0;
                                                                                 v_py=omega*100.0/Kp_y;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }
                                        else if(Kp_x!=0.0&&Kp_y!=0.0&&Kp_z!=0.0){
                                                                                 v_px=omega*100.0/Kp_x;
                                                                                 v_py=omega*100.0/Kp_y;
                                                                                 v_pz=omega*100.0/Kp_z;
                                                                                 v_p=VLen(v_px,v_py,v_pz);
                                                                                 }                                                         
// Compute group velocity
                                // The first point of each phonon branch
                                        if(i==j*M){
                                                  Kp_x1=0.5*2.0*(k_x[i+1]*R_1x+k_y[i+1]*R_1y+k_z[i+1]*R_1z);
                                                  Kp_y1=0.5*2.0*(k_x[i+1]*R_2x+k_y[i+1]*R_2y+k_z[i+1]*R_2z);
                                                  Kp_z1=0.5*2.0*(k_x[i+1]*R_3x+k_y[i+1]*R_3y+k_z[i+1]*R_3z);
                                                  h_x=Kp_x1-Kp_x;
                                                  h_y=Kp_y1-Kp_y;
                                                  h_z=Kp_z1-Kp_z;
                                                  if(h_x==0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i])/h_x);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i])/h_y);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i])/h_x);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i])/h_y);
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                //  kp_d=f(Kp_x1,Kp_y1,Kp_z1);
                                                //  h=kp_d-kp;
                                                //  v_g=100.0*fabs((frequency[i]+frequency[i+1])/h);
                                                                                   }
                               // Those points between first and last point in each phonon dispersion
                                        else if(i!=(j+1)*M-1&&i!=j*M){
                                                                      Kp_x1=0.5*2.0*(k_x[i+1]*R_1x+k_y[i+1]*R_1y+k_z[i+1]*R_1z);
                                                                      Kp_y1=0.5*2.0*(k_x[i+1]*R_2x+k_y[i+1]*R_2y+k_z[i+1]*R_2z);
                                                                      Kp_z1=0.5*2.0*(k_x[i+1]*R_3x+k_y[i+1]*R_3y+k_z[i+1]*R_3z);
                                                                      Kp_x2=0.5*2.0*(k_x[i-1]*R_1x+k_y[i-1]*R_1y+k_z[i-1]*R_1z);
                                                                      Kp_y2=0.5*2.0*(k_x[i-1]*R_2x+k_y[i-1]*R_2y+k_z[i-1]*R_2z);
                                                                      Kp_z2=0.5*2.0*(k_x[i-1]*R_3x+k_y[i-1]*R_3y+k_z[i-1]*R_3z);
                                                                      h_x=Kp_x1-Kp_x2;
                                                                      h_y=Kp_y1-Kp_y2;
                                                                      h_z=Kp_z1-Kp_z2;
                                                   if(h_x==0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                                /*      v_gx=100.0*fabs((frequency[i+1]-frequency[i-1])/h_x);
                                                                      v_gy=100.0*fabs((frequency[i+1]-frequency[i-1])/h_y);
                                                                      v_gz=100.0*fabs((frequency[i+1]-frequency[i-1])/h_z);
                                                                      v_g=f(v_gx,v_gy,v_gz);
                                                                     // Below is the old method, k vector is treated as a scalor 
                                                                     // kp_d1=f(Kp_x1,Kp_y1,Kp_z1);
                                                                     // kp_d2=f(Kp_x2,Kp_y2,Kp_z2);
                                                                     // h=kp_d1-kp_d2;
                                                                     // v_g=100.0*fabs((frequency[i+1]-frequency[i-1])/h); */
                                                                      } 
                               // The last data in each phonon dispersion
                                        else if(i==(j+1)*M-1){
                                                              Kp_x1=0.5*2.0*(k_x[i-1]*R_1x+k_y[i-1]*R_1y+k_z[i-1]*R_1z);
                                                              Kp_y1=0.5*2.0*(k_x[i-1]*R_2x+k_y[i-1]*R_2y+k_z[i-1]*R_2z);
                                                              Kp_z1=0.5*2.0*(k_x[i-1]*R_3x+k_y[i-1]*R_3y+k_z[i-1]*R_3z);
                                                              h_x=Kp_x1-Kp_x;
                                                              h_y=Kp_y1-Kp_y;
                                                              h_z=Kp_z1-Kp_z;
                                                   if(h_x==0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                                                   v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z!=0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y!=0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x!=0.0&&h_y!=0.0&&h_z!=0.0){
                                                                                   v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                                                   v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                                                   v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  else if(h_x==0.0&&h_y==0.0&&h_z==0.0){
                                                                                   v_gx=0.0000;
                                                                                   v_gy=0.0000;
                                                                                   v_gz=0.0000;
                                                                                   v_g=VLen(v_gx,v_gy,v_gz);
                                                                                   }
                                                  /*
                                                              v_gx=100.0*fabs((frequency[i-1]-frequency[i])/h_x);
                                                              v_gy=100.0*fabs((frequency[i-1]-frequency[i])/h_y);
                                                              v_gz=100.0*fabs((frequency[i-1]-frequency[i])/h_z);
                                                              v_g=f(v_gx,v_gy,v_gz);
                                                             // kp_d=f(Kp_x1,Kp_y1,Kp_z1);
                                                             // h=kp_d-kp;
                                                             // v_g=100.0*fabs((frequency[i]-frequency[i-1])/h); */
                                                             } 
// Done
                     if(i<201){
                             printf("%f\t%f\t%f\t%f\t%f\t%lf\t%lf\n",Kp_x,Kp_y,Kp_z,kp,omega,v_p,v_g);
                             }
                     if(options==1){
                                    fprintf(output,"%f\t%f\t%f\t%f\t%f\n",Kp_x,Kp_y,Kp_z,kp,omega*2.0*PI);
                                    fprintf(output1,"%lf\t%lf\t%lf\t%lf\n",kp,omega*2.0*PI,v_p*2.0*PI,v_g*2.0*PI);
                                    fprintf(output2,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_px*2.0*PI,v_gx*2.0*PI);
                                    fprintf(output3,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_py*2.0*PI,v_gy*2.0*PI);
                                    fprintf(output4,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_pz*2.0*PI,v_gz*2.0*PI);
                                    fprintf(output5,"%f\t%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_px*2.0*PI,v_py*2.0*PI,v_pz*2.0*PI);
                                    fprintf(output6,"%f\t%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_gx*2.0*PI,v_gy*2.0*PI,v_gz*2.0*PI);
                                    }
                     else if(options==2){
                                         fprintf(output,"%f\t%f\t%f\t%f\t%f\n",Kp_x,Kp_y,Kp_z,kp,omega);
                                         fprintf(output1,"%lf\t%lf\t%lf\t%lf\n",kp,omega,v_p,v_g);
                                         fprintf(output2,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_px,v_gx);
                                         fprintf(output3,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_py,v_gy);
                                         fprintf(output4,"%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_pz,v_gz);
                                         fprintf(output5,"%f\t%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_px,v_py,v_pz);
                                         fprintf(output6,"%f\t%f\t%f\t%f\t%f\t%f\t%f\n",kp,k_x[i],k_y[i],k_z[i],v_gx,v_gy,v_gz);
                                         }
                                                   }
                  }
printf("k_x\tk_y\tk_z\tk_module\tfrequency(THz)\tv_p (m/s)\tv_g (m/s)\n");
//printf("Total weight of k-points is=%f\n",Weig);
printf("Please make sure that the sum of weights of all kpoints is equal to 1\n");
fclose(output);
fclose(output1);
fclose(output2);
fclose(output3);
fclose(output4);
fclose(output5);
fclose(output6);
free(k_x); free(k_y); free(k_z); free(frequency);
printf("All calculations are finished\n");
printf("Results are stored in files\n");
printf("Thanks for using this code\n");
}
