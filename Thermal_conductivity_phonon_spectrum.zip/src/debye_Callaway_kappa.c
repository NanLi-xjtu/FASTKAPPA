#include "debye_Callaway_kappa.h"

void Callway_Debye_model ()
{
	int i,j,k,l; // some integers
	int N_t; // total number of atoms in the cell
	int rows; // total number of rows in the file
	int nbands; // total number of bands in the file
	int nkpts; // total number of k-points
	int Np; // number of primitive cells in the supercell
	int elements; // number of different elements in the structure
	double Cv; // total specific heat capacity obtained from phonon frequencies;
	double Cvv; // mode-specific heat capacity
	double Tdebye; // Debye T for acoustic phonons
	double *Cac, *Cop; // acoustic and optical branches
	double *Td; //Debye temperature for each branch
	double *vg; // group velocities for each branch
	double *gamma; // Gruneisen paramater for each branch 
	float scale; // scaling constant of lattice vectors
	float a11,a12,a13; // vectors in [100]
	float a21,a22,a23;  // [010]
	float a31,a32,a33;  // [001]
	float a1,a2,a3; // lattice constants 
	float T, T_s, T_f, T_step; // Temperature in the calculation, s: starting T; f: final T and step; Increment step of T
	float V, V_a;// Cell volume and volume per atom
	double V_av; // V/N in cubic angstrom
	float d; // Grain or microstructure size
	float M_v; // total molar mass of the cell
	float M_av; // molar mass of averaged atom 
	double th_c, total; // thermal conductivity
	double th_ca, th_cb, th_cc, th_cn; // thermal conductivity due to phonon, boundary and impurity and normal process;
	double th_cd; // thermal conductivitiesue to scattering of T and L phonon by dislocations
	float *kpoint,*omega,*v_p,*v_g,*Gamma,*weight; // module of k-point, frequency, phase velocity and group velocity
	float dummy1, dummy2, dummy3, dummy4, dummy5, dummy6; // Auxiliary variables
	char file00[128];
	char file01[128];
	char file02[128];
	char file03[128];
	char coords[256];
	FILE *input00;
	FILE *input01;
	FILE *output00;
	FILE *output01;
	FILE *output;
	char file[128];
	double x, y, z, w;
	float fdebye(double); // Debye function
	float fdebye_integral(int no, float min, float max);
	float feinstein(double); // Eistein integral
	float fki_TA1(double); // Debye_Callway model partI
	float fki_TA2(double); 
//	float fki1_integral_TA(int no, float min, float max);
	float fki_LA(double);
//	float fki2_integral_LA(int no, float min, float max);
	float fki_OP(double);
	printf("/*       ################################################               */\n");
	printf("/*       #   Thermal Conductivity from Phonon Spectrum  #               */\n");
	printf("/*       #      Parameter-free Debye-Callway Model      #               */\n"); 
	printf("/*       #          Version 1.0: 2016-09-13             #               */\n");
	printf("/*       #   Latest Update Made: 2020-09-20             #               */\n");
	printf("/*       ################################################               */\n");
	printf("/*----------------------------------------------------------------------*/\n");
	printf("/*          Implemented by BING XIAO from XJTU-SSE                      */\n");
	printf("/*                  bingxiao84@xjtu.edu.cn                              */\n");
	printf("/*----------------------------------------------------------------------*/\n");
	N_t = Natoms;
	printf("Enter Number of atoms in the structure: %d\n", N_t);
//	scanf("%d",&N_t);
	elements = Nelemt;
	printf("Enter number of different elements: %d\n", elements);
//	scanf("%d",&elements);
	Np = Ncells_primtv;
	printf("Number of primitive cells in the supercell: %d\n", Np);
//	scanf("%d",&Np);
	M_v = molcl_weit;
	printf("Molecular weight of cell: %f\n", M_v);
//	scanf("%f",&M_v);
	T_s = stprt;
	T_f = fntprt;
	T_step = icmtprt;
	printf("Input parameters for Temperatures\n");
	printf("Onset T  Final T and T_step %f %f %f\n", T_s,T_f,T_step);
//	scanf("%f %f %f",&T_s,&T_f,&T_step);
//	read lattice vectors and compute cell volumes
	sprintf(file01,"in/CONTCAR_2");
	input01=fopen(file01,"r");
	sprintf(file02,"out/phonon_thermal_conductivity/method%d/Phonon_parameters.dat", methods_theml);
	output00=fopen(file02,"w");
	if(input01==NULL){
		perror("Error while opening the file.\n");
		printf("Can not open file:%s in the current folder!\n",file01);
		printf("Program is now terminated\n");
		exit(EXIT_FAILURE);
	} else{
		printf("File %s is loaded.\n",file01);
		j=0;
		while(fgets(coords,256,input01)!=NULL) {              
			if(j==1) sscanf(coords,"%f",&scale);
			else if(j==2) sscanf(coords,"%f %f %f",&a11,&a12,&a13);
			else if(j==3) sscanf(coords,"%f %f %f",&a21,&a22,&a23);
			else if(j==4) sscanf(coords,"%f %f %f",&a31,&a32,&a33);
             	   j++;
		}
	}
// Calculate lattice parameters and cell volume
   printf("-----------------------------------\n");
   printf("         Lattice vectors           \n");
   printf("%f %f %f\n",a11*scale,a12*scale,a13*scale);
   printf("%f %f %f\n",a21*scale,a22*scale,a23*scale);
   printf("%f %f %f\n",a31*scale,a32*scale,a33*scale);
   a1=VLen(a11,a12,a13)*scale;
   a2=VLen(a21,a22,a23)*scale;
   a3=VLen(a31,a32,a33)*scale;
   V=(a11*(a22*a33-a32*a23)-a12*(a21*a33-a31*a23)+a13*(a21*a32-a31*a22))*(scale*scale*scale);
   V_a=V/(float)(N_t);
   V_av=V*pow(10,-30.0)/((float)N_t);  // Volume per atom in cubic meter
   M_av=(float)(M_v/N_t);   // Atomic mass per averged atom
   printf("------------------------------------\n");
   printf("         Lattice constants          \n");
   printf("a=%f b=%f c=%f\n",a1,a2,a3);
   printf("Cell volume:%f\n",V);
   printf("Cell volume per atom:%f\n",V_a);
   printf("Molecular weight per atom:%f\n",M_av);
   fprintf(output00,"Lattice vectors\n");
   fprintf(output00,"%f\n",scale);
   fprintf(output00,"%f\t%f\t%f\n",a11,a12,a13);
   fprintf(output00,"%f\t%f\t%f\n",a21,a22,a23);
   fprintf(output00,"%f\t%f\t%f\n",a31,a32,a33);
   fprintf(output00,"%d\n",N_t); 
   fprintf(output00,"Volumes\n");
   fprintf(output00,"%f\t%f\n",V,V_a);
   fprintf(output00,"Molecular weight\n");
   fprintf(output00,"%f\t%f\n",M_v,M_av);  
// Read the input data from the file "out/phonon_thermal_conductivity/Inputs_kappa_cal.dat"
 sprintf(file00,"out/phonon_thermal_conductivity/Inputs_kappa_cal.dat");
 input00=fopen(file00,"r");
 if(input00==NULL){
                   perror("Error while opening the file.\n");
                   printf("Can not open file:%s in the current folder!\n",file00);
		   printf("Program is now terminated\n");
                   exit(EXIT_FAILURE);
                   }
 else{
        printf("File %s ls loaded.\n",file00);
        int R_2=0;
        while(!feof(input00)){
                            fscanf(input00,"%f %f %f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4, &dummy5, &dummy6);
                             R_2++;
                            }
        rows=R_2-1;
        nkpts=rows/(N_t*3); // total number of kpoints in each bands
        nbands=N_t*3;  // total number of bands in the input file
        printf("Importing data is done.\n");
        printf("Total number of rows=%d\n",rows);
        printf("Total number of phonon dispersions=%d\n",nbands);
        printf("Total number of kpoints in each band=%d\n",nkpts);
        fclose(input00);
// import the raw data in the array
        kpoint=(float*)malloc(rows*sizeof(float));
        omega=(float*)malloc(rows*sizeof(float));
        v_p=(float*)malloc(rows*sizeof(float));
        v_g=(float*)malloc(rows*sizeof(float));
        Gamma=(float*)malloc(rows*sizeof(float));
        weight=(float*)malloc(rows*sizeof(float));
        input00=fopen(file00,"r");
        for(j=0;j<rows;j++){
                            fscanf(input00,"%f %f %f %f %f %f",&(kpoint[j]),&(omega[j]),&(v_p[j]),&(v_g[j]),&(Gamma[j]),&(weight[j]));
                           }
        fclose(input00);
        printf("Check the inputs, the last 50 lines will be shown here.\n");
        for(i=rows-50;i<rows;i++){
                                printf("%f\t%f\t%f\t%f\t%f\t%f\n",kpoint[i],omega[i],v_p[i],v_g[i],Gamma[i],weight[i]);
                                }
       }
// calculate the total specific heat for optical and acoustic branches Cv(acoustic) and Cv(optical)
// calculate Debye temperature for each phonon branches;
   Cac=(double*)malloc(nbands*sizeof(double));
   Cop=(double*)malloc(nbands*sizeof(double));
   Td=(double*)malloc(nbands*sizeof(double));
   vg=(double*)malloc(nbands*sizeof(double));
   gamma=(double*)malloc(nbands*sizeof(double));
   for(i=0;i<nbands;i++){
                         Cac[i]=0.;
                         Cop[i]=0.;
                         Td[i]=0.;
                         vg[i]=0.;
                         gamma[i]=0.;
						}
   double fq;
   double sumTd;
   double fe; // Einstrein fequency;
   double sumfe;
   double acountfe;
   double sumvg, sumgamma;
   double sumvg_op, sumgamma_op; // optical branches only
   double Te; // Einstein temperature 
   double vg_op, gamma_op; // mode_average phonon group velocity and Gruneisen parameter for optical phonons
   printf("Debye Temperature for each phonon branch\n");
   printf("-----------------------------------------------\n");
   printf("Phonon_Branch    nkpt    Debye_T    Vg    Gamma\n");
   sumfe=0.000000;
   acountfe=0.000000;
   sumvg_op=0.000000; sumgamma_op=0.000000;
   fprintf(output00,"AcousticBranches\n");
   for(i=1;i<=nbands;i++){
   	                      sumTd=0.000000;
   	                      sumvg=0.000000; sumgamma=0.000000;
						  for(j=(i-1)*nkpts;j<i*nkpts;j++){
							                              //double fq;
							                              fq=(double)(omega[j]*2.0*PI*pow(10.0,12));
														  sumTd += (h_r*fq)/k_b;
														  //sumvg += v_g[j]; 
														  sumvg += sqrt(v_g[j]*v_p[j]);
														  sumgamma += Gamma[j]*Gamma[j];
														  }
						  double sumn=(double)(nkpts);
						  Td[i-1]=sumTd/sumn;
						  vg[i-1]=sumvg/sumn;
						  gamma[i-1]=sqrt(sumgamma/sumn);
						  printf("%d\t%d\t%lf\t%lf\t%lf\n",i,nkpts,Td[i-1],vg[i-1],gamma[i-1]);
						  fprintf(output00,"%d\t%d\t%lf\t%lf\t%lf\n",i,nkpts,Td[i-1],vg[i-1],gamma[i-1]);
						  // Find einstein temperature and frequency for optical phonons
						  if(i>3){
						          for(j=(i-1)*nkpts;j<i*nkpts;j++){
								                                   acountfe=acountfe+1.000000; 
																   sumfe += omega[j];
																   //sumvg_op += v_g[j];
																   sumvg_op += sqrt(v_p[j]*v_g[j]);
																   sumgamma_op += Gamma[j]*Gamma[j];
																  }
								 }
                          }
    fe=sumfe/acountfe;
    Te=fe*2.0*PI*pow(10.0,12)*h_r/k_b;
    vg_op=sumvg_op/acountfe;
    gamma_op=sqrt(sumgamma_op/acountfe);
	printf("-----------------------------------------------\n");
	printf("Einstein Frequency and Einstein Temperture\n");
	printf("N_Branches    f(THz)    T(K)    Vg(m/s)   Gamma\n");
	printf("%d\t%lf\t%lf\t%lf\t%lf\n",nbands-3,fe,Te,vg_op,gamma_op);
	printf("-----------------------------------------------\n");
	fprintf(output00,"OpticalBranches\n");
	fprintf(output00,"%d\t%lf\t%lf\t%lf\t%lf\n",nbands-3,fe,Te,vg_op,gamma_op);
	//fclose(output00); 
// Determine Debye T for three acoustic phonon branches
    double tmpmax;
	tmpmax=0.000000;
	for(i=0;i<=2;i++){
		             if(Td[i]>tmpmax){
		             	             tmpmax=Td[i];
									 }
	                 } 
	Tdebye=tmpmax;
	printf("Debye Temperature of Acoustic Phonons:%lf\n",Tdebye);
    printf("-----------------------------------------------\n");
    fprintf(output00,"Debye Temperature\n");
	fprintf(output00,"%lf\n",Tdebye);
    fclose(output00);
// phonon Scattering constant due to the impurities/isotopes of different elements will be calculated first
//------------------------------------------------------------------------------
int options; // options for calculting phonon-isotope scattering constant
int *N_d; 
double *im_c; // phonon-isotope scattering constant 
float *fraction;
float *mass, *radius;
float *m_a, *r_a; // mass and radius of an element;
float mass_t; 
float isotope_ph; 
printf("If there are more than one elements in the structure, you must prepare:\n");
printf("------------------------------------------------------------------------\n");
printf(" Element_1.dat, Element_2.dat and etc.\n");
printf("------------------------------------------------------------------------\n");
options = options_Deb_sca;
printf("Do you want to include scattering mechanism due to isotopes: Yes(1)or No(2)\n");
printf("Enter your option:(MUST BE AN INTEGER) %d\n", options);
//scanf("%d",&options);
if(options==1){
               FILE *input;
               FILE *output;
               int R_1;
               char files1[128];
               char files2[128];
               im_c=(double*)malloc(elements*sizeof(double));
               N_d=(int*)malloc(elements*sizeof(int));
               r_a=(float*)malloc(elements*sizeof(float));
               m_a=(float*)malloc(elements*sizeof(float));
               // first, clean the array
               for(i=0;i<elements;i++){
			                           im_c[i]=0.;
			                           N_d[i]=0.; r_a[i]=0.; m_a[i]=0.;
									  }
			   sprintf(files2,"out/phonon_thermal_conductivity/method%d/Isotope_constant.dat", methods_theml);
			   output=fopen(files2,"w");
			   fprintf(output,"Isotope_scattering_constant\n");
			   fprintf(output,"%d\n",elements);
               for(i=0;i<elements;i++){
                                        N_d[i]=0;
                                        printf("Information about all isotopes must be given in an separate file.\n");
//               printf("Enter the file name below:(Defect.dat or Isotopes.dat)\n");
//               gets(files1);
                                        sprintf(files1,"in/Element_%d.dat",i+1);
                                        input=fopen(files1,"r");
                                        if(input==NULL){
                                                        printf ("Error while opening the file %s.\n", files1);
                                                        exit(EXIT_FAILURE);
                                                        }
                                        else {
                                                printf("File %s ls loaded.\n",files1);
                                            }
                                        R_1=0;
                                        while(!feof(input)){
                                                            fscanf(input,"%f %f %f",&dummy1, &dummy2, &dummy3);
                                                            R_1++;
                                                            }
                                        N_d[i]=R_1-1;
                                        fclose(input);
                                        printf("%d\t%d\n",R_1,N_d[i]);
                                        fraction=(float*)malloc(N_d[i]*sizeof(float));
                                        mass=(float*)malloc(N_d[i]*sizeof(float));
                                        radius=(float*)malloc(N_d[i]*sizeof(float));
                                        input=fopen(files1,"r");
                                        for(j=0;j<N_d[i];j++){
                                                              fscanf(input,"%f %f %f",&(mass[j]),&(radius[j]),&(fraction[j]));
                                                              }
                                        fclose(input);
                                        //m_a=0.000000;
                                        //r_a=0.000000; 
                                        for(k=0;k<N_d[i];k++){
                                                              m_a[i]+=fraction[k]*mass[k];
                                                              r_a[i]+=fraction[k]*radius[k];
                                                              printf("%f\t%f\t%f\n",mass[k],radius[k],fraction[k]);
                                                              }
                                        printf("Defect related parameters:\n");
                                        printf("Average Mass\tAverage Radius(Angstrom)\n");
                                        printf("%f\t%f\n",m_a[i],r_a[i]);
                                        im_c[i]=0.000000;
                                        for(j=0;j<N_d[i];j++){
                                                              im_c[i]+=fraction[j]*((1.0-mass[j]/m_a[i])*(1.0-mass[j]/m_a[i])+(1.0-radius[j]/r_a[i])*(1.0-radius[j]/r_a[i]));
                                                             }
                                        printf("The isotope constant for element %d\n",i+1);
                                        printf("Number of isotopes: %d\n",N_d[i]);
                                        printf("%le\n",im_c[i]);
                                        printf("---------------------------------------------------------\n");
                                        fprintf(output,"%d\t%d\t%le\n",i+1,N_d[i],im_c[i]);
                                        free(fraction); free(radius); free(mass);
                                        }
                // calculate the scattering constant from all isotopes
                mass_t=0.;
                for(i=0;i<elements;i++){
				                        mass_t += m_a[i];
									   }
				isotope_ph=0.000000;
				for(i=0;i<elements;i++){
									   isotope_ph += (float)(elements)*(m_a[i]/mass_t)*(m_a[i]/mass_t)*im_c[i];
									   }
				printf("Scattering constant: %f\n",isotope_ph);
                printf("Scattering constants for isotopes are calculated!\n");
                fprintf(output,"%f\n",isotope_ph);
                fclose(output);
               }
else if(options==2){
                    isotope_ph=0.;
					printf("Scattering due to isotopes is not calculated.\n");
                    printf("No furhter information is required.\n");
                    }
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------	 
// Computing the constants in different phonon scattering mechanisms
 char files02[128];
 double *taun_ac, *taun_op; 
 double *tau_u;
 double *tau_isotope;
 double tauac, tauop;
 double tauu, tauiso;  
 double B_nl, B_nt;  // longitudinal and transverse
 double B_ui, B_s; // U-process and phonon isotope scattering
 int Ntemp; // number of different Temperatures 
 for(i=0;i<4;i++){
                      if(i==0){
					            sprintf(files02,"out/phonon_thermal_conductivity/method%d/Relaxation_constants_TA1", methods_theml);
					            output01=fopen(files02,"w");
								}
					  else if(i==1){
                                    sprintf(files02,"out/phonon_thermal_conductivity/method%d/Relaxation_constants_TA2", methods_theml);
									output01=fopen(files02,"w");					  	
					               }
					  else if(i==2){
					  	            sprintf(files02,"out/phonon_thermal_conductivity/method%d/Relaxation_constants_LA", methods_theml);
					  	            output01=fopen(files02,"w");
					               }
					  else if(i==3){
					               sprintf(files02,"out/phonon_thermal_conductivity/method%d/Relaxation_constants_OP", methods_theml);
					               output01=fopen(files02,"w");
								   }
					  Ntemp=0;
					  for(T=T_s;T<=T_f;T=T+T_step){
												  Ntemp++;
												  if(i==0||i==1){
												                 B_nt=pow(k_b,4.0)*gamma[i]*gamma[i]*V_av/((M_av*covmass)*pow(h_r,3.0)*pow(vg[i],5.0));
														         B_ui=h_r*gamma[i]*gamma[i]/((M_av*covmass)*pow(vg[i],2.0)*Td[i]);
																 tauac=B_nt*(k_b/h_r)*pow(T,5.0);
																 tauu=B_ui*(k_b/h_r)*(k_b/h_r)*pow(T,3.0)*exp(-Td[i]/(3.0*T));
																 tauiso=V_av*pow(k_b,4.0)*isotope_ph*pow(T,4.0)/(4.0*PI*pow(h_r,4.0)*vg[i]*vg[i]*vg[i]);
																//tauac=B_nt*(k_b/h_r)*(k_b/h_r);
																//tauu=B_ui*(k_b/h_r)*(k_b/h_r);
																//tauiso=V_av*pow(k_b,4.0)*isotope_ph/(4.0*PI*pow(h_r,4.0)*vg[i]*vg[i]*vg[i]); 
														         fprintf(output01,"%d\t%f\t%le\t%le\t%le\n",i,T,tauac,tauu,tauiso);
																}
												  else if(i==2){
												               B_nl=pow(k_b,3.0)*gamma[i]*gamma[i]*V_av/((M_av*covmass)*pow(h_r,2.0)*pow(vg[i],5.0));
												               B_ui=h_r*gamma[i]*gamma[i]/((M_av*covmass)*pow(vg[i],2.0)*Td[i]);
															   tauac=B_nl*(k_b/h_r)*(k_b/h_r)*pow(T,5.0);
															   tauu=B_ui*(k_b/h_r)*(k_b/h_r)*pow(T,3.0)*exp(-Td[i]/(3.0*T));
												               tauiso=V_av*pow(k_b,4.0)*isotope_ph*pow(T,4.0)/(4.0*PI*pow(h_r,4.0)*vg[i]*vg[i]*vg[i]);
															   fprintf(output01,"%d\t%f\t%le\t%le\t%le\n",i,T,tauac,tauu,tauiso);
															   }
												  else if(i==3){
												               B_nl=pow(k_b,3.0)*gamma_op*gamma_op*V_av/((M_av*covmass)*pow(h_r,2.0)*pow(vg_op,5.0));
												               B_ui=h_r*gamma_op*gamma_op/((M_av*covmass)*pow(vg_op,2.0)*Te);
															   tauop=B_nl*(k_b/h_r)*(k_b/h_r)*pow(T,5.0);
															   tauu=B_ui*(k_b/h_r)*(k_b/h_r)*pow(T,3.0)*exp(-Te/(3.0*T));
															   tauiso=V_av*pow(k_b,4.0)*isotope_ph*pow(T,4.0)/(4.0*PI*pow(h_r,4.0)*pow(vg_op,3.0));
												               fprintf(output01,"%d\t%f\t%le\t%le\t%le\n",i,T,tauop,tauu,tauiso);
															  }
												  }
					fclose(output01);       
					}
// calculate the integrals
   double cv_aco; // heat capacity of acoustic phonons
   double cv_opt;  // heat capacity of optical phonons
   double kappa;
   sprintf(file,"out/phonon_thermal_conductivity/method%d/Debye_Callaway_kappa.dat", methods_theml);
   output=fopen(file,"w");
   fprintf(output,"T(K)\tTA1(W/m.K)\tTA2(W/m.K)\tLA(W/m.K)\tOP(W/m.K)\tTotal(W/m.K)\n");
   for(T=T_s;T<=T_f;T=T+T_step){
                               double max_debye=Tdebye/T;
							   double opt_debye=Te/T;
							   cv_aco=3.0*k_b*((float)Np)*(3.0/pow(max_debye,3.0))*fdebye_integral(max_in,vmin,max_debye)/(V_av);
							   cv_opt=(3.0*((float)N_t)-3.0)*((float)Np)*k_b*feinstein(opt_debye)/(V_av);
							   kappa=(cv_aco/(cv_aco+cv_opt))*(fki_TA1(T)+fki_TA2(T)+fki_LA(T))*(1.0/3.0)+(cv_opt/(cv_aco+cv_opt))*fki_OP(T);
							   printf("%f\t%le\t%le\t%le\t%le\t%le\n",T,fki_TA1(T),fki_TA2(T),fki_LA(T),fki_OP(T),kappa);
							   printf("%f\t%le\t%le\n",T,cv_aco,cv_opt);
							   fprintf(output,"%f\t%le\t%le\t%le\t%le\t%le\n",T,fki_TA1(T),fki_TA2(T),fki_LA(T),fki_OP(T),kappa);
							   }
fclose(output);
free(gamma); free(Td); free(vg);
free(Cac); free(Cop);
printf("All Calculations are Completed\n");
printf("Press ENTER key to exit the program\n");
}

// Debye function
float fdebye(double x)
{
   return pow(x,4.0)*exp(x)/((exp(x)-1.0)*(exp(x)-1.0));
      }
// Integration of Debye function
float fdebye_integral(int no, float min, float max)
{  
   int n;				 
   float interval0, sum_0=0., t0;
   interval0 = ((max-min)/(no-1));
   
   for (n=2; n<no; n+=2)                /* loop for even points  */
   {
       t0 = interval0*(n-1);
       sum_0 += 4*fdebye(t0);
   }
   for (n=3; n<no; n+=2)                /* loop for odd points  */
   {
      t0 = interval0*(n-1);
      sum_0 += 2*fdebye(t0);
   }   
   sum_0 +=  fdebye(min) + fdebye(max);	 	/* add first and last value */          
   sum_0 *= interval0/3.;        		/* then multilpy by interval*/
   return (sum_0);
} 
float feinstein(double x)
{
	return pow(x,2.0)*exp(x)/((exp(x)-1.0)*(exp(x)-1.0)); 
 } 
// Debye-Callway model kernel funtion for TA1
float fki_TA1(double x)
{
	char TA1_file0[128];
	char coords0[256];
	FILE *input_TA1;
	FILE *input_TA;
	int i,j;
	int rows1;
	int R_TA1;
	int dummy,dummy00;
	int N; // total number of atoms 
	float dummy01;
	double dummy02, dummy03, dummy04;
	int *band;
	float *Temp;
	double *tau_N, *tau_U, *tau_iso;
	double theta_TA1; // Debye temperature
	double vg_TA1; // group velocity
	// read the data from input file
	sprintf(TA1_file0,"out/phonon_thermal_conductivity/method%d/Relaxation_constants_TA1", methods_theml);
	input_TA1=fopen(TA1_file0,"r");
	if(input_TA1==NULL){
                        perror("Error while opening the file.\n");
                        printf("Can not open file:%s\n",TA1_file0);
                        exit(EXIT_FAILURE);
                        }
    else {
          printf("File %s ls loaded.\n",TA1_file0);
        }
    R_TA1=0;
    while(!feof(input_TA1)){
                        fscanf(input_TA1,"%d %f %le %le %le",&dummy00,&dummy01,&dummy02,&dummy03,&dummy04);
                        R_TA1++;
                        }
    rows1=R_TA1-1;
    fclose(input_TA1);
    band=(int*)malloc(rows1*sizeof(int));
    Temp=(float*)malloc(rows1*sizeof(float));
    tau_N=(double*)malloc(rows1*sizeof(double));
    tau_U=(double*)malloc(rows1*sizeof(double));
    tau_iso=(double*)malloc(rows1*sizeof(double));
	input_TA1=fopen(TA1_file0,"r");
	for(i=0;i<rows1;i++){
	                    fscanf(input_TA1,"%d %f %le %le %le",&(band[i]),&(Temp[i]),&(tau_N[i]),&(tau_U[i]),&(tau_iso[i]));
						}
	fclose(input_TA1);
//  read the Debye temperature
    char TA1_file1[128];
    sprintf(TA1_file1,"out/phonon_thermal_conductivity/method%d/Phonon_parameters.dat", methods_theml);
    input_TA=fopen(TA1_file1,"r");
    if(input_TA==NULL){
                      perror("Error while opening the file.\n");
                      printf("Can not open file:%s in the current folder!\n",TA1_file1);
				      printf("Program is now terminated\n");
                      exit(EXIT_FAILURE);
				      }
    else{
         printf("File %s is loaded.\n",TA1_file1);
         j=0;
         while(fgets(coords0,256,input_TA)!=NULL){              
                                             if(j==5){
												      sscanf(coords0,"%d",&N);
													  //printf("%d\n",N);
													 }
											 else if(j==11){
												 	       sscanf(coords0,"%d %d %lf %lf %lf",&dummy,&dummy00,&theta_TA1,&vg_TA1,&dummy03);
												          //printf("%lf\t%lf\t%lf\n",theta_TA1,vg_TA1,dummy03);
														  }
                                             j++;
			                                }
	    }
	fclose(input_TA);
	double integral_max;
	double intstep;
	double p;
	double nstep;
	double tau_N_TA1;
	double tau_U_TA1;
	double tau_iso_TA1;
	double tau_TA1;
	double tau_R; // tau_R = 1.0/(1.0/tau_U+1.0/tau_iso)
	double sumintegral;  // kappa_i1
	double sumintegral0;
	double sumintegral1; // kappa_i2
    double cons_TA1; // constant
//	integral_max=theta/x;  
//  calculate the integral at a specified temperature
    sumintegral=0.;
    sumintegral0=0.;
    sumintegral1=0.;
	for(j=0;j<rows1;j++){
	                     if(Temp[j]==x){
						                integral_max=theta_TA1/x;
						                nstep=(double)(max_in-1.0);
										intstep=(integral_max-vmin)/(nstep);
										//sumintegral=0.;
										//printf("%f\t%f\n",Temp[j],x);
										for(p=vmin;p<=integral_max;p=p+intstep){
										                                       double pp=
																			   tau_N_TA1=(tau_N[j]*pow(p,1.0));
										                                       tau_U_TA1=(tau_U[j]*pow(p,2.0));
										                                       tau_iso_TA1=(tau_iso[j]*pow(p,4.0));
										                                       //tau_N_TA1=(tau_N[j]*pow(p,1.0))*pow(x,5.0);
										                                       //tau_U_TA1=(tau_U[j]*pow(p,2.0))*pow(x,3.0)*exp(-theta_TA1/(3.0*x));
										                                       //tau_iso_TA1=(tau_iso[j]*pow(p,4.0))*pow(x,4.0);
																			   tau_TA1=1.0/((tau_N_TA1)+(tau_U_TA1)+(tau_iso_TA1));
										                                       tau_R=1.0/((tau_U_TA1)+(tau_iso_TA1)); // not used here
																			   sumintegral += (intstep)*(tau_TA1)*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   sumintegral0 += (intstep)*(tau_TA1*tau_N_TA1)*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   //sumintegral1 += (intstep)*(tau_TA1)*pow(p,4.0)*exp(p)/((1.0/tau_N_TA1)*(tau_R)*(exp(p)-1.0)*(exp(p)-1.0));
																			   sumintegral1 += (intstep)*(tau_TA1)*pow(p,4.0)*exp(p)/((1.0/tau_N_TA1)*(1.0/tau_U_TA1)*(exp(p)-1.0)*(exp(p)-1.0));
																			   //sumintegral += intstep*1.0*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   //printf("%le\t%le\t%le\n",tau_N_TA1,tau_U_TA1,tau_iso_TA1);
																			   }   
									   } 
						}
	cons_TA1=pow(x,3.0)*pow(k_b,4.0)/(2.0*PI*PI*pow(h_r,3.0)*vg_TA1);
	free(band); free(Temp);
	free(tau_N); free(tau_U); free(tau_iso);
	//printf("%le\t%le\t%le\n",cons_TA1,sumintegral,sumintegral/sumintegral1);
	//printf("%f\t%le\n",x,cons_TA1*sumintegral);
	return cons_TA1*(sumintegral+(sumintegral0*sumintegral0)/sumintegral1); 
  } 
// Debye-Callway model kernel funtion for TA2
float fki_TA2(double x)
{
	char TA2_file0[128];
	char coords0[256];
	FILE *input_TA2;
	FILE *input_TA;
	int i,j;
	int rows_TA2;
	int R_TA2;
	int dummy,dummy00;
	int N; // total number of atoms 
	float dummy01;
	double dummy02, dummy03, dummy04;
	int *band;
	float *Temp;
	double *tau_N, *tau_U, *tau_iso;
	double theta_TA2; // Debye temperature
	double vg_TA2; // group velocity
	// read the data from input file
	sprintf(TA2_file0,"out/phonon_thermal_conductivity/method%d/Relaxation_constants_TA2", methods_theml);
	input_TA2=fopen(TA2_file0,"r");
	if(input_TA2==NULL){
                        perror("Error while opening the file.\n");
                        printf("Can not open file:%s\n",TA2_file0);
                        exit(EXIT_FAILURE);
                        }
    else {
          printf("File %s ls loaded.\n",TA2_file0);
        }
    R_TA2=0;
    while(!feof(input_TA2)){
                        fscanf(input_TA2,"%d %f %le %le %le",&dummy00,&dummy01,&dummy02,&dummy03,&dummy04);
                        R_TA2++;
                        }
    rows_TA2=R_TA2-1;
    fclose(input_TA2);
    band=(int*)malloc(rows_TA2*sizeof(int));
    Temp=(float*)malloc(rows_TA2*sizeof(float));
    tau_N=(double*)malloc(rows_TA2*sizeof(double));
    tau_U=(double*)malloc(rows_TA2*sizeof(double));
    tau_iso=(double*)malloc(rows_TA2*sizeof(double));
	input_TA2=fopen(TA2_file0,"r");
	for(i=0;i<rows_TA2;i++){
	                    fscanf(input_TA2,"%d %f %le %le %le",&(band[i]),&(Temp[i]),&(tau_N[i]),&(tau_U[i]),&(tau_iso[i]));
						}
	fclose(input_TA2);
//  read the Debye temperature
    char TA2_file1[128];
    sprintf(TA2_file1,"out/phonon_thermal_conductivity/method%d/Phonon_parameters.dat", methods_theml);
    input_TA=fopen(TA2_file1,"r");
    if(input_TA==NULL){
                      perror("Error while opening the file.\n");
                      printf("Can not open file:%s in the current folder!\n",TA2_file1);
		      printf("Program is now terminated\n");
                      exit(EXIT_FAILURE);
				      }
    else{
         printf("File %s is loaded.\n",TA2_file1);
         j=0;
         while(fgets(coords0,256,input_TA)!=NULL){              
                                             if(j==5){
												      sscanf(coords0,"%d",&N);
													  //printf("%d\n",N);
													 }
											 else if(j==12){
												 	       sscanf(coords0,"%d %d %lf %lf %lf",&dummy,&dummy00,&theta_TA2,&vg_TA2,&dummy03);
												          //printf("%lf\t%lf\t%lf\n",theta_TA1,vg_TA1,dummy03);
														  }
                                             j++;
			                                }
	    }
	fclose(input_TA);
	double integral_max;
	double intstep;
	double p;
	double nstep;
	double tau_N_TA2;
	double tau_U_TA2;
	double tau_iso_TA2;
	double tau_TA2;
	double tau_R; // tau_R = 1.0/(1.0/tau_U+1.0/tau_iso)
	double sumintegral;  // kappa_i1
	double sumintegral0;
	double sumintegral1; // kappa_i2
    double cons_TA2; // constant
//	integral_max=theta/x;  
//  calculate the integral at a specified temperature
    sumintegral=0.;
    sumintegral0=0.;
    sumintegral1=0.;
	for(j=0;j<rows_TA2;j++){
	                     if(Temp[j]==x){
						                integral_max=theta_TA2/x;
						                nstep=(double)(max_in-1.0);
										intstep=(integral_max-vmin)/(nstep);
										//sumintegral=0.;
										//printf("%f\t%f\n",Temp[j],x);
										for(p=vmin;p<=integral_max;p=p+intstep){
										                                       tau_N_TA2=(tau_N[j]*pow(p,1.0));
										                                       tau_U_TA2=(tau_U[j]*pow(p,2.0));
										                                       tau_iso_TA2=(tau_iso[j]*pow(p,4.0));
										                                       //tau_N_TA1=(tau_N[j]*pow(p,1.0))*pow(x,5.0);
										                                       //tau_U_TA1=(tau_U[j]*pow(p,2.0))*pow(x,3.0)*exp(-theta_TA1/(3.0*x));
										                                       //tau_iso_TA1=(tau_iso[j]*pow(p,4.0))*pow(x,4.0);
																			   tau_TA2=1.0/((tau_N_TA2)+(tau_U_TA2)+(tau_iso_TA2));
										                                       tau_R=1.0/((tau_U_TA2)+(tau_iso_TA2)); // not used here
																			   sumintegral += (intstep)*(tau_TA2)*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   sumintegral0 += (intstep)*(tau_TA2*tau_N_TA2)*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   //sumintegral1 += (intstep)*(tau_TA2)*pow(p,4.0)*exp(p)/((1.0/tau_N_TA2)*(tau_R)*(exp(p)-1.0)*(exp(p)-1.0));
																			   sumintegral1 += (intstep)*(tau_TA2)*pow(p,4.0)*exp(p)/((1.0/tau_N_TA2)*(1.0/tau_U_TA2)*(exp(p)-1.0)*(exp(p)-1.0));
																			   //sumintegral += intstep*1.0*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   //printf("%le\t%le\t%le\n",tau_N_TA1,tau_U_TA1,tau_iso_TA1);
																			   }   
									   } 
						}
	cons_TA2=pow(x,3.0)*pow(k_b,4.0)/(2.0*PI*PI*pow(h_r,3.0)*vg_TA2);
	//printf("%le\t%le\t%le\n",cons_TA2,sumintegral,sumintegral/sumintegral1);
	free(band); free(Temp);
	free(tau_N); free(tau_U); free(tau_iso);
	//printf("%f\t%le\n",x,cons_TA1*sumintegral);
	return cons_TA2*(sumintegral+(sumintegral0*sumintegral0)/sumintegral1); 
  } 
// Debye-Callway model kernel funtion for LA
float fki_LA(double x)
{
	char LA_file0[128];
	char coords0[256];
	FILE *input_LA1;
	FILE *input_LA;
	int i,j;
	int rows_LA;
	int R_LA;
	int dummy,dummy00;
	int N; // total number of atoms 
	float dummy01;
	double dummy02, dummy03, dummy04;
	int *band;
	float *Temp;
	double *tau_N, *tau_U, *tau_iso;
	double theta_LA; // Debye temperature
	double vg_LA; // group velocity
	// read the data from input file
	sprintf(LA_file0,"out/phonon_thermal_conductivity/method%d/Relaxation_constants_LA", methods_theml);
	input_LA1=fopen(LA_file0,"r");
	if(input_LA1==NULL){
                        perror("Error while opening the file.\n");
                        printf("Can not open file:%s\n",LA_file0);
                        exit(EXIT_FAILURE);
                        }
    else {
          printf("File %s ls loaded.\n",LA_file0);
        }
    R_LA=0;
    while(!feof(input_LA1)){
                        fscanf(input_LA1,"%d %f %le %le %le",&dummy00,&dummy01,&dummy02,&dummy03,&dummy04);
                        R_LA++;
                        }
    rows_LA=R_LA-1;
    fclose(input_LA1);
    band=(int*)malloc(rows_LA*sizeof(int));
    Temp=(float*)malloc(rows_LA*sizeof(float));
    tau_N=(double*)malloc(rows_LA*sizeof(double));
    tau_U=(double*)malloc(rows_LA*sizeof(double));
    tau_iso=(double*)malloc(rows_LA*sizeof(double));
	input_LA1=fopen(LA_file0,"r");
	for(i=0;i<rows_LA;i++){
	                    fscanf(input_LA1,"%d %f %le %le %le",&(band[i]),&(Temp[i]),&(tau_N[i]),&(tau_U[i]),&(tau_iso[i]));
						}
	fclose(input_LA1);
//  read the Debye temperature
    char LA_file1[128];
    sprintf(LA_file1,"out/phonon_thermal_conductivity/method%d/Phonon_parameters.dat", methods_theml);
    input_LA=fopen(LA_file1,"r");
    if(input_LA==NULL){
                      perror("Error while opening the file.\n");
                      printf("Can not open file:%s in the current folder!\n",LA_file1);
		      printf("Program is now terminated\n");
                      exit(EXIT_FAILURE);
				      }
    else{
         printf("File %s is loaded.\n",LA_file1);
         j=0;
         while(fgets(coords0,256,input_LA)!=NULL){              
                                             if(j==5){
												      sscanf(coords0,"%d",&N);
													  //printf("%d\n",N);
													 }
											 else if(j==13){
												 	       sscanf(coords0,"%d %d %lf %lf %lf",&dummy,&dummy00,&theta_LA,&vg_LA,&dummy03);
												          //printf("%lf\t%lf\t%lf\n",theta_TA1,vg_TA1,dummy03);
														  }
                                             j++;
			                                }
	    }
	fclose(input_LA);
	double integral_max;
	double intstep;
	double p;
	double nstep;
	double tau_N_LA;
	double tau_U_LA;
	double tau_iso_LA;
	double tau_LA;
	double tau_R; // tau_R = 1.0/(1.0/tau_U+1.0/tau_iso)
	double sumintegral;  // kappa_i1
	double sumintegral0;
	double sumintegral1; // kappa_i2
    double cons_LA; // constant
//	integral_max=theta/x;  
//  calculate the integral at a specified temperature
    sumintegral=0.;
    sumintegral0=0.;
    sumintegral1=0.;
	for(j=0;j<rows_LA;j++){
	                     if(Temp[j]==x){
						                integral_max=theta_LA/x;
						                nstep=(double)(max_in-1.0);
										intstep=(integral_max-vmin)/(nstep);
										//sumintegral=0.;
										//printf("%f\t%f\n",Temp[j],x);
										for(p=vmin;p<=integral_max;p=p+intstep){
										                                       tau_N_LA=(tau_N[j]*pow(p,2.0));
										                                       tau_U_LA=(tau_U[j]*pow(p,2.0));
										                                       tau_iso_LA=(tau_iso[j]*pow(p,4.0));
										                                       //tau_N_TA1=(tau_N[j]*pow(p,1.0))*pow(x,5.0);
										                                       //tau_U_TA1=(tau_U[j]*pow(p,2.0))*pow(x,3.0)*exp(-theta_TA1/(3.0*x));
										                                       //tau_iso_TA1=(tau_iso[j]*pow(p,4.0))*pow(x,4.0);
																			   tau_LA=1.0/((tau_N_LA)+(tau_U_LA)+(tau_iso_LA));
										                                       tau_R=1.0/((tau_U_LA)+(tau_iso_LA)); // not used here!
																			   sumintegral += (intstep)*(tau_LA)*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   sumintegral0 += (intstep)*(tau_LA*tau_N_LA)*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   //sumintegral1 += (intstep)*(tau_LA)*pow(p,4.0)*exp(p)/((1.0/tau_N_LA)*(tau_R)*(exp(p)-1.0)*(exp(p)-1.0));
																			   sumintegral1 += (intstep)*(tau_LA)*pow(p,4.0)*exp(p)/((1.0/tau_N_LA)*(1.0/tau_U_LA)*(exp(p)-1.0)*(exp(p)-1.0));
																			   //sumintegral += intstep*1.0*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   //printf("%le\t%le\t%le\n",tau_N_TA1,tau_U_TA1,tau_iso_TA1);
																			   }   
									   } 
						}
	cons_LA=pow(x,3.0)*pow(k_b,4.0)/(2.0*PI*PI*pow(h_r,3.0)*vg_LA);
	//printf("%le\t%le\t%le\n",cons_LA,sumintegral,sumintegral/sumintegral1);
	free(band); free(Temp);
	free(tau_N); free(tau_U); free(tau_iso);
	//printf("%f\t%le\n",x,cons_TA1*sumintegral);
	return cons_LA*(sumintegral+(sumintegral0*sumintegral0)/sumintegral1); 
  }
 // Debye-Callway model kernel funtion for OP
float fki_OP(double x)
{
	char OP_file0[128];
	char coords0[256];
	FILE *input_OP1;
	FILE *input_OP;
	int i,j;
	int rows_OP;
	int R_OP;
	int dummy,dummy00;
	int N; // total number of atoms 
	float dummy01;
	double dummy02, dummy03, dummy04;
	int *band;
	float *Temp;
	double *tau_N, *tau_U, *tau_iso;
	double theta_OP; // Debye temperature
	double vg_OP; // group velocity
	// read the data from input file
	sprintf(OP_file0,"out/phonon_thermal_conductivity/method%d/Relaxation_constants_OP", methods_theml);
	input_OP1=fopen(OP_file0,"r");
	if(input_OP1==NULL){
                        perror("Error while opening the file.\n");
                        printf("Can not open file:%s\n",OP_file0);
                        exit(EXIT_FAILURE);
                        }
    else {
          printf("File %s ls loaded.\n",OP_file0);
        }
    R_OP=0;
    while(!feof(input_OP1)){
                        fscanf(input_OP1,"%d %f %le %le %le",&dummy00,&dummy01,&dummy02,&dummy03,&dummy04);
                        R_OP++;
                        }
    rows_OP=R_OP-1;
    fclose(input_OP1);
    band=(int*)malloc(rows_OP*sizeof(int));
    Temp=(float*)malloc(rows_OP*sizeof(float));
    tau_N=(double*)malloc(rows_OP*sizeof(double));
    tau_U=(double*)malloc(rows_OP*sizeof(double));
    tau_iso=(double*)malloc(rows_OP*sizeof(double));
	input_OP1=fopen(OP_file0,"r");
	for(i=0;i<rows_OP;i++){
	                    fscanf(input_OP1,"%d %f %le %le %le",&(band[i]),&(Temp[i]),&(tau_N[i]),&(tau_U[i]),&(tau_iso[i]));
						}
	fclose(input_OP1);
//  read the Debye temperature
    char OP_file1[128];
    sprintf(OP_file1,"out/phonon_thermal_conductivity/method%d/Phonon_parameters.dat", methods_theml);
    input_OP=fopen(OP_file1,"r");
    if(input_OP==NULL){
                      perror("Error while opening the file.\n");
                      printf("Can not open file:%s in the current folder!\n",OP_file1);
		      printf("Program is now terminated\n");
                      exit(EXIT_FAILURE);
				      }
    else{
         printf("File %s is loaded.\n",OP_file1);
         j=0;
         while(fgets(coords0,256,input_OP)!=NULL){              
                                             if(j==5){
												      sscanf(coords0,"%d",&N);
													  //printf("%d\n",N);
													 }
											 else if(j==18){
												 	       sscanf(coords0,"%d %d %lf %lf %lf",&dummy,&dummy00,&theta_OP,&vg_OP,&dummy03);
												           //printf("%lf\t%lf\t%lf\n",theta_OP,vg_OP,dummy03);
														  }
                                             j++;
			                                }
	    }
	fclose(input_OP);
	double integral_max;
	double intstep;
	double p;
	double nstep;
	double tau_N_OP;
	double tau_U_OP;
	double tau_iso_OP;
	double tau_OP;
	double tau_R; // tau_R = 1.0/(1.0/tau_U+1.0/tau_iso)
	double sumintegral;  // kappa_i1
	double sumintegral0;
	double sumintegral1; // kappa_i2
    double cons_OP; // constant
//	integral_max=theta/x;  
//  calculate the integral at a specified temperature
    sumintegral=0.;
    sumintegral0=0.;
    sumintegral1=0.;
	for(j=0;j<rows_OP;j++){
	                     if(Temp[j]==x){
						                integral_max=theta_OP/x;
						                nstep=(double)(max_in-1.0);
										intstep=(integral_max-vmin)/(nstep);
										//sumintegral=0.;
										//printf("%f\t%f\n",Temp[j],x);
										for(p=vmin;p<=integral_max;p=p+intstep){
										                                       tau_N_OP=(tau_N[j]*pow(p,2.0));
										                                       tau_U_OP=(tau_U[j]*pow(p,2.0));
										                                       tau_iso_OP=(tau_iso[j]*pow(p,4.0));
										                                       //tau_N_TA1=(tau_N[j]*pow(p,1.0))*pow(x,5.0);
										                                       //tau_U_TA1=(tau_U[j]*pow(p,2.0))*pow(x,3.0)*exp(-theta_TA1/(3.0*x));
										                                       //tau_iso_TA1=(tau_iso[j]*pow(p,4.0))*pow(x,4.0);
																			   tau_OP=1.0/((tau_N_OP)+(tau_U_OP)+(tau_iso_OP));
										                                       tau_R=1.0/((tau_U_OP)+(tau_iso_OP));
																			   sumintegral += (intstep)*(tau_OP)*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   sumintegral0 += (intstep)*(tau_OP*tau_N_OP)*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   sumintegral1 += (intstep)*(tau_OP)*pow(p,4.0)*exp(p)/((1.0/tau_N_OP)*(tau_R)*(exp(p)-1.0)*(exp(p)-1.0));
																			   //sumintegral += intstep*1.0*pow(p,4.0)*exp(p)/((exp(p)-1.0)*(exp(p)-1.0));
																			   //printf("%le\t%le\t%le\n",tau_N_TA1,tau_U_TA1,tau_iso_TA1);
																			   }   
									   } 
						}
	cons_OP=pow(x,3.0)*pow(k_b,4.0)/(2.0*PI*PI*pow(h_r,3.0)*vg_OP);
	//printf("%le\t%le\t%le\n",cons_OP,sumintegral,sumintegral/sumintegral1);
	free(band); free(Temp);
	free(tau_N); free(tau_U); free(tau_iso);
	//printf("%f\t%le\n",x,cons_TA1*sumintegral);
	return cons_OP*(sumintegral+(sumintegral0*sumintegral0)/sumintegral1); 
  }  
/*float fki1_integral(int no, float min, float max)
{
   int n;				 
   float interval1, sum_1=0., t1;
   interval1 = ((max-min)/(no-1));
   
   for (n=2; n<no; n+=2)                /* loop for even points  */
 /*  {
       t1 = interval1*(n-1);
       sum_1 += 4*fki1(t1);
   }
   for (n=3; n<no; n+=2)                /* loop for odd points  */
 /*  {
      t1 = interval1*(n-1);
      sum_1 += 2*fki1(t1);
   }   
   sum_1 +=  fki1(min) + fki1(max);	 	/* add first and last value */          
/*   sum_1 *= interval1/3.;        		/* then multilpy by interval*/
/*   return (sum_1);
}
// Debye_Callway model kernel function part II
float fki2(double x, double y, double z, double w)
{
	return y*(1.0/(z*w))*pow(x,4.0)*exp(x)/((exp(x)-1.0)*(exp(x)-1.0));
}
float fki2_integral(int no, float min, float max)
{
   int n;				 
   float interval2, sum_2=0., t2;
   interval2 = ((max-min)/(no-1));
   
   for (n=2; n<no; n+=2)                /* loop for even points  */
/*   {
       t2 = interval2*(n-1);
       sum_2 += 4*fki2(t2);
   }
   for (n=3; n<no; n+=2)                /* loop for odd points  */
/*   {
      t2 = interval2*(n-1);
      sum_2 += 2*fki2(t2);
   }   
   sum_2 +=  fki2(min) + fki2(max);	 	/* add first and last value */          
/*   sum_2 *= interval2/3.;        		/* then multilpy by interval*/
/*   return (sum_2);	
} */
