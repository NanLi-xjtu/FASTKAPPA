// Use this program to convert CASTEP phonon spectrum data to phononpy type
// Program is written by bing xiao
// Department of Earth Sciences, University College London, London, WC1E 6BT
// Email: b.xiao@ucl.ac.uk or xbaprs@gmail.com
#include "file_creation.h"

void GetNkpoints ()
{
	FILE *input;
	char filename[128], line[1028];
	int n;

	sprintf (filename, "in/K.dat");
	if ((input = fopen (filename, "r")) == NULL) {
		printf ("%s does not exist\n", filename);
		exit (1);
	}
	n = 0;
	while (1) {
		if (fgets (line, 1028, input) == NULL) break;
		n ++;
	}
	Nkpoints = n;
}

void Inputs_creation_CASTEP()
{
      int i, j, k, l;
      int R_1, R_2, R_3;
      int rows;
      int rows1, rows2, rows3;
      int N_t;  // total number of atoms in the modelling cell
      int M_k;  // total number of k point in each dispersion
      char file1[128], file2[128], file3[128];
      char file[128];
      char filedata[128];
      float dummy1, dummy2;
      float *kpdata, *fredata;
      float *kdata1, *fre1; // volume 1
      float *kdata2, *fre2; // volume 2
      float *kdata3, *fre3;  // volume 3
      FILE *input;
      FILE *output;
      printf("/*-------------------Thermal Conducivity Project------------------*/\n");
      printf("          Formatting CASTEP phonon data to required one           */\n");
      printf("                  File created: Phonon_volume.dat                 */\n");
      printf("/*----------Other programs compatiable with output data-----------*/\n");
      printf("/*       Gruneisen_constant.cpp, Mode_Gruneisen_constant.cpp      */\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("/*                    Written by Bing Xiao                        */\n");
      printf("/*                     b.xiao@ucl.ac.uk                           */\n");
      printf("/*                         2015-11-07                             */\n");
      printf("/*     Recent Updates Timed: 2020-09-03                           */\n");
      printf("/*     bingxiao84@xjtu.edu.cn, Bing Xiao from XJTU                */\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("Enter the file names below for phonon dispersions:\n");
      printf("File name for compressed structure:(band_100_cmp.dat)\n");
//      fgets(file1, 128, stdin);
      sprintf (file1, "in/band_1.dat");
      puts (file1);
      printf("File name for undeformed structure:(band_100_min.dat)\n");
//      fgets(file2, 128, stdin);
      sprintf (file2, "in/band_2.dat");
      puts (file2);
      printf("File name for expanded structure:(band_100_exp.dat)\n");
//      fgets(file3, 128, stdin);
      sprintf (file3, "in/band_3.dat");
      puts (file3);
      printf("\n");
      N_t = Natoms;
      printf("Enter total number of atoms in the cell:(MUST BE AN INTEGER) %d\n", N_t);
//      scanf("%d",&N_t);
      M_k = Nkpoints;
      printf("Enter total number of k-points in each dispersion:(MUST BE AN INTEGER) %d\n", M_k);
//      scanf("%d",&M_k);
      rows=N_t*M_k*3+N_t*3; // This is total rows in CASTEP output data.
     // kdata1=(float*)malloc(rows*sizeof(float));
    //  fre1=(float*)malloc(rows*sizeof(float));
    //  kdata2=(float*)malloc(rows*sizeof(float));
    //  fre2=(float*)malloc(rows*sizeof(float));
    //  kdata3=(float*)malloc(rows*sizeof(float));
    //  fre3=(float*)malloc(rows*sizeof(float));
// Read the raw data
      int nfile; // total number of volumes
      int nrows[3]; // total number of rows in each input
      char files[128];
      for(nfile=1;nfile<=3;nfile++){
                                    if(nfile==1){
                                                 sprintf(file, "%s", file1);
                                                 sprintf(files,"out/file_creation/Raw_cmp.dat");
                                                 }
                                    else if(nfile==2){
                                                      sprintf(file, "%s", file2);
                                                      sprintf(files,"out/file_creation/Raw_min.dat");
                                                      }
                                    else if(nfile==3){
                                                      sprintf(file, "%s", file3);
                                                      sprintf(files,"out/file_creation/Raw_exp.dat");
                                                      }
      
                                    input=fopen(file,"r");
                                    output=fopen(files,"w");
                                    if(input==NULL){
                                                     perror("Error while opening the file.\n");
                                                     printf("Could not find file %s.\n",file);
                                                     exit(EXIT_FAILURE);
                                                     }
                                    else {
                                          printf("File %s ls loaded.\n",file);
                                         }
                                    rows1=0;
                                    i=0;
                                    while(fgets(filedata,256,input)!=NULL){
                                                                           if(i>=2){
                                                      // skip the blank line in the input data file
                                                                                    if(filedata[0]!='\n'){
                                                                                                          sscanf(filedata,"%f %f",&dummy1,&dummy2);
                                                                                                          rows1++;
                                                                                                          printf("%f\t%f\n",dummy1,dummy2);
                                                                                                          fprintf(output,"%f\t%f\n",dummy1,dummy2);
                                                                                                          }
                                                                                   }
                                                                           i++;
                                                                          }
                                    fclose(input);
                                    fclose(output);
                                    nrows[nfile-1]=rows1;
                                    printf("Number of rows in file %s=%d\n",file,nrows[nfile-1]);
                                    if(nfile==1){
                                                 kdata1=(float*)malloc(rows1*sizeof(float));
                                                 fre1=(float*)malloc(rows1*sizeof(float));
                                                 }
                                    else if(nfile==2){
                                                      kdata2=(float*)malloc(rows1*sizeof(float));
                                                      fre2=(float*)malloc(rows1*sizeof(float));
                                                      }
                                    else if(nfile==3){
                                                      kdata3=(float*)malloc(rows1*sizeof(float));
                                                      fre3=(float*)malloc(rows1*sizeof(float));
                                                      }
                                    output=fopen(files,"r");
                                    for(l=0;l<rows1;l++){
                                                         if(nfile==1){
                                                                      fscanf(output,"%f %f",&(kdata1[l]),&(fre1[l]));
                                                                      }
                                                         else if(nfile==2){
                                                                           fscanf(output,"%f %f",&(kdata2[l]),&(fre2[l]));
                                                                           }
                                                         else if(nfile==3){
                                                                           fscanf(output,"%f %f",&(kdata3[l]),&(fre3[l]));
                                                                           }
                                                         }
                                    //for(l=1;l<=(Natom*3);l++){
                                    //                          for(k=(l-1)*(kpoint+1);k<(l*kpoint+l-1);l++){
                                    //                              if(nfile==1){
                                    //                                           fscanf(output,"%f %f",&(kdata1[l]),&(fre1[l]));
                                    //                                           }
                                    //                              else if(nfile==2){
                                    //                                                fscanf(output,"%f %f",&(kdata2[l]),&(fre2[l]));
                                    //                                               }
                                    //                              else if(nfile==3){
                                    //                                                fscanf(output,"%f %f",&(kdata3[l]),&(fre3[l]));
                                    //                                                }
                                    //                                                                        }
                                    //                             }
                                    fclose(output);
                                    }
      if(nrows[0]==rows&&nrows[1]==rows&&nrows[2]==rows){
                                                         printf("/*--------------------------------------------*/\n");
                                                         printf("Phonon dipersion information are summarized:\n");
                                                         printf("Number of atoms:%d\n",N_t);
                                                         printf("Number of dispersions:%d\n",3*N_t);
                                                         printf("Number of kpoints in each dispersion:%d\n",M_k);
                                                         printf("Total number of rows in .dat file:%d\n",rows);
                                                         printf("/*--------------------------------------------*/\n");
                                                         }
      else if(nrows[0]!=rows||nrows[1]!=rows||nrows[2]!=rows){
                                                              printf("Inconsistency is found in your inputs:\n");
                                                              printf("Filename\tRows\n");
                                                              printf("%s: %d\n",file1,nrows[0]);
                                                              printf("%s: %d\n",file2,nrows[1]);
                                                              printf("%s: %d\n",file3,nrows[2]);
                                                              printf("Please check your phonon calculations.\n");
                                                              printf("Program will be terminated.\n");
                                                              exit(EXIT_FAILURE);
                                                              }
//------------------------------------------------------------------------------
// Creat file 'Phonon_volume.dat
      char file4[128];
      FILE *output1;
      sprintf(file4,"out/file_creation/Phonon_volume.dat");
      output1=fopen(file4,"w");
      for(l=1;l<=(N_t*3);l++){
                                for(k=(l-1)*(M_k+1);k<(l*M_k+l-1);k++){
                                                                             // Reset all three acoustic phonons at Gamma point to zero.
                                                                             if(k==0||k==(M_k+1)||k==(2*M_k+2)){
                                                                                                                    fre1[k]=0.000000;
                                                                                                                    fre2[k]=0.000000;
                                                                                                                    fre3[k]=0.000000;
                                                                                                                    }
                                                                             // Replacing all negative frequencies by zero, we do not like softmodes.
                                                                             if(fre1[k]<0.0){
                                                                                             fre1[k]=0.0;
                                                                                             }
                                                                             if(fre2[k]<0.0){
                                                                                             fre2[k]=0.0;
                                                                                             }
                                                                             if(fre3[k]<0.0){
                                                                                             fre3[k]=0.0;
                                                                                             }
                                                                             fprintf(output1,"%f\t%f\t%f\t%f\n",kdata2[k],fre1[k],fre2[k],fre3[k]);
                                                                             }
                                }
/*
      for(j=0;j<rows;j++){
                          //Ensuring zero frequency for the acoustic phonons at Gamma point
                          if(j==0||j==kpoint||j==2*kpoint){
                                                           fre1[j]=0.000000;
                                                           fre2[j]=0.000000;
                                                           fre3[j]=0.000000;
                                                           }
                          fprintf(output1,"%f\t%f\t%f\t%f\n",kdata2[j],fre1[j],fre2[j],fre3[j]);
                          }
                          */
      fclose(output1);
      printf("%s file is successfully created.\n",file4);
      printf("------------------------------------------------------------------\n");
// Remove trash files
      int options;
      options = rm_adundant;
      printf("Do you want to remove adundant files:Yes(1) or No(2)\n");
      printf("Enter your option:(MUST BE AN INTEGER) %d\n", options);
//      scanf("%d",&options);
      if(options==1){
                     int status1, status2, status3;
                     status1=remove("out/file_creation/Raw_cmp.dat");
                     if(status1==0){
                                    printf("File 'Raw_cmp.dat' is deleted.\n");
                                    }
                     status2=remove("out/file_creation/Raw_min.dat");
                     if(status2==0){
                                    printf("File 'Raw_min.dat' is deleted.\n");
                                    }
                     status3=remove("out/file_creation/Raw_exp.dat");
                     if(status3==0){
                                    printf("File 'out/file_creation/Raw_exp.dat' is deleted.\n");
                                    }
                     }
       else if(options==2){
                           printf("No file has been removed in the folder.\n");
                           }    
      printf("All required files are created and saved.\n");
      free(kdata1);free(fre1);
      free(kdata2); free(fre2);
      free(kdata3); free(fre3);
}

void Inputs_creation_phonopy ()
{
      int i,j,k,l;
      int R_1, R_2, R_3;
      int rows;
      int rows1, rows2, rows3;
      int N_t; // total number of atoms in the cell
      int M_k;  // total number of k points in each dispersion
      int kfiles;
      char file1[128], file2[128], file3[128];
      char file[128];
      char filedata[256];
      float dummy1, dummy2;
      float *kdata1,*kdata2,*kdata3; // k notations
      float *fre1,*fre2,*fre3; // phonon frequencies at three different volumes
      FILE *input1; 
      FILE *input;
      FILE *output;
      FILE *output1;
      FILE *output2;
      printf("/*----------------Project Thermal Conductivity--------------------*/\n");
      printf("          Formatting PHONOPY phonon data to required form         */\n");
      printf("                  File created: Phonon_volume.dat                 */\n");
      printf("/*               Porgram is written by Bing Xiao                  */\n");
      printf("/*     Department of Earth Sciences, University College London    */\n");
      printf("/*                      b.xiao@ucl.ac.uk                          */\n");
      printf("/*                  #######################                       */\n");
      printf("/*                  #  DATED:2016-04-13   #                       */\n");
      printf("/*                  #######################                       */\n");
      printf("/*     Recent Updates Timed: 2020-09-03                           */\n");
      printf("/*--------------------Phonon_volume.dat---------------------------*/\n");
      printf("/*Three files must be provided in order to run the program.       */\n");
      printf("/*band_xxx_cmp.dat, band_xxx_min.dat and band_xxx_exp.dat         */\n");
      printf("/*xxx--->principal direction, i.e., 100, 010 and 001              */\n");
      printf("/*cmp: compression phonon frequency;                              */\n");
      printf("/*min: optimized structure;                                       */\n");
      printf("/*exp: expaned structure;                                         */\n");
      printf("/*---------------------K_points.dat-------------------------------*/\n");
      printf("/*You must provide an additional file which has the information   */\n");
      printf("/*about k coordinates(fractional)and k weights.                   */\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("Enter the file names below for phonon dispersions:\n");
      printf("File name for compressed structure:(band_100_cmp.dat)\n");
//      fgets(file1, 128, stdin);
      sprintf (file1, "in/band_1.dat");
      puts (file1);
      printf("File name for undeformed structure:(band_100_min.dat)\n");
//      fgets(file2, 128, stdin);
      sprintf (file2, "in/band_2.dat");
      puts (file2);
      printf("File name for expanded structure:(band_100_exp.dat)\n");
//      fgets(file3, 128, stdin);
      sprintf (file3, "in/band_3.dat");
      puts (file3);
      printf("\n");
      N_t = Natoms;
      printf("Enter total number of atoms in the cell:(MUST BE AN INTEGER) %d\n", N_t);
//      scanf("%d",&N_t);
      M_k = Nkpoints;
      printf("Enter total number of k-points in each dispersion:(MUST BE AN INTEGER) %d\n", M_k);
//      scanf("%d",&M_k);

// Accounting total number of rows in the phonon dispersions
      rows=N_t*M_k*3;
      kdata1=(float*)malloc(rows*sizeof(float));
      fre1=(float*)malloc(rows*sizeof(float));
      kdata2=(float*)malloc(rows*sizeof(float));
      fre2=(float*)malloc(rows*sizeof(float));
      kdata3=(float*)malloc(rows*sizeof(float));
      fre3=(float*)malloc(rows*sizeof(float));
// Import phonons
      int nfile;
      int nrows[3]; // total number of rows in each input
      char files[128];
      for(nfile=1;nfile<=3;nfile++){
                                    if(nfile==1){
                                                 sprintf(file, "%s", file1);
                                                 sprintf(files,"out/file_creation/Raw_cmp.dat");
                                                 }
                                    else if(nfile==2){
                                                      sprintf(file, "%s", file2);
                                                      sprintf(files,"out/file_creation/Raw_min.dat");
                                                      }
                                    else if(nfile==3){
                                                      sprintf(file, "%s", file3);
                                                      sprintf(files,"out/file_creation/Raw_exp.dat");
                                                      }
      
                                    input=fopen(file,"r");
                                    output=fopen(files,"w");
                                    if(input==NULL){
                                                     perror("Error while opening the file.\n");
                                                     printf("Could not find file %s.\n",file);
                                                     exit(EXIT_FAILURE);
                                                     }
                                    else {
                                          printf("File %s ls loaded.\n",file);
                                         }
                                    rows1=0;
                                    i=0;
                                    while(fgets(filedata,256,input)!=NULL){
                                                                           if(i>=2){
                                                      // skip the blank line in the input data file
                                                                                    if(filedata[0]!='\n'){
                                                                                                          sscanf(filedata,"%f %f",&dummy1,&dummy2);
                                                                                                          rows1++;
                                                                                                          printf("%f\t%f\n",dummy1,dummy2);
                                                                                                          fprintf(output,"%f\t%f\n",dummy1,dummy2);
                                                                                                          }
                                                                                   }
                                                                           i++;
                                                                          }
                                    fclose(input);
                                    fclose(output);
                                    nrows[nfile-1]=rows1;
                                    printf("Number of rows in file %s=%d\n",file,nrows[nfile-1]);
                                    output=fopen(files,"r");
                                    for(j=0;j<rows1;j++){
                                                                  if(nfile==1){
                                                                               fscanf(output,"%f %f",&(kdata1[j]),&(fre1[j]));
                                                                               }
                                                                  else if(nfile==2){
                                                                                    fscanf(output,"%f %f",&(kdata2[j]),&(fre2[j]));
                                                                                   }
                                                                  else if(nfile==3){
                                                                                    fscanf(output,"%f %f",&(kdata3[j]),&(fre3[j]));
                                                                                    }
                                                                 }
                                    fclose(output);
                                    }
      if(nrows[0]==rows&&nrows[1]==rows&&nrows[2]==rows){
                                                         printf("/*--------------------------------------------*/\n");
                                                         printf("Phonon dipersion information are summarized:\n");
                                                         printf("Number of atoms:%d\n",N_t);
                                                         printf("Number of dispersions:%d\n",3*N_t);
                                                         printf("Number of kpoints in each dispersion:%d\n",M_k);
                                                         printf("Total number of rows in .dat file:%d\n",rows);
                                                         printf("/*--------------------------------------------*/\n");
                                                         }
      else if(nrows[0]!=rows||nrows[1]!=rows||nrows[2]!=rows){
                                                              printf("Inconsistency is found in your inputs:\n");
                                                              printf("Filename\tRows\n");
                                                              printf("%s: %d\n",file1,nrows[0]);
                                                              printf("%s: %d\n",file2,nrows[1]);
                                                              printf("%s: %d\n",file3,nrows[2]);
                                                              printf("Please check your phonon calculations.\n");
                                                              printf("Program will be terminated.\n");
                                                              exit(EXIT_FAILURE);
                                                              }
//------------------------------------------------------------------------------
      char file4[128];
      sprintf(file4,"out/file_creation/Phonon_volume.dat");
      output1=fopen(file4,"w");
      for(j=0;j<rows;j++){
                          //Ensuring zero frequency for the acoustic phonons at Gamma point
                          if(j==0||j==M_k||j==2*M_k){
                                                           fre1[j]=0.000000;
                                                           fre2[j]=0.000000;
                                                           fre3[j]=0.000000;
                                                           }
                          // Reset all negative phonon frequencies to zero. 
                          if(fre1[j]<0.0){
                                          fre1[j]=0.0;
                                          }
                          if(fre2[j]<0.0){
                                          fre2[j]=0.0;
                                          }
                          if(fre3[j]<0.0){
                                          fre3[j]=0.0;
                                          }
                          fprintf(output1,"%f\t%f\t%f\t%f\n",kdata2[j],fre1[j],fre2[j],fre3[j]);
                          }
      fclose(output1);
      printf("%s file is successfully created.\n",file4);
      printf("------------------------------------------------------------------\n");
      /* Clean the buffer due to scanf */
      printf("Do you want to creat K_points.dat file for the following programs:\n");
      printf("1. Velocities.cpp (Group and Phase Velocites)\n");
      printf("2. Gruneisen_constant.cpp (Phonon spectrum averaged Gruneisen constant)\n");
      printf("3. Phonon_thermal_conductivity_sumk.cpp \n");
      printf("Computing mode-Gruneisen constant using Mode_Gruneisen_constant.cpp \n");
      printf("does not require to creat K_points.dat file.\n");
      kfiles = creat_kpoints;
      printf("Enter your choice:Yes(1) or No(2): %d\n", kfiles);
//      scanf("%d",&kfiles);

if(kfiles==1){
      char file5[128];
      float *kxdata,*kydata,*kzdata;
      float *kweight;
      float tweight;
      float dummy3, dummy4;
      int krows;
      int pv;
      int S;
//      while((S=getchar())!=EOF&&S!='\n');
      printf("Enter the file name for k-coordinates and their weights:\n");
      sprintf (file5, "in/K.dat");
      puts (file5);
//      fgets(file5, 128, stdin);
//    sprintf(file5,"K_star.dat");
      input1=fopen(file5,"r");
      if(input1==NULL){
                      perror("Error while opening the file.\n");
                      printf("Could not find file %s.\n",file5);
                      exit(EXIT_FAILURE);
                      }
      else {
            printf("File %s ls loaded.\n",file5);
            }
// Determine the total number of k-points and total weight
//Number of kpoints provided must be consistent with your input in the begnning
      R_1=0;
      while(!feof(input1)){
                           fscanf(input1,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                           R_1++;
                           }
      krows=R_1-1;
      fclose(input1);
      kxdata=(float*)malloc(krows*sizeof(float));
      kydata=(float*)malloc(krows*sizeof(float));
      kzdata=(float*)malloc(krows*sizeof(float));
      kweight=(float*)malloc(krows*sizeof(float));
      if(krows==M_k){
                        printf("Total number of kpoints in %s is %d.\n",file5,krows);
                        printf("This is consistent with your input:%d\n",M_k);
                        printf("K_points.dat file will be created.\n");
                        }
      else if(krows!=M_k){
                             printf("Inconsistent number of kpoints found:\n");
                             printf("%s: %d\n",file5,krows);
                             printf("Your previous input:%d\n",M_k);
                             printf("Sorry, program will terminate....\n");
                             exit(EXIT_FAILURE);
                             }
      input1=fopen(file5,"r");
      for(k=0;k<krows;k++){
                           fscanf(input1,"%f %f %f %f",&(kxdata[k]),&(kydata[k]),&(kzdata[k]),&(kweight[k]));
                           }
      fclose(input1);
      tweight=0.000000;
      for(j=0;j<krows;j++){
                           tweight+=kweight[j];
                           }
      printf("Total weight of kpoints is %f.\n",tweight);
      output2=fopen("out/file_creation/K_points.dat","w");
      for(j=1;j<=N_t*3;j++){
                             for(k=(j-1)*krows;k<j*krows;k++){
                                                              pv=k-(j-1)*krows;
                                                              fprintf(output2,"%f\t%f\t%f\t%f\n",kxdata[pv],kydata[pv],kzdata[pv],fre2[k]);
                                                              }
                             }
      fclose(output2);
      free(kxdata); free(kydata); free(kzdata); free(kweight);
      }
else if(kfiles==2){
                   printf("Only Phonon_volume.dat file is created.\n");
                   printf("You can use as the input for Mode_Gruneisen_constant.cpp.\n");
                   } 
      int options;
      options = rm_adundant;
      printf("Do you want to remove adundant files:Yes(1) or No(2)\n");
      printf("Enter your option:(MUST BE AN INTEGER) %d\n", options);
//      scanf("%d",&options);

      if(options==1){
                     int status1, status2, status3;
                     status1=remove("out/file_creation/Raw_cmp.dat");
                     if(status1==0){
                                    printf("File 'Raw_cmp.dat' is deleted.\n");
                                    }
                     status2=remove("out/file_creation/Raw_min.dat");
                     if(status2==0){
                                    printf("File 'Raw_min.dat' is deleted.\n");
                                    }
                     status3=remove("out/file_creation/Raw_exp.dat");
                     if(status3==0){
                                    printf("File 'Raw_exp.dat' is deleted.\n");
                                    }
                     }
       else if(options==2){
                           printf("No file has been removed in the folder.\n");
                           }    
      printf("All required files are created and saved.\n");
      free(kdata1);free(fre1);
      free(kdata2); free(fre2);
      free(kdata3); free(fre3);
}

void Inputs_creation_phonopy_interpolation ()
{
      int i,j,k,l;
      int R_1, R_2, R_3;
      int rows;
      int rows1, rows2, rows3;
      int N_t; // total number of atoms in the cell
      int M_k;  // total number of k points in each dispersion
      int kfiles;
      char file1[128], file2[128], file3[128];
      char file[128];
      char filedata[256];
      float dummy1, dummy2;
      float *kdata1,*kdata2,*kdata3; // k notations
      float *fre1,*fre2,*fre3; // phonon frequencies at three different volumes
      FILE *input1; 
      FILE *input;
      FILE *output;
      FILE *output1;
      FILE *output2;
      printf("/*----------------Project Thermal Conductivity--------------------*/\n");
      printf("          Formatting PHONOPY phonon data to required form         */\n");
      printf("                  File created: Phonon_volume.dat                 */\n");
      printf("/*               Porgram is written by Bing Xiao                  */\n");
      printf("/*     Department of Earth Sciences, University College London    */\n");
      printf("/*                      b.xiao@ucl.ac.uk                          */\n");
      printf("/*                  #######################                       */\n");
      printf("/*                  #  DATED:2016-04-13   #                       */\n");
      printf("/*                  #######################                       */\n");
      printf("/*     Recent Updates Timed: 2020-09-03                           */\n");
      printf("/*--------------------Phonon_volume.dat---------------------------*/\n");
      printf("/*Three files must be provided in order to run the program.       */\n");
      printf("/*band_xxx_cmp.dat, band_xxx_min.dat and band_xxx_exp.dat         */\n");
      printf("/*xxx--->principal direction, i.e., 100, 010 and 001              */\n");
      printf("/*cmp: compression phonon frequency;                              */\n");
      printf("/*min: optimized structure;                                       */\n");
      printf("/*exp: expaned structure;                                         */\n");
      printf("/*---------------------K_points.dat-------------------------------*/\n");
      printf("/*You must provide an additional file which has the information   */\n");
      printf("/*about k coordinates(fractional)and k weights.                   */\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("Enter the file names below for phonon dispersions:\n");
      printf("File name for compressed structure:(band_100_cmp.dat)\n");
//      fgets(file1, 128, stdin);
      sprintf (file1, "in/band_1.dat");
      puts (file1);
      printf("File name for undeformed structure:(band_100_min.dat)\n");
//      fgets(file2, 128, stdin);
      sprintf (file2, "in/band_2.dat");
      puts (file2);
      printf("File name for expanded structure:(band_100_exp.dat)\n");
//      fgets(file3, 128, stdin);
      sprintf (file3, "in/band_3.dat");
      puts (file3);
      printf("\n");
      N_t = Natoms;
      printf("Enter total number of atoms in the cell:(MUST BE AN INTEGER) %d\n", N_t);
//      scanf("%d",&N_t);
      M_k = Nkpoints;
      printf("Enter total number of k-points in each dispersion:(MUST BE AN INTEGER) %d\n", M_k);
//      scanf("%d",&M_k);

// Accounting total number of rows in the phonon dispersions
      rows=N_t*M_k*3;
      kdata1=(float*)malloc(rows*sizeof(float));
      fre1=(float*)malloc(rows*sizeof(float));
      kdata2=(float*)malloc(rows*sizeof(float));
      fre2=(float*)malloc(rows*sizeof(float));
      kdata3=(float*)malloc(rows*sizeof(float));
      fre3=(float*)malloc(rows*sizeof(float));
// Import phonons
      int nfile;
      int nrows[3]; // total number of rows in each input
      char files[128];
      for(nfile=1;nfile<=3;nfile++){
                                    if(nfile==1){
                                                 sprintf(file, "%s", file1);
                                                 sprintf(files,"out/file_creation/Raw_cmp.dat");
                                                 }
                                    else if(nfile==2){
                                                      sprintf(file, "%s", file2);
                                                      sprintf(files,"out/file_creation/Raw_min.dat");
                                                      }
                                    else if(nfile==3){
                                                      sprintf(file, "%s", file3);
                                                      sprintf(files,"out/file_creation/Raw_exp.dat");
                                                      }
      
                                    input=fopen(file,"r");
                                    output=fopen(files,"w");
                                    if(input==NULL){
                                                     perror("Error while opening the file.\n");
                                                     printf("Could not find file %s.\n",file);
                                                     exit(EXIT_FAILURE);
                                                     }
                                    else {
                                          printf("File %s ls loaded.\n",file);
                                         }
                                    rows1=0;
                                    i=0;
                                    while(fgets(filedata,256,input)!=NULL){
                                                                           if(i>=2){
                                                      // skip the blank line in the input data file
                                                                                    if(filedata[0]!='\n'){
                                                                                                          sscanf(filedata,"%f %f",&dummy1,&dummy2);
                                                                                                          rows1++;
                                                                                                          printf("%f\t%f\n",dummy1,dummy2);
                                                                                                          fprintf(output,"%f\t%f\n",dummy1,dummy2);
                                                                                                          }
                                                                                   }
                                                                           i++;
                                                                          }
                                    fclose(input);
                                    fclose(output);
                                    nrows[nfile-1]=rows1;
                                    printf("Number of rows in file %s=%d\n",file,nrows[nfile-1]);
                                    output=fopen(files,"r");
                                    for(j=0;j<rows1;j++){
                                                                  if(nfile==1){
                                                                               fscanf(output,"%f %f",&(kdata1[j]),&(fre1[j]));
                                                                               }
                                                                  else if(nfile==2){
                                                                                    fscanf(output,"%f %f",&(kdata2[j]),&(fre2[j]));
                                                                                   }
                                                                  else if(nfile==3){
                                                                                    fscanf(output,"%f %f",&(kdata3[j]),&(fre3[j]));
                                                                                    }
                                                                 }
                                    fclose(output);
                                    }
      if(nrows[0]==rows&&nrows[1]==rows&&nrows[2]==rows){
                                                         printf("/*--------------------------------------------*/\n");
                                                         printf("Phonon dipersion information are summarized:\n");
                                                         printf("Number of atoms:%d\n",N_t);
                                                         printf("Number of dispersions:%d\n",3*N_t);
                                                         printf("Number of kpoints in each dispersion:%d\n",M_k);
                                                         printf("Total number of rows in .dat file:%d\n",rows);
                                                         printf("/*--------------------------------------------*/\n");
                                                         }
      else if(nrows[0]!=rows||nrows[1]!=rows||nrows[2]!=rows){
                                                              printf("Inconsistency is found in your inputs:\n");
                                                              printf("Filename\tRows\n");
                                                              printf("%s: %d\n",file1,nrows[0]);
                                                              printf("%s: %d\n",file2,nrows[1]);
                                                              printf("%s: %d\n",file3,nrows[2]);
                                                              printf("Please check your phonon calculations.\n");
                                                              printf("Program will be terminated.\n");
                                                              exit(EXIT_FAILURE);
                                                              }
//------------------------------------------------------------------------------
      char file4[128];
      sprintf(file4,"out/file_creation/Phonon_volume_tmp.dat");
      output1=fopen(file4,"w");
      for(j=0;j<rows;j++){
                          //Ensuring zero frequency for the acoustic phonons at Gamma point
                          if(j==0||j==M_k||j==2*M_k){
                                                           fre1[j]=0.000000;
                                                           fre2[j]=0.000000;
                                                           fre3[j]=0.000000;
                                                           }
                          // Reset all negative phonon frequencies to zero. 
                          if(fre1[j]<0.0){
                                          fre1[j]=0.0;
                                          }
                          if(fre2[j]<0.0){
                                          fre2[j]=0.0;
                                          }
                          if(fre3[j]<0.0){
                                          fre3[j]=0.0;
                                          }
                          fprintf(output1,"%f\t%f\t%f\t%f\n",kdata2[j],fre1[j],fre2[j],fre3[j]);
                          }
      fclose(output1);
      printf("%s file is successfully created.\n",file4);
      printf("------------------------------------------------------------------\n");
      /* Clean the buffer due to scanf */
 //     printf("Do you want to creat K_points.dat file for the following programs:\n");
//      printf("1. Velocities.cpp (Group and Phase Velocites)\n");
//      printf("2. Gruneisen_constant.cpp (Phonon spectrum averaged Gruneisen constant)\n");
//      printf("3. Phonon_thermal_conductivity_sumk.cpp \n");
 //     printf("Computing mode-Gruneisen constant using Mode_Gruneisen_constant.cpp \n");
//      printf("does not require to creat K_points.dat file.\n");
//      printf("Enter your choice:Yes(1) or No(2)\n");
//      scanf("%d",&kfiles);
    kfiles=1; 
if(kfiles==1){
      char file5[128];
      float *kxdata,*kydata,*kzdata;
      float *kweight;
      float tweight;
      float dummy3, dummy4;
      int krows;
      int pv;
      int S;
//      while((S=getchar())!=EOF&&S!='\n');
      printf("Enter the file name for k-coordinates and their weights:\n");
//      gets(file5);
      sprintf(file5,"in/K.dat");
      puts (file5);
      input1=fopen(file5,"r");
      if(input1==NULL){
                      perror("Error while opening the file.\n");
                      printf("Could not find file %s.\n",file5);
                      exit(EXIT_FAILURE);
                      }
      else {
            printf("File %s ls loaded.\n",file5);
            }
// Determine the total number of k-points and total weight
//Number of kpoints provided must be consistent with your input in the begnning
      R_1=0;
      while(!feof(input1)){
                           fscanf(input1,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                           R_1++;
                           }
      krows=R_1-1;
      fclose(input1);
      kxdata=(float*)malloc(krows*sizeof(float));
      kydata=(float*)malloc(krows*sizeof(float));
      kzdata=(float*)malloc(krows*sizeof(float));
      kweight=(float*)malloc(krows*sizeof(float));
      if(krows==M_k){
                        printf("Total number of kpoints in %s is %d.\n",file5,krows);
                        printf("This is consistent with your input:%d\n",M_k);
                        printf("K_points.dat file will be created.\n");
                        }
      else if(krows!=M_k){
                             printf("Inconsistent number of kpoints found:\n");
                             printf("%s: %d\n",file5,krows);
                             printf("Your previous input:%d\n",M_k);
                             printf("Sorry, program will terminate....\n");
                             exit(EXIT_FAILURE);
                             }
      input1=fopen(file5,"r");
      for(k=0;k<krows;k++){
                           fscanf(input1,"%f %f %f %f",&(kxdata[k]),&(kydata[k]),&(kzdata[k]),&(kweight[k]));
                           }
      fclose(input1);
      tweight=0.000000;
      for(j=0;j<krows;j++){
                           tweight+=kweight[j];
                           }
      printf("Total weight of kpoints is %f.\n",tweight);
      for(i=1;i<=3;i++){
	                    if(i==1){
						         output2=fopen("out/file_creation/Raw_cmp_new.dat","w");
								 for(j=1;j<=N_t*3;j++){
                                                       for(k=(j-1)*krows;k<j*krows;k++){
                                                                                        pv=k-(j-1)*krows;
                                                                                        fprintf(output2,"%f\t%f\t%f\t%f\n",kxdata[pv],kydata[pv],kzdata[pv],fre1[k]);
                                                                                       }
                                                       }
                                 fclose(output2);
								 }
						else if(i==2){
						             output2=fopen("out/file_creation/Raw_min_new.dat","w");
									 for(j=1;j<=N_t*3;j++){
                                                       for(k=(j-1)*krows;k<j*krows;k++){
                                                                                        pv=k-(j-1)*krows;
                                                                                        fprintf(output2,"%f\t%f\t%f\t%f\n",kxdata[pv],kydata[pv],kzdata[pv],fre2[k]);
                                                                                       }
                                                       }
                                 fclose(output2);
									 }
						else if(i==3){
						             output2=fopen("out/file_creation/Raw_exp_new.dat","w");
									 for(j=1;j<=N_t*3;j++){
                                                       for(k=(j-1)*krows;k<j*krows;k++){
                                                                                        pv=k-(j-1)*krows;
                                                                                        fprintf(output2,"%f\t%f\t%f\t%f\n",kxdata[pv],kydata[pv],kzdata[pv],fre3[k]);
                                                                                       }
                                                       }
                                 fclose(output2);
									 }
					   }
      free(kxdata); free(kydata); free(kzdata); free(kweight);
      }
else if(kfiles==2){
                   printf("Only Phonon_volume.dat file is created.\n");
                   printf("You can use as the input for Mode_Gruneisen_constant.cpp.\n");
                   } 

      free(kdata1);free(fre1);
      free(kdata2); free(fre2);
      free(kdata3); free(fre3);

	/*********************interpolation*****************/
	FILE *input2, *input3, *input4;
	FILE *output3, *output4, *output5;
	Raw *cmp, *exp, *min, *cmp_intplt, *exp_intplt, *min_intplt;
	char *filenameRaw[] = {"out/file_creation/Raw_cmp_new.dat", "out/file_creation/Raw_min_new.dat", "out/file_creation/Raw_exp_new.dat"};
	char filename[128], line[1028];
	int n, Nraw, Nraw_intplt;
	float *xa, *ya, *x, *y, *y2, xMin_cmp, xMax_cmp, xMin_min, xMax_min, xMin_exp, xMax_exp, yp1, ypn;
	double xMin, xMax, a, b, c, x0, y0, z0, x1, y1, z1;

	Nraw = 3 * Natoms * Nkpoints;
	AllocMem (cmp, Nraw, Raw);
	AllocMem (min, Nraw, Raw);
	AllocMem (exp, Nraw, Raw);

	for (n = 0; n < 3; n ++) {
		sprintf (filename, "%s", filenameRaw[n]);
		if ((input2 = fopen (filename, "r")) == NULL) {
			printf ("%s does not exist\n", filename);
			exit (1);
		}
		i = 0;
		while (1) {
			if (fgets (line, 1028, input2) == NULL) break;
			switch (n) {
				case 0: sscanf (line, "%lg %lg %lg %lg", &cmp[i].x, &cmp[i].y, &cmp[i].z, &cmp[i].fre); break;
				case 1: sscanf (line, "%lg %lg %lg %lg", &min[i].x, &min[i].y, &min[i].z, &min[i].fre); break;
				case 2: sscanf (line, "%lg %lg %lg %lg", &exp[i].x, &exp[i].y, &exp[i].z, &exp[i].fre); break;
			}
			i ++;
		}
		fclose (input2);
	}
	
	//find xMax and xMin
	xMax_cmp = xMin_cmp = cmp[0].x;
	xMax_min = xMin_min = min[0].x;
	xMax_exp = xMin_exp = exp[0].x;
	for (i = 0; i < Nraw; i ++) {
		if (xMax_cmp < cmp[i].x) xMax_cmp = cmp[i].x;
		if (xMin_cmp > cmp[i].x) xMin_cmp = cmp[i].x;
		if (xMax_min < min[i].x) xMax_min = min[i].x;
		if (xMin_min > min[i].x) xMin_min = min[i].x;
		if (xMax_exp < exp[i].x) xMax_exp = exp[i].x;
		if (xMin_exp > exp[i].x) xMin_exp = exp[i].x;
	}
	//allocate memory
	Nraw_intplt = Nkpoints_set * Natoms * 3;
	AllocMem (cmp_intplt, Nraw_intplt, Raw);
	AllocMem (min_intplt, Nraw_intplt, Raw);
	AllocMem (exp_intplt, Nraw_intplt, Raw);
	AllocMem (xa, Nkpoints+1, float);
	AllocMem (ya, Nkpoints+1, float);
	AllocMem (y2, Nkpoints+1, float);
	AllocMem (x, Nkpoints_set+1, float);
	AllocMem (y, Nkpoints_set+1, float);

	//Raw_cmp
	for (n = 0; n < Natoms * 3; n ++) {
		//init
		for (i = 0; i < Nkpoints_set; i ++) {
			cmp_intplt[i+Nkpoints_set*n].x = (xMax_cmp - xMin_cmp) / (Nkpoints_set - 1) * i + xMin_cmp;
			cmp_intplt[i+Nkpoints_set*n].y = 0.;
			cmp_intplt[i+Nkpoints_set*n].z = 0.;
			x[i+1] = cmp_intplt[i+Nkpoints_set*n].x;
		}
		for (i = 0; i < Nkpoints; i ++) {
			xa[i+1] = cmp[i+Nkpoints*n].x;
			ya[i+1] = cmp[i+Nkpoints*n].fre;
		}
		//interpolation
		yp1 = (ya[2] - ya[1]) / (xa[2] - xa[1]);
		ypn = (ya[Nkpoints] - ya[Nkpoints-1]) / (xa[Nkpoints] - xa[Nkpoints-1]);
		spline(xa, ya, Nkpoints, yp1, ypn, y2);
		for (i = 0; i < Nkpoints_set; i ++) {
			splint (xa, ya, y2, Nkpoints, x[i+1], &y[i+1]);
			cmp_intplt[i+Nkpoints_set*n].fre = y[i+1];
		}
	}

	//Raw_min
	for (n = 0; n < Natoms * 3; n ++) {
		//init
		for (i = 0; i < Nkpoints_set; i ++) {
			min_intplt[i+Nkpoints_set*n].x = (xMax_min - xMin_min) / (Nkpoints_set - 1) * i + xMin_min;
			min_intplt[i+Nkpoints_set*n].y = 0.;
			min_intplt[i+Nkpoints_set*n].z = 0.;
			x[i+1] = min_intplt[i+Nkpoints_set*n].x;
		}
		for (i = 0; i < Nkpoints; i ++) {
			xa[i+1] = min[i+Nkpoints*n].x;
			ya[i+1] = min[i+Nkpoints*n].fre;
		}
		//interpolation
		yp1 = (ya[2] - ya[1]) / (xa[2] - xa[1]);
		ypn = (ya[Nkpoints] - ya[Nkpoints-1]) / (xa[Nkpoints] - xa[Nkpoints-1]);
		spline(xa, ya, Nkpoints, yp1, ypn, y2);
		for (i = 0; i < Nkpoints_set; i ++) {
			splint (xa, ya, y2, Nkpoints, x[i+1], &y[i+1]);
			min_intplt[i+Nkpoints_set*n].fre = y[i+1];
		}
	}

	//Raw_exp
	for (n = 0; n < Natoms * 3; n ++) {
		//init
		for (i = 0; i < Nkpoints_set; i ++) {
			exp_intplt[i+Nkpoints_set*n].x = (xMax_exp - xMin_exp) / (Nkpoints_set - 1) * i + xMin_exp;
			exp_intplt[i+Nkpoints_set*n].y = 0.;
			exp_intplt[i+Nkpoints_set*n].z = 0.;
			x[i+1] = exp_intplt[i+Nkpoints_set*n].x;
		}
		for (i = 0; i < Nkpoints; i ++) {
			xa[i+1] = exp[i+Nkpoints*n].x;
			ya[i+1] = exp[i+Nkpoints*n].fre;
		}
		//interpolation
		yp1 = (ya[2] - ya[1]) / (xa[2] - xa[1]);
		ypn = (ya[Nkpoints] - ya[Nkpoints-1]) / (xa[Nkpoints] - xa[Nkpoints-1]);
		spline(xa, ya, Nkpoints, yp1, ypn, y2);
		for (i = 0; i < Nkpoints_set; i ++) {
			splint (xa, ya, y2, Nkpoints, x[i+1], &y[i+1]);
			exp_intplt[i+Nkpoints_set*n].fre = y[i+1];
		}
	}

	//obtain Phonon_volume.dat
	sprintf(filename,"out/file_creation/Phonon_volume.dat");
	output4=fopen(filename,"w");
	if (output4 == NULL) {
		printf ("creating %s failed\n", filename);
		exit (1);
	}
	sprintf(filename,"out/file_creation/Phonon_volume_tmp.dat");
	input3=fopen(filename,"r");
	if (input3 == NULL) {
		printf ("creating %s failed\n", filename);
		exit (1);
	}
	n = 0;
	while (1) {
		if (fgets (line, 1028, input3) == NULL) break;
		sscanf (line, "%lg", &a);
		if (n == 0) xMax = xMin = a;
		if (xMax < a) xMax = a;
		if (xMin > a) xMin = a;
		n ++;
	}
	for(i = 0;i < Nraw_intplt; i++) {
		fprintf(output4,"%e\t%e\t%e\t%e\n", (xMax - xMin) / (Nkpoints_set - 1.) * (i % Nkpoints_set) + xMin, \
			cmp_intplt[i].fre, min_intplt[i].fre, exp_intplt[i].fre);
	}

	//obtain K_points.dat
	sprintf(filename,"in/K.dat");
	input4=fopen(filename,"r");
	if (input4 == NULL) {
		printf ("%s does not exist/n", filename);
		exit (1);
	}
	n = 0;
	while (1) {
		if (fgets (line, 1028, input4) == NULL) break;
		sscanf (line, "%lg %lg %lg", &a, &b, &c);
		if (n == 0) {
			x0 = a;
			y0 = b;
			z0 = c;
		} else if (n == Nkpoints - 1) {
			x1 = a;
			y1 = b;
			z1 = c;
		}
		n ++;
	}
	sprintf (filename, "out/file_creation/K_points.dat");
	if ((output3 = fopen (filename, "w")) == NULL) {
		printf ("%s does not exist\n", filename);
		exit (1);
	}
	for (i = 0; i < Nraw_intplt; i ++) {
		fprintf (output3, "%e %e %e %e\n",  \
		(x1 - x0) / (Nkpoints_set - 1.) * (i % Nkpoints_set) + x0, \
		(y1 - y0) / (Nkpoints_set - 1.) * (i % Nkpoints_set) + y0, \
		(z1 - z0) / (Nkpoints_set - 1.) * (i % Nkpoints_set) + z0, \
		min_intplt[i].fre);
	}

	//obtain K.dat after interpolation
	sprintf (filename, "out/file_creation/K.dat");
	if ((output5 = fopen (filename, "w")) == NULL) {
		printf ("%s does not exist\n", filename);
		exit (1);
	}
	for (i = 0; i < Nkpoints_set; i ++) {
		fprintf (output5, "%e %e %e %e\n",  \
		(x1 - x0) / (Nkpoints_set - 1.) * i + x0, \
		(y1 - y0) / (Nkpoints_set - 1.) * i + y0, \
		(z1 - z0) / (Nkpoints_set - 1.) * i + z0, \
		1./Nkpoints_set);
	}

	Nkpoints = Nkpoints_set;

	fclose (input3);
	fclose (input4);
	fclose (output3);
	fclose (output4);
	fclose (output5);
	free (cmp);
	free (min);
	free (exp);
	free (cmp_intplt);
	free (min_intplt);
	free (exp_intplt);
	free (xa);
	free (ya);
	free (y2);
	free (x);
	free (y);

      int options;
      options = rm_adundant;
      printf("Do you want to remove adundant files:Yes(1) or No(2)\n");
      printf("Enter your option:(MUST BE AN INTEGER) %d\n", options);
//      scanf("%d",&options);
      if(options==1){
                     int status1, status2, status3;
                     int status4;
                     status1=remove("out/file_creation/Raw_cmp.dat");
                     if(status1==0){
                                    printf("File 'Raw_cmp.dat' is deleted.\n");
                                    }
                     status2=remove("out/file_creation/Raw_min.dat");
                     if(status2==0){
                                    printf("File 'Raw_min.dat' is deleted.\n");
                                    }
                     status3=remove("out/file_creation/Raw_exp.dat");
                     if(status3==0){
                                    printf("File 'Raw_exp.dat' is deleted.\n");
                                    }
                     status4=remove("out/file_creation/Phonon_volume_tmp.dat");
                     if(status4==0){
                                    printf("File 'Phonon_volume_tmp.dat' is deleted.\n");
                                    }
                     }
       else if(options==2){
                           printf("No file has been removed in the folder.\n");
                           }    
      printf("All required files are created and saved.\n");
      printf("Press 'Enter' key to exit the program.\n");
}

void Inputs_creation_CASTEP_interpolation ()
{
      int i, j, k, l;
      int R_1, R_2, R_3;
      int rows;
      int rows1, rows2, rows3;
      int N_t;  // total number of atoms in the modelling cell
      int M_k;  // total number of k point in each dispersion
      int kfiles; // options for create the K_points.dat file
      char file1[128], file2[128], file3[128];
      char file[128];
      char filedata[128];
      float dummy1, dummy2;
      float *kpdata, *fredata;
      float *kdata1, *fre1; // volume 1
      float *kdata2, *fre2; // volume 2
      float *kdata3, *fre3;  // volume 3
      FILE *input;
      FILE *output;
      FILE *input1;
      FILE *output2;
      printf("/*-------------------Thermal Conducivity Project------------------*/\n");
      printf("          Formatting CASTEP phonon data to required one           */\n");
      printf("                  File created: Phonon_volume.dat                 */\n");
      printf("/*----------Other programs compatiable with output data-----------*/\n");
      printf("/*       Gruneisen_constant.cpp, Mode_Gruneisen_constant.cpp      */\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("/*                    Written by Bing Xiao                        */\n");
      printf("/*                     b.xiao@ucl.ac.uk                           */\n");
      printf("/*                         2015-11-07                             */\n");
      printf("/*     Recent Updates Timed: 2020-09-03                           */\n");
      printf("/*     bingxiao84@xjtu.edu.cn, Bing Xiao from XJTU                */\n");
      printf("/*----------------------------------------------------------------*/\n");
      printf("Enter the file names below for phonon dispersions:\n");
      printf("File name for compressed structure:(band_100_cmp.dat)\n");
//      fgets(file1, 128, stdin);
      sprintf (file1, "in/band_1.dat");
      puts (file1);
      printf("File name for undeformed structure:(band_100_min.dat)\n");
//      fgets(file2, 128, stdin);
      sprintf (file2, "in/band_2.dat");
      puts (file2);
      printf("File name for expanded structure:(band_100_exp.dat)\n");
//      fgets(file3, 128, stdin);
      sprintf (file3, "in/band_3.dat");
      puts (file3);
      printf("\n");
      N_t = Natoms;
      printf("Enter total number of atoms in the cell:(MUST BE AN INTEGER) %d\n", N_t);
//      scanf("%d",&N_t);
      M_k = Nkpoints;
      printf("Enter total number of k-points in each dispersion:(MUST BE AN INTEGER) %d\n", M_k);
//      scanf("%d",&M_k);
 
      rows=N_t*M_k*3+N_t*3; // This is total rows in CASTEP output data.
     // kdata1=(float*)malloc(rows*sizeof(float));
    //  fre1=(float*)malloc(rows*sizeof(float));
    //  kdata2=(float*)malloc(rows*sizeof(float));
    //  fre2=(float*)malloc(rows*sizeof(float));
    //  kdata3=(float*)malloc(rows*sizeof(float));
    //  fre3=(float*)malloc(rows*sizeof(float));
// Read the raw data
      int nfile; // total number of volumes
      int nrows[3]; // total number of rows in each input
      char files[128];
      for(nfile=1;nfile<=3;nfile++){
                                    if(nfile==1){
                                                 sprintf(file, "%s", file1);
                                                 sprintf(files,"out/file_creation/Raw_cmp.dat");
                                                 }
                                    else if(nfile==2){
                                                      sprintf(file, "%s", file2);
                                                      sprintf(files,"out/file_creation/Raw_min.dat");
                                                      }
                                    else if(nfile==3){
                                                      sprintf(file, "%s", file3);
                                                      sprintf(files,"out/file_creation/Raw_exp.dat");
                                                      }
      
                                    input=fopen(file,"r");
                                    output=fopen(files,"w");
                                    if(input==NULL){
                                                     perror("Error while opening the file.\n");
                                                     printf("Could not find file %s.\n",file);
                                                     exit(EXIT_FAILURE);
                                                     }
                                    else {
                                          printf("File %s ls loaded.\n",file);
                                         }
                                    rows1=0;
                                    i=0;
                                    while(fgets(filedata,256,input)!=NULL){
                                                                           if(i>=2){
                                                      // skip the blank line in the input data file
                                                                                    if(filedata[0]!='\n'){
                                                                                                          sscanf(filedata,"%f %f",&dummy1,&dummy2);
                                                                                                          rows1++;
                                                                                                          printf("%f\t%f\n",dummy1,dummy2);
                                                                                                          fprintf(output,"%f\t%f\n",dummy1,dummy2);
                                                                                                          }
                                                                                   }
                                                                           i++;
                                                                          }
                                    fclose(input);
                                    fclose(output);
                                    nrows[nfile-1]=rows1;
                                    printf("Number of rows in file %s=%d\n",file,nrows[nfile-1]);
                                    if(nfile==1){
                                                 kdata1=(float*)malloc(rows1*sizeof(float));
                                                 fre1=(float*)malloc(rows1*sizeof(float));
                                                 }
                                    else if(nfile==2){
                                                      kdata2=(float*)malloc(rows1*sizeof(float));
                                                      fre2=(float*)malloc(rows1*sizeof(float));
                                                      }
                                    else if(nfile==3){
                                                      kdata3=(float*)malloc(rows1*sizeof(float));
                                                      fre3=(float*)malloc(rows1*sizeof(float));
                                                      }
                                    output=fopen(files,"r");
                                    for(l=0;l<rows1;l++){
                                                         if(nfile==1){
                                                                      fscanf(output,"%f %f",&(kdata1[l]),&(fre1[l]));
                                                                      }
                                                         else if(nfile==2){
                                                                           fscanf(output,"%f %f",&(kdata2[l]),&(fre2[l]));
                                                                           }
                                                         else if(nfile==3){
                                                                           fscanf(output,"%f %f",&(kdata3[l]),&(fre3[l]));
                                                                           }
                                                         }
                                    //for(l=1;l<=(Natom*3);l++){
                                    //                          for(k=(l-1)*(kpoint+1);k<(l*kpoint+l-1);l++){
                                    //                              if(nfile==1){
                                    //                                           fscanf(output,"%f %f",&(kdata1[l]),&(fre1[l]));
                                    //                                           }
                                    //                              else if(nfile==2){
                                    //                                                fscanf(output,"%f %f",&(kdata2[l]),&(fre2[l]));
                                    //                                               }
                                    //                              else if(nfile==3){
                                    //                                                fscanf(output,"%f %f",&(kdata3[l]),&(fre3[l]));
                                    //                                                }
                                    //                                                                        }
                                    //                             }
                                    fclose(output);
                                    }
      if(nrows[0]==rows&&nrows[1]==rows&&nrows[2]==rows){
                                                         printf("/*--------------------------------------------*/\n");
                                                         printf("Phonon dipersion information are summarized:\n");
                                                         printf("Number of atoms:%d\n",N_t);
                                                         printf("Number of dispersions:%d\n",3*N_t);
                                                         printf("Number of kpoints in each dispersion:%d\n",M_k);
                                                         printf("Total number of rows in .dat file:%d\n",rows);
                                                         printf("/*--------------------------------------------*/\n");
                                                         }
      else if(nrows[0]!=rows||nrows[1]!=rows||nrows[2]!=rows){
                                                              printf("Inconsistency is found in your inputs:\n");
                                                              printf("Filename\tRows\n");
                                                              printf("%s: %d\n",file1,nrows[0]);
                                                              printf("%s: %d\n",file2,nrows[1]);
                                                              printf("%s: %d\n",file3,nrows[2]);
                                                              printf("Please check your phonon calculations.\n");
                                                              printf("Program will be terminated.\n");
                                                              exit(EXIT_FAILURE);
                                                              }
//------------------------------------------------------------------------------
// Creat file 'Phonon_volume.dat
      char file4[128];
      FILE *output1;
      sprintf(file4,"out/file_creation/Phonon_volume_tmp.dat");
      output1=fopen(file4,"w");
      for(l=1;l<=(N_t*3);l++){
                                for(k=(l-1)*(M_k+1);k<(l*M_k+l-1);k++){
                                                                             // Reset all three acoustic phonons at Gamma point to zero.
                                                                             if(k==0||k==(M_k+1)||k==(2*M_k+2)){
                                                                                                                    fre1[k]=0.000000;
                                                                                                                    fre2[k]=0.000000;
                                                                                                                    fre3[k]=0.000000;
                                                                                                                    }
                                                                             // Replacing all negative frequencies by zero, we do not like softmodes.
                                                                             if(fre1[k]<0.0){
                                                                                             fre1[k]=0.0;
                                                                                             }
                                                                             if(fre2[k]<0.0){
                                                                                             fre2[k]=0.0;
                                                                                             }
                                                                             if(fre3[k]<0.0){
                                                                                             fre3[k]=0.0;
                                                                                             }
                                                                             fprintf(output1,"%f\t%f\t%f\t%f\n",kdata2[k],fre1[k],fre2[k],fre3[k]);
                                                                             }
                                }
/*
      for(j=0;j<rows;j++){
                          //Ensuring zero frequency for the acoustic phonons at Gamma point
                          if(j==0||j==kpoint||j==2*kpoint){
                                                           fre1[j]=0.000000;
                                                           fre2[j]=0.000000;
                                                           fre3[j]=0.000000;
                                                           }
                          fprintf(output1,"%f\t%f\t%f\t%f\n",kdata2[j],fre1[j],fre2[j],fre3[j]);
                          }
                          */
      fclose(output1);
      printf("%s file is successfully created.\n",file4);
      printf("------------------------------------------------------------------\n");
// create K_points.dat file
//      printf("Do you want to creat K_points.dat file for the following programs:\n");
//      printf("1. Velocities.cpp (Group and Phase Velocites)\n");
//      printf("2. Gruneisen_constant.cpp (Phonon spectrum averaged Gruneisen constant)\n");
//      printf("3. Phonon_thermal_conductivity_sumk.cpp \n");
//      printf("Computing mode-Gruneisen constant using Mode_Gruneisen_constant.cpp \n");
//      printf("does not require to creat K_points.dat file.\n");
//      printf("Enter your choice:Yes(1) or No(2)\n");
//      scanf("%d",&kfiles);
   kfiles=1;
if(kfiles==1){
      char file5[128];
      float *kxdata,*kydata,*kzdata;
      float *kweight;
      float tweight;
      float dummy3, dummy4;
      int krows;
      int pv;
      int S;
//      while((S=getchar())!=EOF&&S!='\n');
      printf("Enter the file name for k-coordinates and their weights:\n");
//      gets(file5);
      sprintf(file5,"in/K.dat");
      input1=fopen(file5,"r");
      if(input1==NULL){
                      perror("Error while opening the file.\n");
                      printf("Could not find file %s.\n",file5);
                      exit(EXIT_FAILURE);
                      }
      else {
            printf("File %s ls loaded.\n",file5);
            }
// Determine the total number of k-points and total weight
//Number of kpoints provided must be consistent with your input in the begnning
      R_1=0;
      while(!feof(input1)){
                           fscanf(input1,"%f %f %f %f",&dummy1, &dummy2, &dummy3, &dummy4);
                           R_1++;
                           }
      krows=R_1-1;
      fclose(input1);
      kxdata=(float*)malloc(krows*sizeof(float));
      kydata=(float*)malloc(krows*sizeof(float));
      kzdata=(float*)malloc(krows*sizeof(float));
      kweight=(float*)malloc(krows*sizeof(float));
      if(krows==M_k){
                        printf("Total number of kpoints in %s is %d.\n",file5,krows);
                        printf("This is consistent with your input:%d\n",M_k);
                        printf("K_points.dat file will be created.\n");
                        }
      else if(krows!=M_k){
                             printf("Inconsistent number of kpoints found:\n");
                             printf("%s: %d\n",file5,krows);
                             printf("Your previous input:%d\n",M_k);
                             printf("Sorry, program will terminate....\n");
                             exit(EXIT_FAILURE);
                             }
      input1=fopen(file5,"r");
      for(k=0;k<krows;k++){
                           fscanf(input1,"%f %f %f %f",&(kxdata[k]),&(kydata[k]),&(kzdata[k]),&(kweight[k]));
                           }
      fclose(input1);
      tweight=0.000000;
      for(j=0;j<krows;j++){
                           tweight+=kweight[j];
                           }
      printf("Total weight of kpoints is %f.\n",tweight);
       for(i=1;i<=3;i++){
	                    if(i==1){
						         output2=fopen("out/file_creation/Raw_cmp_new.dat","w");
								 for(j=1;j<=N_t*3;j++){
                                                       for(k=(j-1)*krows;k<j*krows;k++){
                                                                                        pv=k-(j-1)*krows;
                                                                                        fprintf(output2,"%f\t%f\t%f\t%f\n",kxdata[pv],kydata[pv],kzdata[pv],fre1[k]);
                                                                                       }
                                                       }
                                 fclose(output2);
								 }
						else if(i==2){
						             output2=fopen("out/file_creation/Raw_min_new.dat","w");
									 for(j=1;j<=N_t*3;j++){
                                                       for(k=(j-1)*krows;k<j*krows;k++){
                                                                                        pv=k-(j-1)*krows;
                                                                                        fprintf(output2,"%f\t%f\t%f\t%f\n",kxdata[pv],kydata[pv],kzdata[pv],fre2[k]);
                                                                                       }
                                                       }
                                 fclose(output2);
									 }
						else if(i==3){
						             output2=fopen("out/file_creation/Raw_exp_new.dat","w");
									 for(j=1;j<=N_t*3;j++){
                                                       for(k=(j-1)*krows;k<j*krows;k++){
                                                                                        pv=k-(j-1)*krows;
                                                                                        fprintf(output2,"%f\t%f\t%f\t%f\n",kxdata[pv],kydata[pv],kzdata[pv],fre3[k]);
                                                                                       }
                                                       }
                                 fclose(output2);
									 }
					   }
      free(kxdata); free(kydata); free(kzdata); free(kweight);
      }
else if(kfiles==2){
                   printf("Only Phonon_volume.dat file is created.\n");
                   printf("You can use as the input for Mode_Gruneisen_constant.cpp.\n");
                   } 

	/*********************interpolation*****************/
	FILE *input2, *input3, *input4;
	FILE *output3, *output4, *output5;
	Raw *cmp, *exp, *min, *cmp_intplt, *exp_intplt, *min_intplt;
	char *filenameRaw[] = {"out/file_creation/Raw_cmp_new.dat", "out/file_creation/Raw_min_new.dat", "out/file_creation/Raw_exp_new.dat"};
	char filename[128], line[1028];
	int n, Nraw, Nraw_intplt;
	float *xa, *ya, *x, *y, *y2, xMin_cmp, xMax_cmp, xMin_min, xMax_min, xMin_exp, xMax_exp, yp1, ypn;
	double xMin, xMax, a, b, c, x0, y0, z0, x1, y1, z1;

	Nraw = 3 * Natoms * Nkpoints;
	AllocMem (cmp, Nraw, Raw);
	AllocMem (min, Nraw, Raw);
	AllocMem (exp, Nraw, Raw);

	for (n = 0; n < 3; n ++) {
		sprintf (filename, "%s", filenameRaw[n]);
		if ((input2 = fopen (filename, "r")) == NULL) {
			printf ("%s does not exist\n", filename);
			exit (1);
		}
		i = 0;
		while (1) {
			if (fgets (line, 1028, input2) == NULL) break;
			switch (n) {
				case 0: sscanf (line, "%lg %lg %lg %lg", &cmp[i].x, &cmp[i].y, &cmp[i].z, &cmp[i].fre); break;
				case 1: sscanf (line, "%lg %lg %lg %lg", &min[i].x, &min[i].y, &min[i].z, &min[i].fre); break;
				case 2: sscanf (line, "%lg %lg %lg %lg", &exp[i].x, &exp[i].y, &exp[i].z, &exp[i].fre); break;
			}
			i ++;
		}
		fclose (input2);
	}
	
	//find xMax and xMin
	xMax_cmp = xMin_cmp = cmp[0].x;
	xMax_min = xMin_min = min[0].x;
	xMax_exp = xMin_exp = exp[0].x;
	for (i = 0; i < Nraw; i ++) {
		if (xMax_cmp < cmp[i].x) xMax_cmp = cmp[i].x;
		if (xMin_cmp > cmp[i].x) xMin_cmp = cmp[i].x;
		if (xMax_min < min[i].x) xMax_min = min[i].x;
		if (xMin_min > min[i].x) xMin_min = min[i].x;
		if (xMax_exp < exp[i].x) xMax_exp = exp[i].x;
		if (xMin_exp > exp[i].x) xMin_exp = exp[i].x;
	}
	//allocate memory
	Nraw_intplt = Nkpoints_set * Natoms * 3;
	AllocMem (cmp_intplt, Nraw_intplt, Raw);
	AllocMem (min_intplt, Nraw_intplt, Raw);
	AllocMem (exp_intplt, Nraw_intplt, Raw);
	AllocMem (xa, Nkpoints+1, float);
	AllocMem (ya, Nkpoints+1, float);
	AllocMem (y2, Nkpoints+1, float);
	AllocMem (x, Nkpoints_set+1, float);
	AllocMem (y, Nkpoints_set+1, float);

	//Raw_cmp
	for (n = 0; n < Natoms * 3; n ++) {
		//init
		for (i = 0; i < Nkpoints_set; i ++) {
			cmp_intplt[i+Nkpoints_set*n].x = (xMax_cmp - xMin_cmp) / (Nkpoints_set - 1) * i + xMin_cmp;
			cmp_intplt[i+Nkpoints_set*n].y = 0.;
			cmp_intplt[i+Nkpoints_set*n].z = 0.;
			x[i+1] = cmp_intplt[i+Nkpoints_set*n].x;
		}
		for (i = 0; i < Nkpoints; i ++) {
			xa[i+1] = cmp[i+Nkpoints*n].x;
			ya[i+1] = cmp[i+Nkpoints*n].fre;
		}
		//interpolation
		yp1 = (ya[2] - ya[1]) / (xa[2] - xa[1]);
		ypn = (ya[Nkpoints] - ya[Nkpoints-1]) / (xa[Nkpoints] - xa[Nkpoints-1]);
		spline(xa, ya, Nkpoints, yp1, ypn, y2);
		for (i = 0; i < Nkpoints_set; i ++) {
			splint (xa, ya, y2, Nkpoints, x[i+1], &y[i+1]);
			cmp_intplt[i+Nkpoints_set*n].fre = y[i+1];
		}
	}

	//Raw_min
	for (n = 0; n < Natoms * 3; n ++) {
		//init
		for (i = 0; i < Nkpoints_set; i ++) {
			min_intplt[i+Nkpoints_set*n].x = (xMax_min - xMin_min) / (Nkpoints_set - 1) * i + xMin_min;
			min_intplt[i+Nkpoints_set*n].y = 0.;
			min_intplt[i+Nkpoints_set*n].z = 0.;
			x[i+1] = min_intplt[i+Nkpoints_set*n].x;
		}
		for (i = 0; i < Nkpoints; i ++) {
			xa[i+1] = min[i+Nkpoints*n].x;
			ya[i+1] = min[i+Nkpoints*n].fre;
		}
		//interpolation
		yp1 = (ya[2] - ya[1]) / (xa[2] - xa[1]);
		ypn = (ya[Nkpoints] - ya[Nkpoints-1]) / (xa[Nkpoints] - xa[Nkpoints-1]);
		spline(xa, ya, Nkpoints, yp1, ypn, y2);
		for (i = 0; i < Nkpoints_set; i ++) {
			splint (xa, ya, y2, Nkpoints, x[i+1], &y[i+1]);
			min_intplt[i+Nkpoints_set*n].fre = y[i+1];
		}
	}

	//Raw_exp
	for (n = 0; n < Natoms * 3; n ++) {
		//init
		for (i = 0; i < Nkpoints_set; i ++) {
			exp_intplt[i+Nkpoints_set*n].x = (xMax_exp - xMin_exp) / (Nkpoints_set - 1) * i + xMin_exp;
			exp_intplt[i+Nkpoints_set*n].y = 0.;
			exp_intplt[i+Nkpoints_set*n].z = 0.;
			x[i+1] = exp_intplt[i+Nkpoints_set*n].x;
		}
		for (i = 0; i < Nkpoints; i ++) {
			xa[i+1] = exp[i+Nkpoints*n].x;
			ya[i+1] = exp[i+Nkpoints*n].fre;
		}
		//interpolation
		yp1 = (ya[2] - ya[1]) / (xa[2] - xa[1]);
		ypn = (ya[Nkpoints] - ya[Nkpoints-1]) / (xa[Nkpoints] - xa[Nkpoints-1]);
		spline(xa, ya, Nkpoints, yp1, ypn, y2);
		for (i = 0; i < Nkpoints_set; i ++) {
			splint (xa, ya, y2, Nkpoints, x[i+1], &y[i+1]);
			exp_intplt[i+Nkpoints_set*n].fre = y[i+1];
		}
	}

	//obtain Phonon_volume.dat
	sprintf(filename,"out/file_creation/Phonon_volume.dat");
	output4=fopen(filename,"w");
	if (output4 == NULL) {
		printf ("creating %s failed\n", filename);
		exit (1);
	}
	sprintf(filename,"out/file_creation/Phonon_volume_tmp.dat");
	input3=fopen(filename,"r");
	if (input3 == NULL) {
		printf ("creating %s failed\n", filename);
		exit (1);
	}
	n = 0;
	while (1) {
		if (fgets (line, 1028, input3) == NULL) break;
		sscanf (line, "%lg", &a);
		if (n == 0) xMax = xMin = a;
		if (xMax < a) xMax = a;
		if (xMin > a) xMin = a;
		n ++;
	}
	for(i = 0;i < Nraw_intplt; i++) {
		fprintf(output4,"%e\t%e\t%e\t%e\n", (xMax - xMin) / (Nkpoints_set - 1.) * (i % Nkpoints_set) + xMin, \
			cmp_intplt[i].fre, min_intplt[i].fre, exp_intplt[i].fre);
	}

	//obtain K_points.dat
	sprintf(filename,"in/K.dat");
	input4=fopen(filename,"r");
	if (input4 == NULL) {
		printf ("%s does not exist/n", filename);
		exit (1);
	}
	n = 0;
	while (1) {
		if (fgets (line, 1028, input4) == NULL) break;
		sscanf (line, "%lg %lg %lg", &a, &b, &c);
		if (n == 0) {
			x0 = a;
			y0 = b;
			z0 = c;
		} else if (n == Nkpoints - 1) {
			x1 = a;
			y1 = b;
			z1 = c;
		}
		n ++;
	}
	sprintf (filename, "out/file_creation/K_points.dat");
	if ((output3 = fopen (filename, "w")) == NULL) {
		printf ("%s does not exist\n", filename);
		exit (1);
	}
	for (i = 0; i < Nraw_intplt; i ++) {
		fprintf (output3, "%e %e %e %e\n",  \
		(x1 - x0) / (Nkpoints_set - 1.) * (i % Nkpoints_set) + x0, \
		(y1 - y0) / (Nkpoints_set - 1.) * (i % Nkpoints_set) + y0, \
		(z1 - z0) / (Nkpoints_set - 1.) * (i % Nkpoints_set) + z0, \
		min_intplt[i].fre);
	}

	//obtain K.dat after interpolation
	sprintf (filename, "out/file_creation/K.dat");
	if ((output5 = fopen (filename, "w")) == NULL) {
		printf ("%s does not exist\n", filename);
		exit (1);
	}
	for (i = 0; i < Nkpoints_set; i ++) {
		fprintf (output5, "%e %e %e %e\n",  \
		(x1 - x0) / (Nkpoints_set - 1.) * i + x0, \
		(y1 - y0) / (Nkpoints_set - 1.) * i + y0, \
		(z1 - z0) / (Nkpoints_set - 1.) * i + z0, \
		1./Nkpoints_set);
	}

	Nkpoints = Nkpoints_set;

	fclose (input3);
	fclose (input4);
	fclose (output3);
	fclose (output4);
	fclose (output5);
	free (cmp);
	free (min);
	free (exp);
	free (cmp_intplt);
	free (min_intplt);
	free (exp_intplt);
	free (xa);
	free (ya);
	free (y2);
	free (x);
	free (y);
 
// Remove trash files
      int options;
      options = rm_adundant;
      printf("Do you want to remove adundant files:Yes(1) or No(2)\n");
      printf("Enter your option:(MUST BE AN INTEGER) %d\n", options);
//      scanf("%d",&options);
      if(options==1){
                     int status1, status2, status3;
                     int status4;
                     status1=remove("out/file_creation/Raw_cmp.dat");
                     if(status1==0){
                                    printf("File 'Raw_cmp.dat' is deleted.\n");
                                    }
                     status2=remove("out/file_creation/Raw_min.dat");
                     if(status2==0){
                                    printf("File 'Raw_min.dat' is deleted.\n");
                                    }
                     status3=remove("out/file_creation/Raw_exp.dat");
                     if(status3==0){
                                    printf("File 'Raw_exp.dat' is deleted.\n");
                                    }
                     status4=remove("out/file_creation/Phonon_volume_tmp.dat");
                     if(status4==0){
                                    printf("File 'Phonon_volume_tmp.dat' is deleted.\n");
                                    }
                     }
       else if(options==2){
                           printf("No file has been removed in the folder.\n");
                           }    
      printf("All required files are created and saved.\n");
      printf("Press 'Enter' key to exit the program.\n");
      free(kdata1);free(fre1);
      free(kdata2); free(fre2);
      free(kdata3); free(fre3);
}
