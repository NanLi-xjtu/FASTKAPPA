#include "print.h"

int cas_pho;
int Natoms, Nkpoints, Nkpoints_set;
int creat_kpoints;
int rm_adundant;
int frqcUnt;
int readV; // options for reading the cell volume
VecR volumes_cee;
int options_gru; // options for an additional outputs for plotting purpose.
real stprt;
real fntprt;
real icmtprt;
int options_c;
int ndisp; // number of dispersions
real cel_volm;
int Nelemt;
real gra_siz;
real molcl_weit;
int options_sca;
int methods_theml;
int Natoms_convtn;
real scaling_m5;
real bond_lent_avg;
real temprt_fre;
int Ncells_primtv;
real MGP;
real ASV;
real Tdebye;
real Textint;
real latc_const;
real scaling_m1;
int dimension_m4;
real LAfre, TA1fre, TA2fre; // maximum frequencies of LA and TA modes in Brillouin zone.
int options_Deb_sca;

NameList nameList[] = {
	NameI (cas_pho),
	NameI (Natoms),
	NameI (Nkpoints_set),
	NameI (creat_kpoints),
	NameI (rm_adundant),
	NameI (frqcUnt),
	NameI (readV),
	NameR (volumes_cee),
	NameI (options_gru),
	NameR (stprt),
	NameR (fntprt),
	NameR (icmtprt),
	NameI (options_c),
	NameI (ndisp),
	NameR (cel_volm),
	NameI (Nelemt),
	NameR (gra_siz),
	NameI (Natoms_convtn),
	NameR (molcl_weit),
	NameI (options_sca),
	NameI (methods_theml),
	NameR (scaling_m5),
	NameR (bond_lent_avg),
	NameR (temprt_fre),
	NameI (Ncells_primtv),
	NameR (MGP),
	NameR (ASV),
	NameR (Tdebye),
	NameR (Textint),
	NameR (latc_const),
	NameR (scaling_m1),
	NameI (dimension_m4),
	NameI (options_Deb_sca),
};

int GetNameList (int argc, char **argv)
{
	int id, j, k, match, ok;
	char buff[80], *token;
	FILE *fp;

	sprintf (buff, "in/fastkappa.in");
	if ((fp = fopen (buff, "r")) == 0) return (0);
	for (k = 0; k < sizeof (nameList) / sizeof (NameList); k ++)
		nameList[k].vStatus = 0;
	ok = 1;
	while (1){
		fgets (buff, 80, fp);
		if (feof (fp)) break;
		token = strtok (buff, "\t\n");
		if (! token) break;
		match = 0;
		for (k = 0; k < sizeof (nameList) / sizeof (NameList); k++){
			if (strcmp (token, nameList[k].vName) == 0){
				match = 1;
				if (nameList[k].vStatus == 0){
					nameList[k].vStatus = 1;
					for (j = 0; j < nameList[k].vLen; j++){
						token = strtok (NULL, ", \t\n");
						if (token){
							switch (nameList[k].vType){
								case N_I:
									*NP_I = atol (token);
									break;
								case N_R:
									*NP_R = atof (token);
									break;
							}
						} else{
							nameList[k].vStatus = 2;
							ok = 0;
						}
					}
					token = strtok (NULL, ", \t\n");
					if (token){
						nameList[k].vStatus = 3;
						ok = 0;
					}
					break;
				}else{
					nameList[k].vStatus = 4;
					ok = 0;
				}
			}
		}
		if (! match) ok = 0;
	}
	fclose (fp);
	for (k = 0; k < sizeof (nameList) / sizeof (NameList); k ++){
		if (nameList[k].vStatus != 1) ok = 0;
	}
	return (ok);
}

void PrintNameList (FILE *fp)
{
	int j, k;

	fprintf (fp, "NameList -- data\n");
	for (k = 0; k < sizeof (nameList) / sizeof (NameList); k ++){
		fprintf (fp, "%s\t", nameList[k].vName);
		if (strlen (nameList[k].vName) < 8) fprintf (fp, "\t");
		if (nameList[k].vStatus > 0){
			for (j = 0; j < nameList[k].vLen; j ++){
				switch (nameList[k].vType){
					case N_I:
						fprintf (fp, "%d ", *NP_I);
						break;
					case N_R:
						fprintf (fp, "%#g ", *NP_R);
						break;
				}
			}
		}
		switch (nameList[k].vStatus){
			case 0:
				fprintf (fp, "** no data");
				break;
			case 1:
				break;
			case 2:
				fprintf (fp, "** missing data");
				break;
			case 3:
				fprintf (fp, "** extra data");
				break;
			case 4:
				fprintf (fp, "** multiply defined");
				break;
		}
		fprintf (fp, "\n");
	}
	fprintf (fp, "----\n");
}

FILE *ReadFile (char filename[128])
{
	FILE *input;

	if ((input = fopen (filename, "r")) == NULL) {
		printf ("%s doesn't exist\n", filename);
		exit (1);
	}

	return (input);
}

FILE *WriteFile (char filename[128])
{
	FILE *output;

	if ((output = fopen (filename, "w")) == NULL) {
		printf ("creating %s failed\n", filename);
		exit (1);
	}

	return (output);
}
